from pathlib import Path
import os,json,time,subprocess,traceback
C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');O=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
state=O/'mapping_queue_status.json'
def status(s,**k):state.write_text(json.dumps(dict(status=s,scene='scene0011_00',filter_version='split_new3500_inherit100',repair_complete=False,evaluation_complete=False,**k),indent=2))
try:
 status('WAITING_SHARED_INPUTS')
 while True:
  p=O/'shared_input_status.json'
  try:d=json.loads(p.read_text())
  except (FileNotFoundError,json.JSONDecodeError):d={}
  if d.get('status')=='FAILED':raise RuntimeError('shared inputs failed: '+str(d))
  if d.get('status')=='PASS':break
  time.sleep(30)
 jobs=[]
 for method,n in [('main',400),('online',100)]:
  env={**os.environ,'CVPR_CHECKPOINT':str(n),'CVPR_TRACK_GROUP':'B','PYTHONDONTWRITEBYTECODE':'1'}
  log=(O/('mapping_'+method+'.log')).open('a')
  p=subprocess.Popen([PY,'-B',str(C/'run_mapping_once.py'),method,str(n)],env=env,stdout=log,stderr=subprocess.STDOUT)
  jobs.append((method,n,p,log))
 status('RUNNING',stage='PARALLEL_MAIN400_AND_ONLINE100_MAPPING',pids={m:p.pid for m,n,p,f in jobs})
 failures=[]
 for method,n,p,log in jobs:
  rc=p.wait();log.close()
  if rc:failures.append((method,n,rc))
 if failures:raise RuntimeError(str(failures))
 status('PASS',stage='BASELINE400_AND_ONLINE100_MAPS_COMPLETE_REPAIR_NOT_STARTED')
except Exception:
 status('FAILED',traceback=traceback.format_exc());raise
