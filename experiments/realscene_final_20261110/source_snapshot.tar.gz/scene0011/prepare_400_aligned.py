from pathlib import Path
import sys,os,json,hashlib,time,traceback
import numpy as np,cv2
BASE=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');R=BASE/'scannet400_aligned_input';R.mkdir(exist_ok=True);SRC=BASE/'source_rgbd/scene0011_00';start=time.time();sys.path.insert(0,'/home/chenkejun/CVPR/experiments/p1a1_scannet_20261008/snapshot/revisable_instance_map/src')
from revisable_instance_map.scannet_frame_io import color_coordinates
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2));os.replace(t,p)
try:
 candidates=sorted([int(p.stem) for p in (SRC/'depth').glob('*.png') if (SRC/'color'/f'{p.stem}.jpg').exists() and (SRC/'pose'/f'{p.stem}.txt').exists() and np.isfinite(np.loadtxt(SRC/'pose'/f'{p.stem}.txt')).all()]);assert len(candidates)>=400 and len(set(candidates))==len(candidates)
 selected=np.asarray(candidates)[np.linspace(0,len(candidates)-1,400,dtype=int)].tolist();assert len(set(selected))==400
 out=R/'input/results';out.mkdir(parents=True,exist_ok=True);K=np.loadtxt(SRC/'intrinsic/intrinsic_depth.txt')[:3,:3];poses=np.tile(np.eye(4,dtype=np.float32),(1996,1,1));intr=np.tile(K,(1996,1,1));mx,my=color_coordinates(SRC,640,480);records=[]
 for j,raw in enumerate(selected):
  fid=5*j;dp=SRC/'depth'/f'{raw}.png';rgbp=SRC/'color'/f'{raw}.jpg';pp=SRC/'pose'/f'{raw}.txt';depth=cv2.imread(str(dp),-1);rgb=cv2.imread(str(rgbp));assert depth.shape==(480,640) and rgb is not None
  aligned=cv2.remap(rgb,mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT);png=out/f'frame{fid:06d}.png';assert cv2.imwrite(str(png),aligned)
  jpg=out/f'frame{fid:06d}.jpg';dep=out/f'depth{fid:06d}.png'
  if not jpg.exists():jpg.symlink_to(png)
  if not dep.exists():dep.symlink_to(dp)
  poses[fid]=np.loadtxt(pp).astype(np.float32);records.append(dict(frame=fid,original_frame=raw,rgb_sha256=sha(rgbp),depth_sha256=sha(dp),pose_sha256=sha(pp),aligned_rgb_sha256=sha(png)))
  if len(records)%25==0:put(R/'status.json',{'status':'RUNNING','stage':'aligned_input_preparation','completed':len(records),'total':400,'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 np.savetxt(R/'input/traj.txt',poses.reshape(-1,16),fmt='%.17g');np.savetxt(R/'input/intrinsics.txt',intr.reshape(-1,9),fmt='%.17g');base=json.loads(Path('/data/chenkejun/CVPR/results/scannet_ovimap_strict_dbscan_20261104/inputs/scene0050_00/config.json').read_text());base['scene']='scene0011_00';base['camera'].update(fx=float(K[0,0]),fy=float(K[1,1]),cx=float(K[0,2]),cy=float(K[1,2]));base['frame_selection']=dict(start=0,stop_exclusive=1996,stride=5);base['source'].update(scene_root=str(R/'input'),mask_root=str(R/'masks'));put(R/'config.json',base)
 put(R/'selection.json',{'status':'PASS','scene':'scene0011_00','original_frames':selected,'rows':records,'sampling':'uniform over same processed valid frame list as 200-frame experiment','frame_alias_note':'virtual indices 0,5,...,1995; original IDs in rows','GT_used':False,'elapsed_seconds':time.time()-start})
 put(R/'status.json',{'status':'PASS','stage':'aligned_input_preparation','completed':400,'elapsed_seconds':time.time()-start,'pid':os.getpid(),'not_repair':True})
except BaseException:
 put(R/'status.json',{'status':'FAILED','stage':'aligned_input_preparation','elapsed_seconds':time.time()-start,'traceback':traceback.format_exc()});raise
