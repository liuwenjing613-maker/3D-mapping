from pathlib import Path
import os,json,subprocess,shutil,time,ast
E=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');O=Path('/home/chenkejun/CVPR/experiments/scannet_repair_50_120_200_20261106/online/scene0011_00/selection_code/120/B');OD=Path('/data/chenkejun/CVPR/results/scannet_repair_50_120_200_20261106/online/scene0011_00/120/B/candidates');root=R/'scannet400/online/scene0011_00/200/B';B=root/'mapping';cand=root/'candidates';C=E/'scannet400_frontend/online/scene0011_00/200/B';d=json.loads((B/'mapping_complete.json').read_text());assert d['status']=='PASS' and d['frame_count']==200 and not d['GT_used'] and not d['future_inputs_used'];prior=json.loads((B/'prior_commit.json').read_text());assert prior['processed_frames']==100 and prior['prior_commit_path'].startswith(str(R/'scannet400'))
cand.mkdir(exist_ok=True);C.mkdir(parents=True,exist_ok=True)
for name in ['baseline','geometry','association','inputs','mapping_complete.json']:
 src=B/name;dst=cand/name;assert src.exists()
 if not dst.exists():dst.symlink_to(src.resolve(),target_is_directory=src.is_dir())
if not (C/'config.json').exists():(C/'config.json').symlink_to((B/'config.json').resolve())
for name in ['catalog','frontend','overmerge','intersection','versions','semantic_route','grouping_r2']:
 dst=C/name
 if not dst.exists():shutil.copytree(O/name,dst,ignore=shutil.ignore_patterns('__pycache__'))
 for p in dst.rglob('*'):
  if not p.is_file() or p.suffix not in ['.py','.json']:continue
  s=p.read_text().replace(str(OD),str(cand)).replace(str(O),str(C)).replace('geometry_prefix120.json','geometry_prefix200.json')
  if p.name=='build_candidates.py':
   s=s.replace('range(0,596,5)','range(0,996,5)').replace('arange(250,596,5,','arange(500,996,5,').replace('range(250,596,5)','range(500,996,5)').replace('len(poses)==596','len(poses)==996').replace("['all_frames_checked']=70","['all_frames_checked']=100")
   for a,b in [("'previous_committed_checkpoint':50","'previous_committed_checkpoint':100"),("'history_frames':120","'history_frames':200"),("'checkpoint':120","'checkpoint':200"),("'candidate_processed_frame_range':[51,120]","'candidate_processed_frame_range':[101,200]"),("'candidate_raw_frame_range':[250,595]","'candidate_raw_frame_range':[500,995]"),("'repair50_applied':True","'repair100_applied':True"),("'repair120_applied':False","'repair200_applied':False"),('checkpoint50 branch B, continuation to120','checkpoint100 branch B, continuation to200'),('new_mapping_frames_51_to120','new_mapping_frames_101_to200')]:s=s.replace(a,b)
  if p.name=='prepare_inputs.py':
   for a,b in [('range(250,596,5)','range(500,996,5)'),("['previous_committed_checkpoint']==50","['previous_committed_checkpoint']==100"),('previous_committed_checkpoint=50','previous_committed_checkpoint=100'),('history_frames=120','history_frames=200'),('repair50_applied=True','repair100_applied=True'),('repair120_applied=False','repair200_applied=False')]:s=s.replace(a,b)
  if p.suffix=='.py':ast.parse(s)
  else:json.loads(s)
  p.write_text(s)
src=E/'scannet200/online/scene0011_00/50/B/frontend/infer_sam.py';s=src.read_text().replace(str(R/'scannet200/online/scene0011_00/50/B/candidates/frontend'),str(cand/'frontend'));ast.parse(s);(C/'frontend/infer_sam.py').write_text(s)
rows=[x for x in json.loads((R/'scannet400_aligned_input/selection.json').read_text())['rows'] if x['frame']<1000];assert len(rows)==200;(cand/'selection_prefix.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')
assert not (root/'catalog_build_launch.json').exists()
with (root/'catalog_build.log').open('ab',buffering=0) as f:p=subprocess.Popen(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(C/'catalog/build_candidates.py'),'scene0011_00'],cwd=C/'catalog',env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(root/'catalog_build_launch.json').write_text(json.dumps({'pid':p.pid,'started':time.time(),'scope':'causal 100-200 catalog after real 100 commit'})+'\n')
s=(E/'scannet400_frontend/front_driver.py').read_text().replace('expected=list(range(0,(n-1)*5+1,5))','expected=list(range(500,(n-1)*5+1,5))').replace("d['previous_committed_checkpoint']==0","d['previous_committed_checkpoint']==100");ast.parse(s);driver=C/'front_driver.py';driver.write_text(s)
with (root/'candidate_frontend_launcher.log').open('ab',buffering=0) as f:q=subprocess.Popen(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(driver),'online','200','B'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(root/'candidate_frontend_launch.json').write_text(json.dumps({'pid':q.pid,'started':time.time(),'scope':'SAM3+CropFormer proposals after catalog'})+'\n');print('400 online200 catalog',p.pid,'front',q.pid)
