from pathlib import Path
import sys,os,json,time,ast,traceback,hashlib
import numpy as np
from collections import defaultdict
from types import SimpleNamespace
O=Path('/home/chenkejun/CVPR/experiments/scannet_ovimap_strict_dbscan_20261104');sys.path.insert(0,str(O));from dbscan_common import load,save,sha
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/scannet_repair_50_120_200_20261106/mapping_snapshot/revisable_instance_map/src');from revisable_instance_map.frame_io import ReplicaFrameSource
from revisable_instance_map.observations import RawInstanceObservation,source_pixel_indices
R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');root=R/'scannet400/main/scene0011_00/400/B/mapping';out=R/'scannet400/baseline_postprocess/original_evidence';out.mkdir(parents=True,exist_ok=True);start=time.time()
def write(name,d):p=out/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(p)
try:
 receipt=json.loads((root/'mapping_complete.json').read_text());assert receipt['status']=='PASS' and receipt['frame_ids']==list(range(0,2000,5)) and not receipt['repair_applied'] and not receipt['GT_used'];ledger=load(root/'association/observation_support_3cm.npz');assoc=SimpleNamespace(**json.loads(str(ledger['parameters_json'][0])))
 source=Path('/home/chenkejun/CVPR/experiments/scannet_repair_50_120_200_20261106/main/scene0011_00/commit_continue.py');text=source.read_text();node=next(t for t in ast.parse(text).body if isinstance(t,ast.FunctionDef) and t.name=='sample_pixels');namespace=dict(np=np,source_pixel_indices=source_pixel_indices);exec(compile(ast.get_source_segment(text,node),str(source),'exec'),namespace);sample=namespace['sample_pixels']
 obs={};byframe=defaultdict(list)
 for line in (root/'association/observations.jsonl').read_text().splitlines():
  item=RawInstanceObservation(**json.loads(line));obs[item.observation_id]=item
 sourceframes=ReplicaFrameSource(root/'config.json');assert list(sourceframes.frame_ids)==receipt['frame_ids'];assert set(obs)==set(map(str,ledger['observation_ids']))
 for k,fid in enumerate(ledger['frame_ids']):byframe[int(fid)].append(k)
 samples=[None]*len(obs);pixels=[None]*len(obs)
 for index,fid in enumerate(sourceframes.frame_ids,1):
  fr=sourceframes.load_frame(fid)
  for k in byframe[fid]:
   item=obs[str(ledger['observation_ids'][k])];assert item.frame_id==fid and item.source_mask_sha256==str(ledger['source_mask_sha256'][k]);px,vox=sample(fr,item,assoc);lo,hi=map(int,ledger['offsets'][k:k+2]);np.testing.assert_array_equal(np.unique(vox,axis=0),ledger['voxel_coordinates'][lo:hi]);samples[k]=vox;pixels[k]=px
  if index%25==0:write('status.json',{'status':'RUNNING','stage':'BASELINE_OBSERVATION_EVIDENCE_ONLY','frames':index,'total':400,'elapsed_seconds':time.time()-start})
 offsets=np.r_[0,np.cumsum([len(v) for v in samples])].astype(np.int64);save(out/'source_pixel_support.npz',observation_ids=ledger['observation_ids'],instance_ids=ledger['instance_ids'],frame_ids=ledger['frame_ids'],layer_index=np.zeros(len(obs),np.int32),offsets=offsets,sampled_voxel_coordinates=np.concatenate(samples),sampled_pixel_indices=np.concatenate(pixels),voxel_size_m=ledger['voxel_size_m']);write('complete.json',{'status':'PASS','frames':400,'observations':len(obs),'all_saved_observation_support_exact':True,'only_original_observations':True,'GT_used':False,'output_sha256':sha(out/'source_pixel_support.npz'),'elapsed_seconds':time.time()-start});write('status.json',{'status':'PASS','stage':'BASELINE_OBSERVATION_EVIDENCE_ONLY','frames':400,'elapsed_seconds':time.time()-start})
except BaseException:write('status.json',{'status':'FAILED','traceback':traceback.format_exc()});raise
