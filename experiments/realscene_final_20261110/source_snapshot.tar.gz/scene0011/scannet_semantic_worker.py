from pathlib import Path
import os,sys,json,time,traceback,hashlib,importlib.util,collections
import numpy as np
from PIL import Image
root=Path(sys.argv[1]);out=root/'candidates/background070';out.mkdir(parents=True,exist_ok=True);start=time.time()
def write(p,x):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n');q.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 med=json.loads((root/'candidates/medoids/result.json').read_text());group=json.loads((root/'candidates/grouping_r2/grouping.json').read_text());assert med['status']=='PASS';seeds={x['id']:x for x in group['seeds']};ref=json.loads(Path('/data/chenkejun/CVPR/results/offline_medoids_background070_20261108/room0/classification.json').read_text());cfg=ref['config'];assert cfg['pixel_confidence']==cfg['mask_fraction']==.7
 spec=importlib.util.spec_from_file_location('frozen_semantics','/home/chenkejun/CVPR/experiments/offline_medoids_background_20261108/replay.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);labels,_=mod.resolve_labels(ref['model']['id2label'],cfg);pred=mod.Predictor(cfg,ref['model'])
 # Check original model output against a frozen frame before applying to ScanNet.
 a=ref['frames'][0];image=np.asarray(Image.open(a['RGB_path']).convert('RGB'));p,c=pred.predict(image)
 with np.load(a['cache']) as z:assert np.array_equal(p,z['labels']) and np.array_equal(c>=.7,z['confidence']>=.7)
 byframe=collections.defaultdict(list)
 for g in med['groups']:
  for cl in g['clusters']:
   s=seeds[cl['representative']];byframe[int(s['frame'])].append(dict(group_id=g['id'],cluster=cl['number'],mask_id=s['id'],cluster_members=cl['members'],original_primary=g['primary']))
 method=root.parts[-4];n=int(root.parts[-2]);g=root.parts[-1]
 cfgpath=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet200')/method/'scene0011_00'/str(n)/g/'config.json';raw=json.loads(cfgpath.read_text());scene=Path(raw['source']['scene_root']);results=[]
 for num,(fid,items) in enumerate(sorted(byframe.items()),1):
  rgb=scene/raw['source']['rgb_pattern'].format(frame=fid);im=np.asarray(Image.open(rgb).convert('RGB'));p,c=pred.predict(im)
  cache=out/f'f{fid:06d}.npz';np.savez_compressed(cache,labels=p,confidence=c)
  for item in items:
   s=seeds[item['mask_id']];maskpath=root/'candidates/grouping_r2'/s['mask'];assert sha(maskpath)==s['mask_sha256'];mask=np.asarray(Image.open(maskpath))>0;info=mod.summarize_mask(p,c,mask,labels,cfg)
   results.append({**item,'frame':fid,'mask_sha256':s['mask_sha256'],'support':s['support_count'],'cache':str(cache),'cache_sha256':sha(cache),'decision':info['decision'],'exclude':info['exclude'],'top_class':info['top_class'],'high_excluded_fraction':info['high_excluded_fraction']})
  if num%5==0:write(out/'status.json',dict(status='RUNNING',stage='BACKGROUND070',frames=num,total_frames=len(byframe),seconds=time.time()-start))
 kept=[r for r in results if not r['exclude']];result={'status':'PASS','stage':'MEDOIDS_BACKGROUND070_ONLY','records':results,'retained_candidates':kept,'summary':{'input':len(results),'excluded':len(results)-len(kept),'retained':len(kept),'frames':len(byframe)},'GT_used':False,'tracking_or_repair':False,'elapsed_seconds':time.time()-start};write(out/'result.json',result);write(out/'status.json',{k:v for k,v in result.items() if k not in ('records','retained_candidates')})
except BaseException:write(out/'status.json',dict(status='FAILED',traceback=traceback.format_exc()));raise
