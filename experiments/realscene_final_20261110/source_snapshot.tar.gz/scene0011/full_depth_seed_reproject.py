from pathlib import Path
from dataclasses import replace
import json,hashlib,sys,os,time,traceback,collections,importlib.util
import numpy as np
from scipy.spatial import cKDTree
from PIL import Image
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/p1a1_raw_replica8_20261002/snapshot/revisable_instance_map/src')
from revisable_instance_map.frame_io import ReplicaFrameSource
from revisable_instance_map.surface_evidence import project_frame_regions
r=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');u=Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101');scene=sys.argv[1];out=r/'replica_full_depth_fixed_selection/seed_reprojection'/scene;out.mkdir(parents=True,exist_ok=True);start=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');q.replace(p)
try:
 man=json.loads((r/'replica_repair_input_manifest'/f'{scene}.json').read_text());maps=u/'main'/scene/'400/A/mapping';mc=json.loads((maps/'mapping_complete.json').read_text());assert mc['status']=='PASS' and mc['frame_count']==400 and not mc['repair_applied'] and not mc['GT_used']
 surf=maps/'baseline/final/instance_surface.npz'
 with np.load(surf) as z:xyz=z['xyz_m'];labels=z['instance_id']
 tree=cKDTree(xyz);cfg=json.loads((maps/'config.json').read_text());source=ReplicaFrameSource(maps/'config.json');assoc=maps/'association/associations.jsonl';lookup={};oldmax=max(0,int(labels.max()))
 for line in assoc.read_text().splitlines():
  a=json.loads(line);key=(int(a['frame_id']),int(a['mask_local_id']));assert key not in lookup;lookup[key]=int(a['instance_id']);oldmax=max(oldmax,int(a['instance_id']))
 common=Path('/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/main')/scene/'selection_code/400/A/catalog/common.py';spec=importlib.util.spec_from_file_location('catalog_common',common);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 scene_root=Path(cfg['source']['scene_root']);poses=np.loadtxt(scene_root/cfg['source']['trajectory']).reshape(-1,4,4);cam=cfg['camera'];records=[];byframe=collections.defaultdict(list)
 for s in man['seeds']:byframe[int(s['seed_frame'])].append(s)
 tracks={x['mask_id']:x for x in json.loads((r/'replica_gate_label_inputs/complete.json').read_text())['cases'] if x['scene']==scene}
 for index,(fid,items) in enumerate(sorted(byframe.items()),1):
  frame=source.load_frame(fid);depth=np.asarray(Image.open(scene_root/cfg['source']['depth_pattern'].format(frame=fid)),np.float32)/cam['depth_png_units_per_meter'];vis,uv=mod.project_visible(xyz,poses[fid],depth,cam);vi=np.flatnonzero(vis);xy=uv[vi];vl=labels[vi];v_ids,v_n=np.unique(vl[vl>0],return_counts=True);visible=dict(zip(v_ids.tolist(),v_n.tolist()))
  for s in items:
   mid=s['mask_id'];adapt=json.loads(Path(tracks[mid]['path']).read_text());tid=int(adapt['track_id']);assert sha(s['source_mask'])==s['source_mask_sha256'];mask=np.asarray(Image.open(s['source_mask']))>0;support=vi[mask[xy[:,1],xy[:,0]]];assert len(support)>0;lab=labels[support];ids,counts=np.unique(lab[lab>0],return_counts=True);cands=sorted([dict(id=int(i),intersection=int(n),mask_points=len(support),visible_instance_points=int(visible[int(i)]),dice=2*int(n)/(len(support)+visible[int(i)])) for i,n in zip(ids,counts)],key=lambda x:(-x['dice'],x['id']))
   raw,n=np.unique(frame.mask_local[mask],return_counts=True);hist=collections.Counter()
   for k,nv in zip(raw,n):
    if int(k)>0:hist[lookup[(fid,int(k))]]+=int(nv)
   family=min(hist,key=lambda k:(-hist[k],k)) if hist else None
   projected,trackid,stats=project_frame_regions(replace(frame,mask_local=np.where(mask,tid,0).astype(np.uint16)),tree,pixel_stride=2,max_distance_m=.015,workers=2);assert len(projected)>0
   sp=out/(mid+'_gate_support.npz');np.savez_compressed(sp,surface_point_index=projected,track_id=trackid);vp=out/(mid+'_visible_support.npz');np.savez_compressed(vp,indices=support)
   records.append(dict(mask_id=mid,H_group=s['H_group'],seed_frame=fid,track_id=tid,source_mask=s['source_mask'],source_mask_sha256=s['source_mask_sha256'],visible_support=len(support),full_support_sha256=sha(vp),gate_support=str(sp),gate_support_sha256=sha(sp),projected_unique=len(np.unique(projected)),projection_stats=stats,old_family_for_gate=family,old_family_pixel_counts=dict(hist),id_candidates=cands,prior_sparse_preview=s['id_preview'],tracking_adaptation=tracks[mid]['path']))
  write(out/'status.json',dict(status='RUNNING',stage='FULL_DEPTH_SEED_PROJECTION_NOT_REPAIR',frames_done=index,frames_total=len(byframe),completed=len(records),elapsed_seconds=time.time()-start))
 contenders=collections.defaultdict(list)
 for row in records:
  best=row['id_candidates'][0] if row['id_candidates'] else None;row['target_id']=best['id'] if best and best['dice']>.5 else None
  if row['target_id'] is not None:contenders[row['target_id']].append(row)
 for row in records:
  group=contenders.get(row['target_id'],[]);win=min(group,key=lambda q:(-q['id_candidates'][0]['dice'],q['mask_id'])) if group else None
  row['id_action']='inherit' if win is row else 'new';row['persistent_id']=row['target_id'] if win is row else oldmax+row['track_id'];row['conflict_winner']=win['mask_id'] if win else None
 assert len({x['persistent_id'] for x in records})==len(records) and max(x['persistent_id'] for x in records)<65536
 data=dict(status='PASS',stage='FULL_DEPTH_SEED_PROJECTION_AND_ID_DIAGNOSTIC_ONLY',scene=scene,baseline='PPT unified_full_depth_20261101 main pre-repair mapping',input_selection='122 user-reviewed sparse-geometry selected masks; selection has NOT been recomputed on full depth',manual_M0466_preserved=any(x['mask_id']=='M0466' for x in records) if scene=='room0' else None,baseline_surface=str(surf),baseline_surface_sha256=sha(surf),association_sha256=sha(assoc),points=len(xyz),old_max_id=oldmax,objects=records,elapsed_seconds=time.time()-start,GT_used=False,repair_executed=False)
 write(out/'result.json',data);write(out/'status.json',dict(status='PASS',stage=data['stage'],scene=scene,objects=len(records),elapsed_seconds=data['elapsed_seconds'],repair_executed=False))
except BaseException:write(out/'status.json',dict(status='FAILED',traceback=traceback.format_exc()));raise
