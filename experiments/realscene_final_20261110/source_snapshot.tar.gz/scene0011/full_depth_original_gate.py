from pathlib import Path
import sys,json,hashlib,time,os,traceback
import numpy as np
from scipy.spatial import cKDTree
r=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');u=Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101');scene_id=sys.argv[1];out=r/'replica_full_depth_fixed_selection/gate'/scene_id;out.mkdir(parents=True,exist_ok=True);start=time.time();old=Path('/home/chenkejun/CVPR/experiments/auto_v2_room0_20261019/e1_repair');sys.path.insert(0,str(old));import bootstrap;import run_batch as b
from instance_repair.cli import load_script
pure=load_script('_pure_gate_full_depth',Path('/home/chenkejun/CVPR/experiments/v15_main_offline400_20261105/main/room0/track_pure_gate.py'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
def write(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2));os.replace(q,p)
try:
 prep_path=r/'replica_full_depth_fixed_selection/seed_reprojection'/scene_id/'result.json';prep=json.loads(prep_path.read_text());assert prep['status']=='PASS' and all(x['old_family_for_gate'] is not None for x in prep['objects']);assert sha(prep['baseline_surface'])==prep['baseline_surface_sha256']
 class Scene:
  def __init__(self):
   with np.load(prep['baseline_surface']) as z:self.xyz=z['xyz_m'].copy()
   self.maps=u/'main'/scene_id/'400/A/mapping';self.records={fid:None for fid in range(0,2000,5)};self.tree=cKDTree(self.xyz.astype(np.float64));self.source=b.r.ReplicaFrameSource(self.maps/'config.json');self.lookup={}
   ap=self.maps/'association/associations.jsonl';assert sha(ap)==prep['association_sha256']
   for line in ap.read_text().splitlines():
    x=json.loads(line);self.lookup[(int(x['frame_id']),int(x['mask_local_id']))]=int(x['instance_id'])
  def family_view(self,fid,frame,ids):
   p=self.maps/'baseline/frame_support'/f'f{fid:06d}.npz'
   with np.load(p) as z:old_local=np.unique(z['mask_local_id'])
   present=any(self.lookup[(fid,int(m))] in ids for m in old_local if int(m)>0)
   table=np.zeros(int(frame.mask_local.max())+1,dtype=np.int32)
   for m in np.unique(frame.mask_local):
    if m:table[m]=self.lookup[(fid,int(m))]
   mapped=table[frame.mask_local];return bool(present),(mapped>0)&~np.isin(mapped,ids)
 scene=Scene();policy=json.loads((old/'gate_policy.json').read_text());cases={};objects={};canonical={};tracking={}
 for row in prep['objects']:
  mid=row['mask_id'];tid=row['track_id'];adapt=json.loads(Path(row['tracking_adaptation']).read_text());assert adapt['status']=='PASS_INPUT_ADAPTER_ONLY' and adapt['track_id']==tid
  p=Path(row['gate_support']);assert sha(p)==row['gate_support_sha256'];z=np.load(p);points=np.unique(z['surface_point_index'][z['track_id']==tid]);assert len(points)>0
  samples=points[np.linspace(0,len(points)-1,min(len(points),2048),dtype=int)];pad=policy['seed_surface_bbox_padding_m'];bounds=(scene.xyz[points].min(0)-pad,scene.xyz[points].max(0)+pad)
  cases[mid]={'ids':[tid],'config':{'seed_frame':row['seed_frame'],'old_family_ids':[row['old_family_for_gate']]},'case':{'case_uid':mid}};canonical[tid]=tid;objects[tid]={'track_id':tid,'case_uid':mid,'canonical_track_id':tid,'points':points,'samples':samples,'bounds':bounds,'group_id':row['H_group'],'mask_id':mid,'old_family_id':row['old_family_for_gate'],'persistent_id':row['persistent_id']}
  labels=Path(row['tracking_adaptation']).parent/'labels';tracking[mid]={x['frame']:{'label_file':str(labels/f"{x['frame']:06d}.png")} for x in adapt['mapping_frames']};assert sorted(tracking[mid])==list(range(0,2000,5))
 def progress(n,total,seconds):write(out/'status.json',dict(status='RUNNING',stage='FULL_DEPTH_ORIGINAL_GATE_ONLY',scene=scene_id,frames=n,total=total,elapsed_seconds=time.time()-start,pid=os.getpid()))
 progress(0,400,0);result=pure.evaluate(b,scene,cases,objects,canonical,policy,tracking,out=out,progress=progress);assert result['status']=='PASS' and len(result['frames'])==400
 result.update(scene=scene_id,stage='FULL_DEPTH_ORIGINAL_GATE_ONLY',selection='fixed sparse-screened user-approved masks reprojected onto full-depth; full-depth screening not rerun',model='SAM3',baseline='PPT unified_full_depth_20261101',gate_policy_sha256=sha(old/'gate_policy.json'),seed_geometry_sha256=sha(prep_path),GT_used=False,repair_executed=False,elapsed_seconds=time.time()-start)
 write(out/'frame_decisions.json',result);write(out/'status.json',dict(status='PASS',stage='FULL_DEPTH_ORIGINAL_GATE_ONLY',scene=scene_id,frames=400,elapsed_seconds=time.time()-start,accepted_frames_by_track=result['counts']['accepted_frames_by_track']))
except BaseException:write(out/'status.json',dict(status='FAILED',traceback=traceback.format_exc(),elapsed_seconds=time.time()-start));raise
