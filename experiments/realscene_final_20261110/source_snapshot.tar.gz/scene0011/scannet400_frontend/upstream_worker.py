from pathlib import Path
import json,os,sys,time,subprocess,traceback,fcntl
m,n,g=sys.argv[1],int(sys.argv[2]),sys.argv[3]
R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/scannet400')/m/'scene0011_00'/str(n)/g
C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet400_frontend')/m/'scene0011_00'/str(n)/g
S=R/'candidates';status=R/'approved_upstream_status.json';started=time.time();py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
def dump(d):
 p=status.with_suffix('.tmp');p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');p.replace(status)
def state(s,**kw):dump(dict(status=s,method=m,checkpoint=n,group=g,stage_scope='candidate upstream evidence only; no fixed-H, video tracking or repair',elapsed_seconds=time.time()-started,**kw))
def acquire():
 paths=[Path('/data/chenkejun/CVPR/results/ovimap_aligned_main_onlinev2_20261101/gpu_locks'),Path('/data/chenkejun/CVPR/results/requested_fixedH_main_v2b_20261108/online/gpu_locks')]
 for p in paths:p.mkdir(parents=True,exist_ok=True)
 while True:
  lines=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
  for row in lines:
   idx,uid,free,util=[v.strip() for v in row.split(',')]
   if int(free)<30000 or int(util)>15:continue
   locks=[]
   try:
    for path in paths:
     f=(path/(uid+'.lock')).open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
    return idx,uid,locks
   except BlockingIOError:
    for f in locks:fcntl.flock(f,fcntl.LOCK_UN);f.close()
  state('WAITING_GPU');time.sleep(15)
try:
 assert json.loads((S/'frontend/pipeline_complete.json').read_text())['status']=='PASS'
 assert json.loads((S/'frontend/sam2_1/model_provenance.json').read_text())['model']=='SAM3 image interactivity'
 stages=[('overmerge','overmerge/score.py',False),('intersection','intersection/compute.py',False),('versions','versions/compute.py',False),('semantic_classify','semantic_route/classify.py',True),('semantic_cabinet','semantic_route/refine_cabinet.py',True),('semantic_route','semantic_route/route.py',False),('grouping_r2','grouping_r2/compute.py',False)]
 for name,rel,gpu in stages:
  env={**os.environ,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','LD_LIBRARY_PATH':'/data/chenkejun/CVPR/libs/p1a1_roi_cropformer_zoom_20261003/nvidia_580_126_09'}
  env['PYTHONPATH']=str(C/'catalog')+':'+str(C/'versions')+':'+str(C/'semantic_route')+':'+str(C/'grouping_r2')+':/home/chenkejun/CVPR/experiments/scannet_repair_50_120_200_20261106'
  locks=[];idx=uid=None
  if gpu:idx,uid,locks=acquire();env['CUDA_VISIBLE_DEVICES']=uid
  t=time.time();state('RUNNING',stage=name,gpu_index=idx,gpu_uuid=uid)
  try:
   with (R/(name+'.log')).open('ab') as f:rc=subprocess.call([py,'-B','-u',str(C/rel)],cwd=(C/rel).parent,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
   with (R/'approved_upstream_timing.jsonl').open('a') as f:f.write(json.dumps(dict(stage=name,start=t,end=time.time(),seconds=time.time()-t,gpu_index=idx,gpu_uuid=uid,returncode=rc))+'\n')
   if rc:raise RuntimeError(f'{name} failed exit {rc}, see {R/name}.log')
  finally:
   for f in locks:fcntl.flock(f,fcntl.LOCK_UN);f.close()
 state('PASS',stage='UPSTREAM_CANDIDATE_EVIDENCE_ONLY',repair_complete=False,tracking_complete=False)
except BaseException:state('FAILED',traceback=traceback.format_exc());raise
