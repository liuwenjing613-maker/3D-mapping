from pathlib import Path
import os,sys,json,time,subprocess,fcntl,traceback
out=Path(sys.argv[1]);code=Path(sys.argv[2]);state=out/'driver_status.json';start=time.time();locksdir=[Path('/data/chenkejun/CVPR/results/ovimap_aligned_main_onlinev2_20261101/gpu_locks'),Path('/data/chenkejun/CVPR/results/requested_fixedH_main_v2b_20261108/online/gpu_locks')]
def dump(d):q=state.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(state)
chosen=None
try:
 while not chosen:
  rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
  for row in rows:
   idx,uid,free,util=[x.strip() for x in row.split(',')]
   if int(free)<40000 or int(util)>15:continue
   files=[]
   try:
    for directory in locksdir:
     directory.mkdir(parents=True,exist_ok=True);f=(directory/(uid+'.lock')).open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);files.append(f)
    chosen=(idx,uid,files);break
   except BlockingIOError:
    for f in files:fcntl.flock(f,fcntl.LOCK_UN);f.close()
  if not chosen:dump(dict(status='WAITING_GPU',elapsed=time.time()-start));time.sleep(15)
 idx,uid,files=chosen;t=time.time();env={**os.environ,'CUDA_VISIBLE_DEVICES':uid,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','PYTHONDONTWRITEBYTECODE':'1','LD_LIBRARY_PATH':'/data/chenkejun/CVPR/libs/p1a1_roi_cropformer_zoom_20261003/nvidia_580_126_09','XDG_CACHE_HOME':str(out/'cache'),'CUDA_CACHE_PATH':str(out/'cache/cuda'),'MPLCONFIGDIR':str(out/'cache/mpl')};env.pop('PYTHONPATH',None)
 dump(dict(status='RUNNING',gpu_index=int(idx),gpu_uuid=uid,started_unix=t,gpu_wait_seconds=t-start))
 with (out/'cropformer.log').open('ab') as f:rc=subprocess.call(['/data/chenkejun/ovimap_runtime_20260908/envs/cropformer/bin/python','-B','-u',str(code)],cwd=code.parent,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 dump(dict(status='PASS' if rc==0 else 'FAILED',returncode=rc,gpu_index=int(idx),gpu_uuid=uid,seconds=time.time()-t,wall_seconds=time.time()-start,tracking_or_repair=False))
 if rc:raise RuntimeError('cropformer failed')
except BaseException:
 if not state.exists() or json.loads(state.read_text()).get('status')!='FAILED':dump(dict(status='FAILED',traceback=traceback.format_exc()))
 raise
finally:
 if chosen:
  for f in chosen[2]:fcntl.flock(f,fcntl.LOCK_UN);f.close()
