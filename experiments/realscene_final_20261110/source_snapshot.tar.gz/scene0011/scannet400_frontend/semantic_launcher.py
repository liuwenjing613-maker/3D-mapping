from pathlib import Path
import os,sys,json,time,subprocess,fcntl,traceback
root=Path(sys.argv[1]);status=root/'semantic_driver_status.json';start=time.time();dirs=[Path('/data/chenkejun/CVPR/results/ovimap_aligned_main_onlinev2_20261101/gpu_locks'),Path('/data/chenkejun/CVPR/results/requested_fixedH_main_v2b_20261108/online/gpu_locks')];chosen=None
def write(x):q=status.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(status)
try:
 while chosen is None:
  for row in subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines():
   idx,uid,free,util=[x.strip() for x in row.split(',')]
   if int(free)<20000 or int(util)>15:continue
   fs=[]
   try:
    for d in dirs:
     d.mkdir(parents=True,exist_ok=True);f=(d/(uid+'.lock')).open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);fs.append(f)
    chosen=(idx,uid,fs);break
   except BlockingIOError:
    for f in fs:fcntl.flock(f,fcntl.LOCK_UN);f.close()
  if chosen is None:write({'status':'WAITING_GPU','elapsed':time.time()-start});time.sleep(15)
 idx,uid,fs=chosen;env={**os.environ,'CUDA_VISIBLE_DEVICES':uid,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','LD_LIBRARY_PATH':'/data/chenkejun/CVPR/libs/p1a1_roi_cropformer_zoom_20261003/nvidia_580_126_09'};env.pop('PYTHONPATH',None);t=time.time();write({'status':'RUNNING','stage':'BACKGROUND070','gpu_index':int(idx),'gpu_uuid':uid,'gpu_wait_seconds':t-start})
 with (root/'semantic_driver.log').open('ab') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u','/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet400_frontend/semantic_worker.py',str(root)],env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 write({'status':'PASS' if rc==0 else 'FAILED','returncode':rc,'gpu_index':int(idx),'gpu_uuid':uid,'seconds':time.time()-t,'wall_seconds':time.time()-start,'scope':'background screening only'})
except BaseException:write({'status':'FAILED','traceback':traceback.format_exc()});raise
finally:
 if chosen:
  for f in chosen[2]:fcntl.flock(f,fcntl.LOCK_UN);f.close()
