from pathlib import Path
import os,sys,json,time,subprocess,traceback,hashlib
import numpy as np
m,n,g=sys.argv[1],int(sys.argv[2]),sys.argv[3];root=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/scannet400')/m/'scene0011_00'/str(n)/g;C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet400_frontend')/m/'scene0011_00'/str(n)/g;front=root/'candidates/frontend';start=time.time()
def dump(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def state(s,**kw):dump(root/'candidate_frontend_status.json',dict(status=s,method=m,checkpoint=n,group=g,elapsed_seconds=time.time()-start,scope='candidate proposal inference only; no fixedH, temporal tracking, repair',**kw))
try:
 catalog=root/'candidates/catalog/scene0011_00/candidate_manifest.json';launch=json.loads((root/'catalog_build_launch.json').read_text())
 while not catalog.exists():
  if not Path('/proc',str(launch['pid'])).exists():raise RuntimeError('candidate catalog process exited: '+(root/'catalog_build.log').read_text()[-2500:])
  state('WAITING_CATALOG');time.sleep(10)
 d=json.loads(catalog.read_text());expected=list(range(500,(n-1)*5+1,5));assert d['no_GT_used'] and d['candidate_search_frame_ids']==expected and d['previous_committed_checkpoint']==100
 state('RUNNING',stage='prepare_candidate_inputs');env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4'}
 with (root/'candidate_prepare.log').open('ab') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(C/'frontend/prepare_inputs.py')],cwd=C/'frontend',env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 if rc:raise RuntimeError('prepare failed, see candidate_prepare.log')
 manifest=json.loads((front/'input_manifest.json').read_text());control=next(j for j in manifest['jobs'] if j['kind']=='control');fid=control['frame'];assert fid in expected
 sel=json.loads((root/'candidates/selection_prefix.json').read_text());row=next(r for r in sel['rows'] if r['frame']==fid)
 src=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/source_rgbd/scene0011_00');rgb=src/'color'/f"{row['original_frame']}.jpg";digest=hashlib.sha256(rgb.read_bytes()).hexdigest();assert digest==row['rgb_sha256']
 dump(front/'native_control.json',dict(frame=fid,path=str(rgb),sha256=digest,original_frame=row['original_frame']))
 sys.path.insert(0,'/home/chenkejun/CVPR/experiments/p1a1_scannet_20261008/snapshot/revisable_instance_map/src');from revisable_instance_map.scannet_frame_io import color_coordinates
 mx,my=color_coordinates(src,640,480);np.savez_compressed(front/'native_control_map.npz',map_x=mx,map_y=my)
 driver=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet_sam3_candidate_driver.py');samout=front/'run_sam3';samout.mkdir(exist_ok=True)
 with (samout/'launcher.log').open('ab',buffering=0) as f:p1=subprocess.Popen(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(driver),str(samout),str(C/'frontend/infer_sam.py')],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
 cropout=front/'run_cropformer';cropout.mkdir(exist_ok=True);cropdriver=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet400_frontend/crop_driver.py')
 with (cropout/'launcher.log').open('ab',buffering=0) as f:p2=subprocess.Popen(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(cropdriver),str(cropout),str(C/'frontend/infer_cropformer.py')],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
 state('RUNNING',stage='PARALLEL_SAM3_AND_CROPFORMER_PROPOSALS',sam3_pid=p1.pid,cropformer_pid=p2.pid,jobs=len(manifest['jobs']),control_frame=fid)
 while True:
  statuses=[]
  for out,p in [(samout,p1),(cropout,p2)]:
   fp=out/'driver_status.json';s=json.loads(fp.read_text()) if fp.exists() else {'status':'STARTING'}
   if s['status']=='FAILED' or (p.poll() is not None and s['status']!='PASS'):raise RuntimeError(str(out)+' failed '+str(s))
   statuses.append(s['status'])
  if all(s=='PASS' for s in statuses):break
  time.sleep(20)
 state('RUNNING',stage='candidate_summary');
 with (root/'candidate_summary.log').open('ab') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(C/'frontend/summarize_frontend.py')],cwd=C/'frontend',env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 if rc:raise RuntimeError('summary failed, see candidate_summary.log')
 assert json.loads((front/'pipeline_complete.json').read_text())['status']=='PASS'
 state('PASS',stage='CANDIDATE_PROPOSALS_ONLY',tracking_complete=False,repair_complete=False)
except BaseException:state('FAILED',traceback=traceback.format_exc());raise
