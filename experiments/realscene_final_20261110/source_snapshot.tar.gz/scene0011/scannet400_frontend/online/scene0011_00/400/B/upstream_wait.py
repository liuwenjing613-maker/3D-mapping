from pathlib import Path
import sys,json,time,subprocess,traceback
root=Path(sys.argv[1]);worker=Path(sys.argv[2]);out=root/'upstream_wait_status.json'
def put(x):
 q=out.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(out)
try:
 while True:
  p=root/'candidate_frontend_status.json';d=json.loads(p.read_text()) if p.exists() else {'status':'WAITING'}
  if d['status']=='FAILED':raise RuntimeError('frontend failed: '+str(d))
  if d['status']=='PASS':break
  put({'status':'WAITING_FRONTEND'});time.sleep(15)
 put({'status':'RUNNING','stage':'upstream'})
 with (root/'upstream_wait.log').open('a') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(worker),'online','400','B'],stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 if rc:raise RuntimeError('upstream failed')
 put({'status':'PASS'})
except BaseException:put({'status':'FAILED','traceback':traceback.format_exc()});raise
