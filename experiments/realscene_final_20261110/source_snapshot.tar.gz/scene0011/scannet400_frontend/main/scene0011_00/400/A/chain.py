from pathlib import Path
import os,sys,json,time,traceback,subprocess
root=Path(sys.argv[1]);c=Path(sys.argv[2]);globalc=Path(sys.argv[3]);s=root/'screen_chain_status.json';started=time.time()
def put(x):q=s.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(s)
def run(stage,cmd):
 put({'status':'RUNNING','stage':stage,'elapsed':time.time()-started})
 with (root/(stage+'_chain.log')).open('a') as f:rc=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'})
 if rc:raise RuntimeError(stage+' failed exit '+str(rc))
try:
 marker=root/'approved_upstream_status.json'
 while True:
  d=json.loads(marker.read_text()) if marker.exists() else {'status':'WAITING'}
  if d['status']=='FAILED':raise RuntimeError('upstream failed: '+str(d))
  if d['status']=='PASS':break
  put({'status':'WAITING_UPSTREAM','elapsed':time.time()-started});time.sleep(15)
 py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
 run('medoids',[py,'-B','-u',str(globalc.parent/'scannet_medoids_worker.py'),str(root)])
 run('semantic',[py,'-B','-u',str(globalc/'semantic_launcher.py'),str(root)])
 run('fixedH',[py,'-B','-u',str(c/'fixedH_wait.py'),str(root),str(c/'fixedH_geometry.py')])
 put({'status':'PASS','stage':'SCREENING_ONLY','elapsed':time.time()-started})
except BaseException:put({'status':'FAILED','traceback':traceback.format_exc(),'elapsed':time.time()-started});raise
