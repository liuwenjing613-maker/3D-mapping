from pathlib import Path
import json,time,subprocess,sys,traceback
root=Path(sys.argv[1]);code=Path(sys.argv[2]);out=root/'fixedH_driver_status.json'
def put(x):out.write_text(json.dumps(x,indent=2)+'\n')
try:
 while True:
  ss=[]
  for p in [root/'candidates/background070/status.json',root/'candidates/visibility/status.json']:
   d=json.loads(p.read_text()) if p.exists() else {'status':'WAITING'}
   if d['status']=='FAILED':raise RuntimeError(str(p)+' failed: '+str(d))
   ss.append(d['status'])
  if all(x=='PASS' for x in ss):break
  put({'status':'WAITING','stages':ss});time.sleep(10)
 put({'status':'RUNNING','stage':'FIXED_H_GEOMETRY'})
 with (root/'fixedH_geometry.log').open('a') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(code)],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 if rc:raise RuntimeError('fixedH geometry failed; see fixedH_geometry.log')
 put({'status':'PASS','stage':'SCREENING_ONLY_NOT_TRACKING_OR_REPAIR'})
except Exception:put({'status':'FAILED','traceback':traceback.format_exc()});raise
