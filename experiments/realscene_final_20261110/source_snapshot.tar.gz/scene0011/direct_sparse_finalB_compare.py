"""User-requested immediate paired final-B comparison on existing sparse map."""
from pathlib import Path
import sys,os,json,time,hashlib,traceback,concurrent.futures,subprocess
import numpy as np
ROOT=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');OUT=ROOT/'direct_post_sparse';MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');SCENES=['room0','room1','room2','office0','office1','office2','office3','office4'];PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';sys.path.insert(0,'/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/policies/main');from scene_completion.pipeline import write_scene_complete,finalize
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+f'.{os.getpid()}.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');q.replace(p)
def cli(args,log):
 env={**os.environ,'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None);env.pop('CVPR_ONLINE_GUARD',None)
 with log.open('a') as f:subprocess.run([PY,'-B','-u','-m','unified_eval.cli',*map(str,args)],cwd=MAIN,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
def one(scene):
 start=time.time();dest=OUT/scene;dest.mkdir(parents=True,exist_ok=True);freeze=read(ROOT/'replica_main_evaluation_r2'/scene/'prediction_freeze.json');repair=read(ROOT/'replica_repair_exec'/scene/'repair/repair_complete.json');audit=read(ROOT/'replica_baseline_frame_audit'/scene/'complete.json');assert repair['status']=='PASS' and repair['mapping_frames']==400 and repair['GT_used'] is False and audit['status']=='PASS' and audit['frames']==400
 before=Path(freeze['baseline']);after=Path(freeze['source']);assert sha(before)==freeze['baseline_sha256'] and sha(after)==freeze['source_sha256'];geom=Path('/data/chenkejun/CVPR/revisable_instance_map/replica8_p0_main')/scene/'geometry/surface.ply';assert geom.is_file()
 with np.load(before) as a,np.load(after) as b:
  np.testing.assert_array_equal(a['xyz_m'],b['xyz_m']);np.testing.assert_array_equal(a['rgb'],b['rgb'])
 prior=read(ROOT/'replica_main_evaluation_r2'/scene/'new_raw/adapter_manifest.json');lock=read(MAIN/'unified_eval/configs/current_protocol.json');assert lock['profile_revision']==2 and lock['evaluable_GT_count']==350 and prior['gt_file_sha256']==lock['canonical_GT'][scene]['file_sha256'] and sha(prior['gt_file'])==prior['gt_file_sha256']
 outputs={}
 for arm,p in [('before',before),('after',after)]:
  work=dest/arm;work.mkdir(parents=True,exist_ok=True);base=p.parent.parent;native=base/'native/instance_surface.npz';ev=(base/'surface_evidence.npz') if arm=='before' else (base/'native/surface_evidence.npz');inputs=dict(surface=p,native=native,evidence=ev,normal_geometry=geom);assert all(q.is_file() for q in inputs.values())
  manifest=work/'scene_complete.json'
  if not manifest.exists():write_scene_complete(manifest,scene=scene,workflow='no_repair' if arm=='before' else 'main',frame_ids=list(range(0,2000,5)),inputs=inputs,final_processing_complete=True,final_repair_complete=(arm=='after'))
  provenance=work/'provenance.json';write(provenance,dict(status='PASS',scene=scene,arm=arm,GT_used_for_repair=False,baseline='sparse original main one-vote',selection='user reviewed fixed-H, room0 H012 M0466',tracking_model='SAM3' if arm=='after' else None,actual_repair_computed=arm=='after',separate_repair_commit=False,source_repair_status=str(ROOT/'replica_repair_exec'/scene/'repair/repair_complete.json') if arm=='after' else None,scope='original sparse geometry; final B only; DBSCAN not yet run; not PPT full-depth benchmark'))
  write(dest/'status.json',dict(status='RUNNING',stage='FINAL_B_'+arm,scene=scene,elapsed_seconds=time.time()-start))
  receipt=finalize(manifest,work/'final_B');assert receipt['status']=='PASS';final=Path(receipt['final_surface']);adapter=work/'r2';cli(['adapt-surface','--gt',prior['gt_file'],'--surface',final,'--fixed-correspondence',prior['correspondence_cache'],'--source-provenance',provenance,'--method-name','sparse_fixedH_sam3_'+arm+'_final_B','--method-commit','fixedH_sam3_final_B_20261109','--out',adapter],work/'adapt.log');a=read(adapter/'adapter_manifest.json')
  for k in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256']:assert a[k]==prior[k],k
  outputs[arm]=dict(surface=str(final),surface_sha256=sha(final),adapter=str(adapter),gt=a['gt_file'],correspondence=a['correspondence_cache'],seconds_B=receipt.get('seconds'))
 pair=dest/'paired';cli(['eval-repair-pair','--gt',outputs['before']['gt'],'--before',Path(outputs['before']['adapter'])/'canonical_prediction.npz','--after',Path(outputs['after']['adapter'])/'canonical_prediction.npz','--out',pair],dest/'paired.log');result=dict(status='PASS',scene=scene,stage='FINAL_B_R2_BEFORE_DBSCAN',outputs=outputs,GT_used_for_repair=False,elapsed_seconds=time.time()-start,DBSCAN_complete=False,postprocess_final_B=True,sparse_geometry_not_PPT_full_depth=True);write(dest/'status.json',result);return scene,result
def main():
 started=time.time();OUT.mkdir(parents=True,exist_ok=True);write(OUT/'status.json',dict(status='RUNNING',stage='FINAL_B_AND_R2_BEFORE_DBSCAN',completed=[],started_unix=started));done=[]
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   fs={pool.submit(one,s):s for s in SCENES}
   for f in concurrent.futures.as_completed(fs):
    scene,_=f.result();done.append(scene);write(OUT/'status.json',dict(status='RUNNING',stage='FINAL_B_AND_R2_BEFORE_DBSCAN',completed=done,elapsed_seconds=time.time()-started))
  for arm in ['before','after']:
   rows=[]
   for s in SCENES:
    p=OUT/s/arm/'r2';a=read(p/'adapter_manifest.json');rows.append(dict(gt=a['gt_file'],prediction=str(p/'canonical_prediction.npz'),diagnostic_prediction=str(p/'diagnostic_support_prediction.npz')))
   dest=OUT/'pooled'/arm;dest.mkdir(parents=True,exist_ok=True);write(dest/'batch.json',{'scenes':rows});cli(['eval-batch','--scenes',dest/'batch.json','--out',dest],dest/'run.log');m=read(dest/'summary.json');assert m['CA_PRF1_0_5']['TP']+m['CA_PRF1_0_5']['FN']==350
  write(OUT/'status.json',dict(status='PASS',stage='FINAL_B_R2_BEFORE_DBSCAN',completed=done,elapsed_seconds=time.time()-started,evaluable_GT=350,DBSCAN_complete=False,scope='sparse original paired geometry, final B applied to both; no separate repair commit; not comparable as full-depth PPT final'))
 except BaseException:write(OUT/'status.json',dict(status='FAILED',completed=done,traceback=traceback.format_exc(),elapsed_seconds=time.time()-started,DBSCAN_complete=False));raise
if __name__=='__main__':main()
