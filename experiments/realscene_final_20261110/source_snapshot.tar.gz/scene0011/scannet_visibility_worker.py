from pathlib import Path
import os,sys,json,time,traceback,importlib.util
import numpy as np
from PIL import Image
root=Path(sys.argv[1]);out=root/'candidates/visibility';out.mkdir(parents=True,exist_ok=True);start=time.time()
def state(s,**kw):
 p=out/'status.json';q=p.with_suffix('.tmp');q.write_text(json.dumps(dict(status=s,elapsed_seconds=time.time()-start,**kw),indent=2)+'\n');q.replace(p)
try:
 method=root.parts[-4];n=int(root.parts[-2]);g=root.parts[-1];code=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109/scannet200')/method/'scene0011_00'/str(n)/g;raw=json.loads((code/'config.json').read_text());scene=Path(raw['source']['scene_root']);ids=list(range(0,(n-1)*5+1,5));poses=np.loadtxt(scene/raw['source']['trajectory']).reshape(-1,4,4);assert len(poses)>ids[-1]
 spec=importlib.util.spec_from_file_location('catalog_common',str(code/'catalog/common.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 with np.load(root/'candidates/baseline/final/instance_surface.npz') as z:xyz=z['xyz_m'].copy()
 frames=[]
 for num,fid in enumerate(ids,1):
  dst=out/f'f{fid:06d}.npz'
  if not dst.exists():
   depth=np.asarray(Image.open(scene/raw['source']['depth_pattern'].format(frame=fid)),np.float32)/raw['camera']['depth_png_units_per_meter'];valid,uv=mod.project_visible(xyz,poses[fid],depth,mod.camera_at(raw,fid));idx=np.flatnonzero(valid).astype(np.int32);np.savez_compressed(dst,vertex_index=idx,uv=uv[idx])
  frames.append(fid)
  if num%5==0 or num==len(ids):state('RUNNING',stage='PROJECT_DEPTH_VISIBLE_POINTS',frames=num,total=len(ids),last=fid)
 state('PASS',stage='CAUSAL_VISIBILITY_ONLY',frames=ids,total=len(ids),GT_used=False,tracking_or_repair=False)
except BaseException:state('FAILED',traceback=traceback.format_exc());raise
