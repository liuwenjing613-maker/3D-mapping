from prepare_attributes import attributes
from pathlib import Path
import sys,json,time,traceback,os
n=int(sys.argv[1]);p=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/scannet400_geometry')/'attributes/scene0011_00'/str(n);p.mkdir(parents=True,exist_ok=True);t=time.time()
def dump(x):(p/'driver_status.json').write_text(json.dumps(x,indent=2)+'\n')
dump(dict(status='RUNNING',frames=n,started_unix=t,pid=os.getpid(),GT_used=False))
try:
 attributes('scene0011_00',n);dump(dict(status='PASS',frames=n,wall_seconds=time.time()-t,GT_used=False,tracking_or_repair=False))
except Exception:dump(dict(status='FAILED',frames=n,traceback=traceback.format_exc()));raise
