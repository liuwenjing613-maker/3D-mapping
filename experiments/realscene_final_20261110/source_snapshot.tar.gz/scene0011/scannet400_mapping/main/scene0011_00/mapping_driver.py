from pathlib import Path
import os,subprocess,sys,time,json,traceback
from common_continue import *
root=ROOT;root.mkdir(parents=True,exist_ok=True);state=root/'mapping_driver_status.json';t=time.time()
def status(x,**kw):dump(state,dict(status=x,unix=time.time(),wall_seconds=time.time()-t,**kw))
base={**os.environ,'CVPR_MAPPING_RUN_ROOT':str(root),'CVPR_SURFACE_POLICY':'checkpoint','CVPR_SCENE':'scene0011_00','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4'};base.pop('PYTHONPATH',None);base.pop('CVPR_ONLINE_GUARD',None)
try:
 for stage,name in [('initialize','initialize_empty.py'),('mapping_setup','map_support.py'),('mapping','map_continue.py')]:
  if stage=='mapping' and (B/'mapping_complete.json').exists():continue
  env=dict(base)
  if stage=='mapping':env.update(CVPR_ONLINE_GUARD=str(B/'input_guard.json'),PYTHONPATH=str(CONT/'map_guard')+':'+str(CONT)+':'+str(CONT.parent.parent))
  with (root/(stage+'.log')).open('a') as f:
   p=subprocess.Popen([PY,'-B','-u',str(CONT/name)],cwd=CONT,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT);status('RUNNING',stage=stage,pid=p.pid,GT_used=False,tracking_or_repair=False);rc=p.wait()
  if rc:raise RuntimeError(stage+' failed exit '+str(rc))
 done=read(B/'mapping_complete.json');assert done['status']=='PASS' and done['frame_count']==CHECKPOINT and not done['repair_applied'] and not done['future_inputs_used'] and not done['GT_used']
 status('PASS',stage='CAUSAL_NO_REPAIR_MAPPING_ONLY',GT_used=False,tracking_or_repair=False)
except Exception:status('FAILED',traceback=traceback.format_exc(),tracking_or_repair=False);raise
