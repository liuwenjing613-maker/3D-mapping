from pathlib import Path
import os,sys,json,fcntl,subprocess
C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');O=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');m=sys.argv[1];n=int(sys.argv[2]);assert (m,n) in [('main',400),('online',100)]
with (O/(m+'_initial_mapping.lock')).open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 marker=O/'scannet400'/m/'scene0011_00'/str(n)/'B/mapping_driver_status.json'
 if marker.exists() and json.loads(marker.read_text()).get('status')=='PASS':sys.exit(0)
 attrs=O/'scannet400_geometry/attributes/scene0011_00'/str(n)/'driver_status.json'
 assert json.loads(attrs.read_text())['status']=='PASS'
 env={**os.environ,'CVPR_CHECKPOINT':str(n),'CVPR_TRACK_GROUP':'B','PYTHONDONTWRITEBYTECODE':'1'}
 subprocess.run(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B',str(C/'scannet400_mapping'/m/'scene0011_00/mapping_driver.py')],env=env,check=True)
