"""Original main offline anchor gate on fixed-H/SAM3 seeds. Does not repair."""
from pathlib import Path
import sys,json,hashlib,time,os,traceback,types
import numpy as np
from scipy.spatial import cKDTree
from PIL import Image
B=Path('/data/chenkejun/CVPR/results');R=B/'requested_fixedH_main_v2b_20261108';scene_id=sys.argv[1];OUT=R/'replica_original_gate'/scene_id;OUT.mkdir(parents=True,exist_ok=True);start=time.time()
old=Path('/home/chenkejun/CVPR/experiments/auto_v2_room0_20261019/e1_repair');sys.path.insert(0,str(old));import bootstrap
import run_batch as b
from instance_repair.cli import load_script
pure=load_script('_pure_gate_fixedh',Path('/home/chenkejun/CVPR/experiments/v15_main_offline400_20261105/main/room0/track_pure_gate.py'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def write(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2));os.replace(q,p)
try:
 prep_path=R/'replica_gate_geometry'/scene_id/'complete.json';prep=json.loads(prep_path.read_text());assert prep['status']=='PASS_SEED_GEOMETRY_ONLY' and not prep['missing_old_family'];assert sha(prep['baseline_surface'])==prep['baseline_surface_sha256'] and sha(prep['association_file'])==prep['association_sha256']
 class Scene:
  def __init__(self):
   with np.load(prep['baseline_surface']) as z:self.xyz=z['xyz_m'].copy()
   raw=Path('/data/chenkejun/CVPR/revisable_instance_map/p1a1_raw_replica8_20261002/native')/scene_id/'P1-A1/surface_p0'
   with np.load(raw/'instance_surface.npz') as z:np.testing.assert_array_equal(self.xyz,z['xyz_m'])
   report=json.loads((raw/'materialization_report.json').read_text());assert sha(prep['association_file'])==report['association_decisions_sha256'];self.records={x['frame_id']:x for x in report['frame_records']};assert sorted(self.records)==list(range(0,2000,5))
   self.tree=cKDTree(self.xyz.astype(np.float64));self.source=b.r.ReplicaFrameSource(Path('/data/chenkejun/CVPR/revisable_instance_map/replica8_p0_main')/scene_id/'configs/raw.json');self.lookup={}
   for line in Path(prep['association_file']).read_text().splitlines():
    x=json.loads(line);self.lookup[(int(x['frame_id']),int(x['mask_local_id']))]=int(x['instance_id'])
  def family_view(self,fid,frame,ids):
   p=Path(self.records[fid]['support_file']);assert sha(p)==self.records[fid]['support_sha256']
   with np.load(p) as z:old_local=np.unique(z['mask_local_id'])
   present=any(self.lookup[(fid,int(m))] in ids for m in old_local if int(m)>0)
   table=np.zeros(int(frame.mask_local.max())+1,dtype=np.int32)
   for m in np.unique(frame.mask_local):
    if m:table[m]=self.lookup[(fid,int(m))]
   mapped=table[frame.mask_local];return bool(present),(mapped>0)&~np.isin(mapped,ids)
 scene=Scene();policy=json.loads((old/'gate_policy.json').read_text());cases={};objects={};canonical={};tracking={}
 for r in prep['objects']:
  mid=r['mask_id'];tid=r['track_id'];case=mid;adapt=json.loads(Path(r['label_adaptation']).read_text());assert adapt['status']=='PASS_INPUT_ADAPTER_ONLY' and adapt['track_id']==tid
  p=Path(r['support_file']);assert sha(p)==r['support_sha256'];z=np.load(p);points=np.unique(z['surface_point_index'][z['track_id']==tid]);assert len(points)>0
  samples=points[np.linspace(0,len(points)-1,min(len(points),2048),dtype=int)];pad=policy['seed_surface_bbox_padding_m'];bounds=(scene.xyz[points].min(0)-pad,scene.xyz[points].max(0)+pad)
  cases[case]={'ids':[tid],'config':{'seed_frame':r['seed_frame'],'old_family_ids':[r['old_family_for_gate']]},'case':{'case_uid':case}};canonical[tid]=tid;objects[tid]={'track_id':tid,'case_uid':case,'canonical_track_id':tid,'points':points,'samples':samples,'bounds':bounds,'group_id':r['H_group'],'mask_id':mid,'old_family_id':r['old_family_for_gate'],'persistent_id':r['persistent_id']}
  labels=Path(r['label_adaptation']).parent/'labels';tracking[case]={x['frame']:{'label_file':str(labels/f"{x['frame']:06d}.png")} for x in adapt['mapping_frames']};assert sorted(tracking[case])==list(range(0,2000,5))
 write(OUT/'status.json',{'status':'RUNNING','stage':'ORIGINAL_ANCHOR_GATE_ONLY_NOT_REPAIR','scene':scene_id,'frames':0,'total':400,'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 def progress(n,total,seconds):write(OUT/'status.json',{'status':'RUNNING','stage':'ORIGINAL_ANCHOR_GATE_ONLY_NOT_REPAIR','scene':scene_id,'frames':n,'total':total,'elapsed_seconds':time.time()-start,'gate_seconds':seconds,'pid':os.getpid()})
 result=pure.evaluate(b,scene,cases,objects,canonical,policy,tracking,out=OUT,progress=progress);assert result['status']=='PASS' and len(result['frames'])==400
 result.update(scene=scene_id,stage='ORIGINAL_ANCHOR_GATE_ONLY_NOT_REPAIR',selection='fixed-H 0.4; room0 H012 manual M0466',model='SAM3',baseline='original main auto-v3-swap',gate_policy_sha256=sha(old/'gate_policy.json'),seed_geometry_sha256=sha(prep_path),GT_used=False,repair_executed=False,elapsed_seconds=time.time()-start)
 write(OUT/'frame_decisions.json',result);write(OUT/'status.json',{'status':'PASS','stage':'ORIGINAL_ANCHOR_GATE_ONLY_NOT_REPAIR','scene':scene_id,'frames':400,'elapsed_seconds':time.time()-start,'accepted_frames_by_track':result['counts']['accepted_frames_by_track']})
except BaseException:
 write(OUT/'status.json',{'status':'FAILED','stage':'ORIGINAL_ANCHOR_GATE_ONLY_NOT_REPAIR','scene':scene_id,'traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
