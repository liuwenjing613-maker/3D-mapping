from pathlib import Path
import os,sys,json,time,traceback,ast,re,types,hashlib,subprocess
import numpy as np
from scipy.spatial import cKDTree
from sklearn.cluster import DBSCAN
from no_mask_gate_commit_bootstrap import *
from scene_completion.core import complete
from scene_completion.pipeline import write_scene_complete,finalize
from revisable_instance_map.surface_evidence import reduce_surface_votes
ROOTRUN=RUN;OUT=ROOTRUN/'ablation_no_mask_gate_full_depth';scene=scene_id;arm=sys.argv[1];assert arm in ['before','after']
dest=OUT/'postprocess'/scene/arm;dest.mkdir(parents=True,exist_ok=True);started=time.time();status=dest/'status.json'
def dump(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');q.replace(p)
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def save(p,**d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.stem+'.tmp.npz');np.savez_compressed(q,**d);q.replace(p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def state(stage,**x):dump(status,dict(status='RUNNING',stage=stage,scene=scene,arm=arm,elapsed_seconds=time.time()-started,**x));print(stage,scene,arm,flush=True)
GUARD=Path('/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/ablations/dbscan_identity_completion_guarded_20261102/run_guarded_covisible.py');t=GUARD.read_text();tree=ast.parse(t);cfg=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='CFG' for x in n.targets));CFG=eval(compile(ast.Expression(cfg.value),str(GUARD),'eval'),{'dict':dict})
for name in ['strict','encode','voxel_reps','build_candidates','replay_votes','fill_gray']:
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);code=ast.get_source_segment(t,node)
 if name=='build_candidates':
  code=code.replace("branch=Path(pixel).parents[2];scene_root=branch.parents[1];group=branch.name", "scene_root=HISTORY;group='A'")
  code=code.replace('for cp in [50,100,200,300,400]:','for cp in CHECKPOINTS:')
 if name=='replay_votes':code=code.replace("(root/'repair/partial/transactions').glob('f*.npz')","TRANSACTIONS.glob('f*.npz')")
 exec(compile(code,str(GUARD),'exec'),globals())
O=Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101');HISTORY=OUT/'post_layout'/scene;CHECKPOINTS=[400] if arm=='after' else []
def ensure_inputs():
 if arm=='after':
  cp=ROOT/'repair/commit_complete.json';pixel=ROOT/'repair/commit_candidate/source_pixel_support.npz'
  while not cp.exists():
   log=ROOT/'repair_driver_status.json'
   if log.exists() and read(log).get('status')=='FAILED':raise RuntimeError('Actual full-depth repair commit failed; see '+str(log))
   state('WAITING_REAL_REPAIR_COMMIT');time.sleep(15)
  receipt=read(cp);assert receipt['status']=='PASS' and receipt['source_pixel_support_sha256']==sha(pixel)
  h=HISTORY/'400/A';h.mkdir(parents=True,exist_ok=True);link=h/'repair'
  if not link.exists():link.symlink_to(ROOT/'repair',target_is_directory=True)
  assert link.resolve()==(ROOT/'repair').resolve();return pixel
 d=OUT/'postprocess_inputs/no_repair'/scene
 while not (d/'status.json').exists() or read(d/'status.json')['status']=='RUNNING':state('WAITING_BASELINE_SOURCE_PIXEL_EXPORT');time.sleep(15)
 assert read(d/'status.json')['status']=='PASS' and read(d/'status.json')['all_sampled_voxels_exact'];return d/'source_pixel_support.npz'
def main():
 global TRANSACTIONS
 pixel=ensure_inputs();state('LOAD_AND_VERIFY_INPUTS');srcpath=ROOT/'mapping/baseline/final/instance_surface.npz' if arm=='before' else ROOT/'repair/partial/whole_to_partial'/scene/'final/instance_surface.npz';assert srcpath.exists();src=load(srcpath);baseline=r.Scene(scene);xyz=src['xyz_m'];rgb=src['rgb'];np.testing.assert_array_equal(xyz,baseline.xyz);np.testing.assert_array_equal(rgb,baseline.rgb)
 native=srcpath.parent.parent/'native';evpath=(srcpath.parent.parent/'surface_evidence.npz') if arm=='before' else native/'surface_evidence.npz';pairpath=(srcpath.parent.parent/'surface_instance_frame_votes.npz') if arm=='before' else native/'surface_instance_frame_votes.npz';pair=load(pairpath);ev=load(evpath);pr=dest/'pre_dbscan';pr.mkdir(exist_ok=True);geom=ROOT/'mapping/geometry/surface.ply';write_scene_complete(pr/'scene_complete.json',scene=scene,workflow='no_repair' if arm=='before' else 'main',frame_ids=FIDS,inputs=dict(surface=srcpath,native=native/'instance_surface.npz',evidence=evpath,normal_geometry=geom),final_processing_complete=True,final_repair_complete=arm=='after');receipt=finalize(pr/'scene_complete.json',pr/'final_B');final=load(receipt['final_surface']);np.testing.assert_array_equal(final['xyz_m'],xyz)
 if arm=='after':base=int(read(ROOT/'repair/global_association.json')['instance_base']);TRANSACTIONS=ROOT/'repair/partial/transactions'
 else:base=max(int(pair['instance_id'].max()),int(src['instance_id'].max()),int(final['instance_id'].max()))+1;TRANSACTIONS=dest/'transactions';TRANSACTIONS.mkdir(exist_ok=True)
 assert int(pair['instance_id'].max())<base
 old=reduce_surface_votes(encode(pair,base),pair['frame_votes'],len(xyz),base,2,.67)
 for key in r.FIELDS:np.testing.assert_array_equal(old[key],ev[key])
 ctl,_,_=complete(xyz,baseline.normals,src['instance_id'],old);np.testing.assert_array_equal(ctl,final['instance_id']);del ctl
 if arm=='before':
  state('REBUILD_BASELINE_FRAME_VOTES')
  for fid in FIDS:
   sup=baseline.support(fid);ok=sup['candidate_persistent_id']>0;raw=np.unique(sup['surface_point_index'][ok].astype(np.int64)*base+sup['candidate_persistent_id'][ok]);keys=strict(raw,base);save(TRANSACTIONS/f'f{fid:06d}.npz',whole_to_partial_candidate_keys=raw,whole_to_partial_frame_keys=keys);baseline._support.pop(fid,None)
  assert len(list(TRANSACTIONS.glob('f*.npz')))==400
 state('DBSCAN_GUARDED_MERGE');lut,decisions=build_candidates(xyz,final['instance_id'],pair,pixel,dest)
 if len(lut)<base:lut=np.r_[lut,np.arange(len(lut),base,dtype=np.int32)]
 if decisions['families']:
  kk,vv,mp=replay_votes(ROOT,pair,base,lut,dest);merged=reduce_surface_votes(kk,vv,len(xyz),base,2,.67)
 else:merged=old;mp=pair;dump(dest/'frame_replay_audit.json',dict(status='PASS',no_identity_changes=True,original_votes_reused=True))
 lab=src['instance_id'].copy();assigned=lab>0;lab[assigned]=lut[lab[assigned]];was=old['state']==2;now=merged['state']==2;lab[was&~now]=-1;lab[now]=merged['top1_instance_id'][now]
 merge=dest/'merge_only';merge.mkdir(exist_ok=True);save(merge/'pre_B.npz',xyz_m=xyz,rgb=rgb,instance_id=lab);save(merge/'native.npz',xyz_m=xyz,rgb=rgb,instance_id=np.where(now,merged['top1_instance_id'],-1).astype(np.int32));save(merge/'evidence.npz',xyz_m=xyz,rgb=rgb,**merged)
 geom=ROOT/'mapping/geometry/surface.ply';write_scene_complete(merge/'scene_complete.json',scene=scene,workflow='no_repair' if arm=='before' else 'main',frame_ids=FIDS,inputs=dict(surface=merge/'pre_B.npz',native=merge/'native.npz',evidence=merge/'evidence.npz',normal_geometry=geom),final_processing_complete=True,final_repair_complete=arm=='after');receipt=finalize(merge/'scene_complete.json',merge/'final_B');labels=load(receipt['final_surface'])['instance_id']
 state('DBSCAN_GUARDED_FILL');norm=baseline.normals;valid=np.isfinite(norm).all(axis=1)&(np.linalg.norm(norm,axis=1)>.5)&np.isfinite(xyz).all(axis=1);labels=fill_gray(xyz,norm,valid,labels,merged,mp,dest);save(dest/'instance_surface.npz',xyz_m=xyz,rgb=rgb,instance_id=labels)
 state('R2_EVALUATION');prov=dest/'provenance.json';dump(prov,dict(status='PASS',scene=scene,arm=arm,stage='original_guarded_covisible_DBSCAN',source_pixel_support=str(pixel),GT_used_for_decision=False,offline_main=arm=='after',real_repair_commit=(arm=='after'),baseline='full-depth incremental TSDF, same fixed seeds, no tracked-mask gate',normal_valid='finite original PLY normals with norm > 0.5',configuration=CFG))
 original=read(Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101/evaluation/main')/scene/'r2/adapter_manifest.json');main=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'};env.pop('PYTHONPATH',None)
 with (dest/'evaluation.log').open('w') as f:subprocess.run([py,'-B','-m','unified_eval.cli','adapt-surface','--gt',original['gt_file'],'--surface',str(dest/'instance_surface.npz'),'--fixed-correspondence',original['correspondence_cache'],'--source-provenance',str(prov),'--method-name','sparse_fixedH_'+arm+'_DBSCAN','--method-commit','fixedH_sam3_no_mask_gate_guarded_dbscan_20261109','--out',str(dest/'r2')],cwd=main,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
 adapted=read(dest/'r2/adapter_manifest.json')
 for k in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256']:assert adapted[k]==original[k],k
 dump(status,dict(status='PASS',stage='DBSCAN_AND_R2_COMPLETE',scene=scene,arm=arm,source=str(dest/'instance_surface.npz'),sha256=sha(dest/'instance_surface.npz'),families=decisions['families'],elapsed_seconds=time.time()-started,GT_used_for_decision=False));print('PASS',scene,arm,flush=True)
try:main()
except BaseException:dump(status,dict(status='FAILED',scene=scene,arm=arm,elapsed_seconds=time.time()-started,traceback=traceback.format_exc()));raise
