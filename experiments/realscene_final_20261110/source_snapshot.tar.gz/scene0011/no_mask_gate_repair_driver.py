from pathlib import Path
import os,sys,time,json,subprocess,traceback,fcntl
scene=sys.argv[1];C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');O=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/ablation_no_mask_gate_full_depth');root=O/'repair_exec'/scene;state=root/'repair_driver_status.json';start=time.time();slot=None
def read(p):return json.loads(p.read_text())
def dump(x):q=state.with_name(state.name+'.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(state)
def status(st,**kw):dump(dict(status=st,scene=scene,elapsed_seconds=time.time()-start,**kw))
try:
 p=root/'prepare_status.json'
 while True:
  x=read(p) if p.exists() else {}
  if x.get('status')=='FAILED':raise RuntimeError('no-gate input preparation failed: '+x.get('traceback','')[-1000:])
  if x.get('status')=='PASS':break
  status('WAITING_INPUT',stage='UNGATED_MASK_PREPARATION');time.sleep(15)
 locks=O/'cpu_slots';locks.mkdir(exist_ok=True)
 while slot is None:
  for n in range(8):
   f=(locks/(str(n)+'.lock')).open('a')
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);slot=f;break
   except BlockingIOError:f.close()
  if slot is None:status('WAITING_CPU_SLOT');time.sleep(15)
 env={**os.environ,'CVPR_SCENE':scene,'CVPR_TRACK_GROUP':'A','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None)
 for stage,code in [('REPAIR','no_mask_gate_repair_'+scene+'.py'),('COMMIT','no_mask_gate_commit_'+scene+'.py')]:
  status('RUNNING',stage=stage)
  with (root/(stage.lower()+'.log')).open('a') as f:subprocess.run(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(C/code)],cwd=C,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
  target=root/'repair'/('repair_complete.json' if stage=='REPAIR' else 'commit_complete.json');assert read(target)['status']=='PASS'
 status('PASS',stage='NO_MASK_GATE_REPAIR_AND_REAL_COMMIT',mask_gate_applied=False,GT_used=False)
except BaseException:status('FAILED',stage='NO_MASK_GATE_REPAIR_OR_COMMIT',traceback=traceback.format_exc());raise
finally:
 if slot:fcntl.flock(slot,fcntl.LOCK_UN);slot.close()
