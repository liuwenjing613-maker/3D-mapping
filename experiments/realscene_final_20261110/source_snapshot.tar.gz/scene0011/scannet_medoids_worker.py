from pathlib import Path
import os,sys,json,time,traceback,importlib.util,itertools,hashlib
import numpy as np
from sklearn.linear_model import LogisticRegression
root=Path(sys.argv[1]);src=root/'candidates/grouping_r2';out=root/'candidates/medoids';out.mkdir(parents=True,exist_ok=True);start=time.time()
def write(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');q.replace(p)
try:
 audit=json.loads((src/'audit.json').read_text());assert audit['status']=='PASS';data=json.loads((src/'grouping.json').read_text());seeds=data['seeds']
 with np.load(src/'pair_metrics.npz') as z:I=z['iou'];inter=z['intersection'];union=z['union']
 assert I.shape==(len(seeds),len(seeds)) and np.allclose(I,inter/union)
 spec=importlib.util.spec_from_file_location('medoids_original','/home/chenkejun/CVPR/experiments/offline_kmedoids_unified_20261108/replay.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 groups=[];train=[]
 for g in data['groups']:
  inds=sorted(g['members'],key=lambda i:seeds[i]['id']);D=1-I[np.ix_(inds,inds)];assert np.allclose(D,D.T) and np.allclose(np.diag(D),0);f=mod.fit(D);groups.append((g,inds,D,f))
  if len(inds)>=3:
   for i,j in itertools.combinations(range(len(inds)),2):train.append((float(D[i,j]),int(f['labels'][i]!=f['labels'][j])))
 x=np.asarray([[a] for a,b in train]);y=np.asarray([b for a,b in train]);assert set(y)=={0,1},'no both pseudo-label classes for pair classifier'
 model=LogisticRegression(C=1.0,solver='lbfgs',max_iter=1000,tol=1e-10,random_state=0);model.fit(x,y);outgroups=[];seen=set()
 for g,inds,D,f in groups:
  ids=[seeds[i]['id'] for i in inds];assert not(seen&set(ids));seen.update(ids);centers=f['centers'][:];labels=np.asarray(f['labels']).copy();prob=None;reason=f['reason']
  if len(ids)==2:
   prob=float(model.predict_proba([[float(D[0,1])]])[0,1])
   if prob>.5:centers=[0,1];labels=np.array([0,1]);reason='learned_different'
   else:reason='learned_same'
  clusters=[]
  for k,c in enumerate(centers):
   members=[ids[i] for i in np.flatnonzero(labels==k)];assert ids[c] in members;clusters.append({'number':k+1,'representative':ids[c],'members':members})
  outgroups.append({'id':g['id'],'primary':seeds[g['primary']]['id'],'members':ids,'clusters':clusters,'silhouette':f['silhouette'],'reason':reason,'pair_different_score':prob})
 assert len(seen)==len(seeds);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 result={'status':'PASS','stage':'MEDOIDS_ONLY','scope':'equal weights; IoU distance; two-mask score learned from other groups in same checkpoint, >=3 masks; no GT','groups':outgroups,'summary':{'groups':len(groups),'input':len(seeds),'representatives':sum(len(g['clusters']) for g in outgroups),'training_pairs':len(train),'training_classes':{str(k):int(sum(y==k)) for k in set(y)}},'classifier':{'coef':float(model.coef_[0,0]),'intercept':float(model.intercept_[0]),'source':'other groups in same causal checkpoint'},'source_grouping':str(src/'grouping.json'),'source_sha256':sha(src/'grouping.json'),'elapsed_seconds':time.time()-start,'GT_used':False,'tracking_or_repair':False}
 write(out/'result.json',result);write(out/'status.json',{k:v for k,v in result.items() if k!='groups'})
except BaseException:write(out/'status.json',dict(status='FAILED',stage='MEDOIDS_ONLY',traceback=traceback.format_exc()));raise
