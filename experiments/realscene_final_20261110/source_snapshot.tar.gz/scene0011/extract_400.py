from pathlib import Path
import json,struct,hashlib,zlib,time,traceback,os
import numpy as np
from PIL import Image
B=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');R=B/'scannet400_input_raw';R.mkdir(parents=True,exist_ok=True)
src=Path('/data/chenkejun/datasets/ScanNet/scans/scene0011_00/scene0011_00.sens');sel=json.loads((B/'scannet0011_400_selection.json').read_text());wanted={n:i for i,n in enumerate(sel['original_frames'])};assert len(wanted)==400
status=R/'status.json';start=time.time()
def write(p,obj):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,ensure_ascii=False,indent=2));os.replace(t,p)
def exact(f,n):
 b=f.read(n)
 if len(b)!=n:raise EOFError((len(b),n))
 return b
def num(f,fmt):return struct.unpack('<'+fmt,exact(f,struct.calcsize(fmt)))[0]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for k in ('rgb','depth','pose'):(R/k).mkdir(exist_ok=True)
 rows=[]
 with src.open('rb') as f:
  version=num(f,'I');name=exact(f,num(f,'Q')).decode('utf8','replace');mats=[np.frombuffer(exact(f,64),dtype='<f4').reshape(4,4).copy() for _ in range(4)]
  cc=num(f,'i');dc=num(f,'i');cw=num(f,'I');ch=num(f,'I');dw=num(f,'I');dh=num(f,'I');shift=num(f,'f');nf=num(f,'Q');assert version==4 and cc==2 and dc==1 and nf==2374,(version,cc,dc,nf)
  for i in range(nf):
   pose=np.frombuffer(exact(f,64),dtype='<f4').reshape(4,4).copy();tc=num(f,'Q');td=num(f,'Q');nc=num(f,'Q');nd=num(f,'Q')
   if i not in wanted:f.seek(nc+nd,1);continue
   ordinal=wanted[i];color=exact(f,nc);depth=exact(f,nd);assert color[:2]==b'\xff\xd8' and color[-2:]==b'\xff\xd9';arr=np.frombuffer(zlib.decompress(depth),dtype='<u2').reshape(dh,dw);assert np.isfinite(pose).all()
   rgb=R/'rgb'/f'{ordinal:06d}.jpg';dep=R/'depth'/f'{ordinal:06d}.png';pos=R/'pose'/f'{ordinal:06d}.txt'
   rgb.write_bytes(color);Image.fromarray(arr).save(dep);np.savetxt(pos,pose,fmt='%.9g')
   rows.append({'ordinal':ordinal,'original_frame':i,'virtual_frame':5*ordinal,'rgb_sha256':sha(rgb),'depth_sha256':sha(dep),'pose_sha256':sha(pos),'timestamp_color':tc,'timestamp_depth':td})
   if len(rows)%20==0:write(status,{'status':'RUNNING','stage':'raw_input_extraction','completed':len(rows),'total':400,'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 assert len(rows)==400 and [r['original_frame'] for r in rows]==sel['original_frames']
 write(R/'manifest.json',{'status':'PASS_RAW_ONLY','source_sens':str(src),'selection':str(B/'scannet0011_400_selection.json'),'frame_count':len(rows),'color_size':[cw,ch],'depth_size':[dw,dh],'depth_shift':shift,'intrinsics_extrinsics':[m.tolist() for m in mats],'frames':rows,'elapsed_seconds':time.time()-start,'next_stage':'calibrated RGB-depth alignment and map building; NOT repair'})
 write(status,{'status':'PASS','stage':'raw_input_extraction','completed':400,'elapsed_seconds':time.time()-start,'pid':os.getpid(),'not_repair':True})
except BaseException:
 write(status,{'status':'FAILED','stage':'raw_input_extraction','elapsed_seconds':time.time()-start,'error':traceback.format_exc()});raise
