from pathlib import Path
import os,sys,json,fcntl,subprocess,time,hashlib,traceback
root=Path(sys.argv[1]);code=Path(sys.argv[2]);cfg=root/'inference_config.json';out=root/'raw_masks';state=root/'baseline_cropformer_status.json';locks=Path('/data/chenkejun/CVPR/results/requested_fixedH_main_v2b_20261108/online/gpu_locks');locks.mkdir(parents=True,exist_ok=True);start=time.time()
def dump(d):
 q=state.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(state)
chosen=None
while not chosen:
 rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
 for row in rows:
  idx,uid,free,util=[x.strip() for x in row.split(',')]
  if int(idx) not in (0,2,3,5,6,7) or int(free)<14000 or int(util)>20:continue
  lock=(locks/(uid+'.lock')).open('a')
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:lock.close();continue
  chosen=(uid,lock,int(idx));break
 if not chosen:dump(dict(status='WAITING_GPU',seconds=time.time()-start));time.sleep(15)
uid,lock,idx=chosen;tick=time.time();env={**os.environ,'CUDA_VISIBLE_DEVICES':uid,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','PYTHONDONTWRITEBYTECODE':'1','LD_LIBRARY_PATH':'/data/chenkejun/CVPR/libs/p1a1_roi_cropformer_zoom_20261003/nvidia_580_126_09','CUDA_CACHE_PATH':str(root/'runtime_cache/cuda'),'XDG_CACHE_HOME':str(root/'runtime_cache'),'MPLCONFIGDIR':str(root/'runtime_cache/mpl')};env.pop('PYTHONPATH',None)
dump(dict(status='RUNNING',gpu_uuid=uid,gpu_index=idx,gpu_wait_seconds=tick-start))
try:
 with (root/'baseline_cropformer.log').open('a') as f:rc=subprocess.call(['/data/chenkejun/ovimap_runtime_20260908/envs/cropformer/bin/python','-B','-u',str(code),'--config',str(cfg)],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=code.parent)
 if rc:raise RuntimeError('inference exit '+str(rc))
 data=json.loads((root/'selection.json').read_text());m=root/'masks';m.mkdir(exist_ok=True);records=[]
 def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
 for row in data['rows']:
  fid,original=row['frame'],row['original_frame'];mask=out/(str(original)+'.png');t=m/('frame%06d.png'%fid)
  if not t.exists():t.symlink_to(mask)
  rec=json.loads((out/'records'/(str(original)+'.json')).read_text());assert rec['input_sha256']==row['rgb_sha256'] and rec['mask_sha256']==sha(mask)
  rec.update(frame=fid,original_frame=original);records.append(rec)
 (m/'frames.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in records));(m/'complete.json').write_text(json.dumps(dict(status='PASS',frames=len(records),selection_sha256=sha(root/'selection.json'),source='new exact original CropFormer baseline inference, no repair',GT_used=False),indent=2)+'\n')
 dump(dict(status='PASS',frames=len(records),gpu_uuid=uid,gpu_index=idx,gpu_wait_seconds=tick-start,seconds=time.time()-tick,wall_seconds=time.time()-start,tracking_or_repair=False))
except Exception:dump(dict(status='FAILED',traceback=traceback.format_exc(),gpu_uuid=uid,gpu_index=idx));raise
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
