from pathlib import Path
import os,sys,json,time,subprocess,traceback,ast
R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/scannet200/online/scene0011_00/200/B');E=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');src=Path(sys.argv[1]);start=time.time();status=R/'post_mapping_setup_status.json'
def put(d):q=status.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(status)
try:
 while True:
  p=R/'mapping_driver_status.json';d=json.loads(p.read_text()) if p.exists() else {'status':'WAITING'}
  if d['status']=='FAILED':raise RuntimeError('mapping failed '+str(d))
  if d['status']=='PASS':break
  put({'status':'WAITING_MAPPING','elapsed_seconds':time.time()-start});time.sleep(20)
 for name in ['catalog','front','chain']:
  p=src/(name+'_200.py');put({'status':'RUNNING','stage':'SETUP_'+name,'elapsed_seconds':time.time()-start})
  with (R/('setup_'+name+'.log')).open('ab') as f:rc=subprocess.call(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(p)],env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
  if rc:raise RuntimeError('setup '+name+' failed exit '+str(rc))
 put({'status':'PASS','stage':'FINAL_NODE_CHAIN_LAUNCHED_NOT_REPAIR','elapsed_seconds':time.time()-start})
except BaseException:put({'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
