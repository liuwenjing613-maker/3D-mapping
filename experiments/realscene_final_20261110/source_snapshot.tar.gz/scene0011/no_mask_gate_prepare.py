from pathlib import Path
import os,sys,json,time,traceback,hashlib
import numpy as np
from PIL import Image
BASE=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');scene=sys.argv[1];original=BASE/'replica_full_depth_fixed_selection/repair_exec'/scene;root=BASE/'ablation_no_mask_gate_full_depth/repair_exec'/scene;T=root/'tracking';gate=T/'gate';out=gate/'accepted_masks';out.mkdir(parents=True,exist_ok=True);start=time.time()
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/auto_v2_room0_20261019/e1_repair');import run_batch as b
def read(p):return json.loads(Path(p).read_text())
def put(p,x):q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');q.replace(p)
def link(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if not dst.exists():dst.symlink_to(src.resolve(),target_is_directory=src.is_dir())
 assert dst.resolve()==src.resolve()
def status(x,**kw):put(root/'prepare_status.json',dict(status=x,scene=scene,elapsed_seconds=time.time()-start,**kw))
try:
 assert read(original/'repair/commit_complete.json')['status']=='PASS';assert read(original/'tracking/tracking_queue_complete.json')['model']=='SAM3'
 T.mkdir(parents=True,exist_ok=True)
 for name in ['seed_diagnostics.json','global_association.json','seed_manifest.json','seed_id_map.json','input_freeze.json','cases','tracking_queue_complete.json']:link(original/'tracking'/name,T/name)
 link(original/'mapping',root/'mapping');cases=read(T/'seed_diagnostics.json')['cases'];objects={};canonical={}
 for case in cases:
  uid=case['case_uid'];tr=read(T/'cases'/uid/'tracking/complete.json');assert tr['status']=='PASS' and tr['model']=='SAM3' and tr['total_frames']==1996
  rows={int(z['frame']):z for z in tr['frames']};assert sorted(rows)==list(range(0,2000,5))
  for ob in case['objects']:
   tid=int(ob['track_id']);assert tid not in objects;objects[tid]=rows;canonical[tid]=tid
 assert len(objects)==read(T/'seed_manifest.json')['selected_masks'];gated={x['frame']:x for x in read(original/'tracking/gate/frame_decisions.json')['frames']};records=[];counts={'nonempty_masks':0,'gated_accepted':0,'extra_nongated':0,'overlap_abstention_pixels':0,'frames':400};status('RUNNING',stage='BUILD_UNGATED_MASKS',frames=0,total=400)
 for n,fid in enumerate(range(0,2000,5),1):
  masks=[];accepted=[]
  for tid,rows in objects.items():
   row=rows[fid];data=Path(row['label_file']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['label_sha256'];from io import BytesIO
   arr=np.asarray(Image.open(BytesIO(data)));assert arr.shape==(680,1200);mask=arr==tid
   if mask.any():masks.append((tid,mask));accepted.append(tid)
  if masks:merged,conflict=b.j.merge_foregrounds(masks,canonical)
  else:merged=np.zeros((680,1200),np.uint16);conflict=np.zeros((680,1200),bool)
  assert set(np.unique(merged))<={0,*accepted}
  Image.fromarray(merged.astype(np.uint16)).save(out/f'f{fid:06d}.png');old=set(map(int,gated[fid]['accepted_track_ids']));raw=set(accepted);counts['nonempty_masks']+=len(raw);counts['gated_accepted']+=len(old);counts['extra_nongated']+=len(raw-old);counts['overlap_abstention_pixels']+=int(conflict.sum());records.append({'frame':fid,'accepted_track_ids':sorted(raw),'policy':'all nonempty SAM3 tracked masks; no quality/view gate','cross_case_conflict_pixels':int(conflict.sum())})
  if n%25==0:status('RUNNING',stage='BUILD_UNGATED_MASKS',frames=n,total=400)
 put(gate/'frame_decisions.json',{'status':'PASS','stage':'UNGATED_TRACK_MASKS_INPUT_ONLY','frames':records,'counts':counts,'mask_gate_applied':False,'overlap_policy':'original merge_foregrounds; conflicting pixels abstained','GT_used':False});put(T/'gate_complete.json',{'status':'PASS','objects':len(objects),'mask_gate_applied':False,'source':str(gate/'frame_decisions.json')});status('PASS',stage='UNGATED_TRACK_MASK_INPUTS_READY',counts=counts,GT_used=False);print('PASS',scene,counts,flush=True)
except BaseException:status('FAILED',stage='PREPARE_UNGATED_INPUTS',traceback=traceback.format_exc());raise
