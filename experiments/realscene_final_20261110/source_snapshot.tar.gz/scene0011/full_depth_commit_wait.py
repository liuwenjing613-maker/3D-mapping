from pathlib import Path
import os,sys,json,time,subprocess,traceback
scene=sys.argv[1];C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');root=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/replica_full_depth_fixed_selection/repair_exec')/scene;state=root/'commit_driver_status.json';t=time.time()
def dump(d):q=state.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(state)
try:
 while True:
  p=root/'runner_status.json';x=json.loads(p.read_text()) if p.exists() else {}
  if x.get('status')=='FAILED':raise RuntimeError('repair failed '+x.get('traceback','')[-1500:])
  if x.get('status')=='PASS':break
  dump({'status':'WAITING_REPAIR','elapsed_seconds':time.time()-t});time.sleep(20)
 code=C/('full_depth_commit_'+scene+'.py');env={**os.environ,'CVPR_SCENE':scene,'CVPR_TRACK_GROUP':'A','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'};env.pop('PYTHONPATH',None)
 dump({'status':'RUNNING','stage':'REAL_REPAIR_COMMIT_AND_SOURCE_PIXEL_PROVENANCE','elapsed_seconds':time.time()-t})
 with (root/'commit_driver.log').open('a') as f:subprocess.run(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(code)],cwd=C,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
 receipt=json.loads((root/'repair/commit_complete.json').read_text());assert receipt['status']=='PASS'
 dump({'status':'PASS','stage':'REAL_REPAIR_COMMIT','elapsed_seconds':time.time()-t,'receipt':str(root/'repair/commit_complete.json')})
except BaseException:dump({'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-t});raise
