"""Freeze selected SAM3 gate geometry on the original main fixed surface.

This is preparation only: no gate, vote changes, map repair or evaluation.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,os,time,traceback,collections
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/p1a1_raw_replica8_20261002/snapshot/revisable_instance_map/src')
from revisable_instance_map.frame_io import ReplicaFrameSource
from revisable_instance_map.surface_evidence import project_frame_regions
B=Path('/data/chenkejun/CVPR/results');R=B/'requested_fixedH_main_v2b_20261108';scene=sys.argv[1];OUT=R/'replica_gate_geometry'/scene;OUT.mkdir(parents=True,exist_ok=True);start=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2));os.replace(t,p)
try:
 manifest=json.loads((R/'replica_repair_input_manifest'/f'{scene}.json').read_text());assert manifest['status']=='VALIDATED_TRACKING_INPUT_ONLY_NOT_REPAIR'
 group=json.loads((B/'replica8_swap34_20261020'/scene/'v1/grouping.json').read_text());paths=[p for p in group['source_sha256'] if p.endswith('/final/instance_surface.npz')];assert len(paths)==1;surface=Path(paths[0]);assert sha(surface)==group['source_sha256'][str(surface)]
 with np.load(surface,allow_pickle=False) as z:xyz=z['xyz_m'].copy();labels=z['instance_id'].copy();inventory=z['native_instance_ids'].copy()
 assert len(xyz)==len(labels);tree=cKDTree(xyz.astype(np.float64));config=Path('/data/chenkejun/CVPR/revisable_instance_map/replica8_p0_main')/scene/'configs/raw.json';source=ReplicaFrameSource(config)
 assoc=Path('/data/chenkejun/CVPR/revisable_instance_map/p1a1_raw_replica8_20261002/native')/scene/'P1-A1/association/associations.jsonl';assert assoc.exists();lookup={};oldmax=max(int(np.max(inventory)),int(np.max(labels)))
 for line in assoc.read_text().splitlines():
  x=json.loads(line);key=(int(x['frame_id']),int(x['mask_local_id']));assert key not in lookup;lookup[key]=int(x['instance_id']);oldmax=max(oldmax,int(x['instance_id']))
 track={x['mask_id']:x for x in json.loads((R/'replica_gate_label_inputs/complete.json').read_text())['cases'] if x['scene']==scene};assert len(track)==len(manifest['seeds']);used=set();result=[]
 for r in manifest['seeds']:
  mid=r['mask_id'];adapt=json.loads(Path(track[mid]['path']).read_text());tid=adapt['track_id'];assert adapt['H_group']==r['H_group'] and adapt['seed_frame']==r['seed_frame'];seed=np.asarray(Image.open(r['source_mask']))>0;assert sha(r['source_mask'])==r['source_mask_sha256'];fid=r['seed_frame'];frame=source.load_frame(fid);lab=np.where(seed,tid,0).astype(np.uint16);pts,lcl,stats=project_frame_regions(replace(frame,mask_local=lab),tree,pixel_stride=2,max_distance_m=.015,workers=2);assert len(pts)>0 and np.all(lcl==tid) and np.all(pts<len(xyz));unique=np.unique(pts)
  vals,nums=np.unique(frame.mask_local[seed],return_counts=True);hist=collections.Counter()
  for v,n in zip(vals,nums):
   if int(v)>0:hist[lookup[(fid,int(v))]]+=int(n)
  family=min(hist,key=lambda k:(-hist[k],k)) if hist else None
  # Persistent identity derives solely from the user-confirmed pre-filter ID preview.
  preview=r['id_preview'];pid=int(preview['preview_id']) if preview['action']=='inherit' else oldmax+tid
  assert pid>0 and pid<=65535 and pid not in used;used.add(pid)
  if preview['action']=='inherit':assert pid<=oldmax and preview['best_dice']>.5
  else:assert pid>oldmax
  p=OUT/f'{mid}_seed_projected_support.npz';np.savez_compressed(p,surface_point_index=pts,track_id=lcl)
  result.append({'mask_id':mid,'track_id':tid,'H_group':r['H_group'],'seed_frame':fid,'projected_points':len(unique),'support_file':str(p),'support_sha256':sha(p),'projection_stats':stats,'old_family_for_gate':family,'old_family_pixel_counts':dict(hist),'family_distinct_from_assigned_id':True,'persistent_id':pid,'id_preview':preview,'label_adaptation':track[mid]['path']})
  write(OUT/'status.json',{'status':'RUNNING','stage':'FIXED_SURFACE_SEED_PROJECTION_NOT_REPAIR','scene':scene,'completed':len(result),'total':len(manifest['seeds']),'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 report={'status':'PASS_SEED_GEOMETRY_ONLY','scene':scene,'baseline_surface':str(surface),'baseline_surface_sha256':sha(surface),'association_file':str(assoc),'association_sha256':sha(assoc),'prior_max_id':oldmax,'points':len(xyz),'objects':result,'missing_old_family':[x['mask_id'] for x in result if x['old_family_for_gate'] is None],'selection_sha256':sha(R/'replica_repair_input_manifest'/f'{scene}.json'),'elapsed_seconds':time.time()-start,'GT_used':False,'gate_executed':False,'repair_executed':False};write(OUT/'complete.json',report);write(OUT/'status.json',{'status':'PASS','scene':scene,'stage':'FIXED_SURFACE_SEED_PROJECTION_NOT_REPAIR','completed':len(result),'elapsed_seconds':time.time()-start})
except BaseException:
 write(OUT/'status.json',{'status':'FAILED','scene':scene,'stage':'FIXED_SURFACE_SEED_PROJECTION_NOT_REPAIR','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
