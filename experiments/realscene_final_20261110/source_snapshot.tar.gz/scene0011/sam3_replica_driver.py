"""Run approved offline Replica SAM3 seed tracking; no map modification."""
from pathlib import Path
import os,json,time,subprocess,hashlib,fcntl,traceback
B=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');C=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');R=B/'replica_sam3_tracking';R.mkdir(exist_ok=True);start=time.time()
def write(p,obj):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(obj,ensure_ascii=False,indent=2));os.replace(t,p)
def free_gpus():
 q=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True)
 return {int(a.strip()):int(b.strip()) for line in q.splitlines() for a,b in [line.split(',')]}
def env(gpu):return dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',LIBRARY_PATH='/data/chenkejun/CVPR/envs/sam3_cuda_link',PYTHONPATH='/data/chenkejun/CVPR/envs/sam3_compat:/home/chenkejun/CVPR/repos/sam3-main')
lock=(R/'driver.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 assert json.loads((B/'sam3_smoke/status.json').read_text())['status']=='PASS'
 sel=json.loads((B/'selection_manifest.json').read_text())['selections'];jobs=[]
 for scene,rs in sel.items():
  src=Path('/home/chenkejun/beauty/conceptgraphs/data/Replica')/scene/'results';video=R/scene/'rgb';video.mkdir(parents=True,exist_ok=True)
  for i in range(1996):
   target=src/f'frame{i:06d}.jpg';dest=video/f'{i:06d}.jpg';assert target.is_file(),target
   if not dest.exists():dest.symlink_to(target)
  for row in rs:
   p=Path('/data/chenkejun/CVPR/results/replica8_swap34_20261020')/scene/'v1/masks'/f'{row["mask_id"]}.png';assert hashlib.sha256(p.read_bytes()).hexdigest()==row['mask_sha256'];jobs.append((scene,row['mask_id']))
 assert len(jobs)==122
 pending=[];running={};done=[];fail=[]
 for scene,mid in jobs:
  q=R/scene/mid/'status.json'
  if q.exists() and json.loads(q.read_text()).get('status')=='PASS':
   info=json.loads(q.read_text());files=R/scene/mid/'masks';assert len(list(files.glob('*.png')))==1996 and info['directions']['forward']['count']+info['directions']['backward']['count']==1995;done.append({'scene':scene,'mask':mid,'status':'PASS','resumed_verified':True})
  else:pending.append((scene,mid))
 while pending or running:
  for gpu,(proc,scene,mid,log) in list(running.items()):
   if proc.poll() is None:continue
   log.close();p=R/scene/mid/'status.json';s=json.loads(p.read_text()) if p.exists() else {'status':'FAILED','error':'no status'}
   item={'scene':scene,'mask':mid,'gpu':gpu,'returncode':proc.returncode,'status':s.get('status')};(done if proc.returncode==0 and s.get('status')=='PASS' else fail).append(item);del running[gpu]
  if fail:raise RuntimeError('SAM3 tracking failed; stopped scheduling further seeds: '+str(fail))
  avail=free_gpus()
  for gpu in sorted(avail):
   if not pending:break
   if gpu in running or avail[gpu]<43000:continue
   scene,mid=pending.pop(0);out=R/scene/mid;out.mkdir(exist_ok=True);log=(out/'driver.log').open('ab');p=subprocess.Popen(['/data/chenkejun/CVPR/envs/dualmap_torch27/bin/python','-B','-u',str(C/'sam3_replica_seed.py'),scene,mid],cwd=C,env=env(gpu),stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True);running[gpu]=(p,scene,mid,log)
  write(R/'driver_status.json',{'status':'RUNNING','stage':'SAM3_TRACKING_ONLY_NOT_REPAIR','input_seeds':len(jobs),'finished':len(done),'pending':len(pending),'running':[{'scene':s,'mask':m,'gpu':g,'pid':p.pid} for g,(p,s,m,_) in running.items()],'failed':fail,'elapsed_seconds':time.time()-start,'driver_pid':os.getpid()})
  time.sleep(10)
 write(R/'driver_status.json',{'status':'PASS','stage':'SAM3_TRACKING_ONLY_NOT_REPAIR','completed':done,'elapsed_seconds':time.time()-start})
except BaseException:
 write(R/'driver_status.json',{'status':'FAILED','stage':'SAM3_TRACKING_ONLY_NOT_REPAIR','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
