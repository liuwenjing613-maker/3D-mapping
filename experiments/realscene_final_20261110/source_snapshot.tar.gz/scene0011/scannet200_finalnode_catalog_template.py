from pathlib import Path
import os,json,subprocess,shutil,time,ast
E=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');D=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/scannet200');O=Path('/home/chenkejun/CVPR/experiments/scannet_repair_50_120_200_20261106/online/scene0011_00/selection_code/120/B');OD=Path('/data/chenkejun/CVPR/results/scannet_repair_50_120_200_20261106/online/scene0011_00/120/B/candidates');root=D/'online/scene0011_00/120/B';B=root/'mapping';cand=root/'candidates';C=E/'scannet200/online/scene0011_00/120/B';d=json.loads((B/'mapping_complete.json').read_text());assert d['status']=='PASS' and d['frame_count']==120 and not d['GT_used'] and not d['future_inputs_used'];prior=json.loads((B/'prior_commit.json').read_text());assert prior['processed_frames']==50 and prior['prior_commit_path'].startswith(str(D))
cand.mkdir(exist_ok=True);C.mkdir(parents=True,exist_ok=True)
for name in ['baseline','geometry','association','inputs','mapping_complete.json']:
 src=B/name;dst=cand/name;assert src.exists()
 if not dst.exists():dst.symlink_to(src.resolve(),target_is_directory=src.is_dir())
if not (C/'config.json').exists():(C/'config.json').symlink_to((B/'config.json').resolve())
if not (C/'catalog').exists():shutil.copytree(O/'catalog',C/'catalog',ignore=shutil.ignore_patterns('__pycache__'))
for p in (C/'catalog').glob('*.py'):
 s=p.read_text().replace(str(OD),str(cand)).replace(str(O),str(C));ast.parse(s);p.write_text(s)
assert not (root/'catalog_launch.json').exists()
with (root/'catalog.log').open('ab',buffering=0) as f:x=subprocess.Popen(['/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python','-B','-u',str(C/'catalog/build_candidates.py'),'scene0011_00'],cwd=C/'catalog',env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(root/'catalog_launch.json').write_text(json.dumps({'pid':x.pid,'started':time.time(),'scope':'120 causal catalog after 50 commit'})+'\n');print('catalog120',x.pid)
