from pathlib import Path
import json,sys,importlib.util,copy,hashlib
import numpy as np
from PIL import Image
root=Path(sys.argv[1]);old=root/'candidates/background070/result.json';out=root/'candidates/background_tuned';out.mkdir(exist_ok=True)
d=json.loads(old.read_text());assert d['status']=='PASS'
ref=json.loads(Path('/data/chenkejun/CVPR/results/offline_medoids_background070_20261108/room0/classification.json').read_text())
cfg=copy.deepcopy(ref['config']);cfg['pixel_confidence']=.55;cfg['mask_fraction']=.60
spec=importlib.util.spec_from_file_location('frozen_semantics','/home/chenkejun/CVPR/experiments/offline_medoids_background_20261108/replay.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
labels,_=mod.resolve_labels(ref['model']['id2label'],cfg);cache={};records=[]
for r in d['records']:
 p=Path(r['cache']);assert hashlib.sha256(p.read_bytes()).hexdigest()==r['cache_sha256']
 if str(p) not in cache:
  with np.load(p) as z:cache[str(p)]=(z['labels'].copy(),z['confidence'].copy())
 maskpath=root/'candidates/grouping_r2/masks'/(r['mask_id']+'.png')
 assert hashlib.sha256(maskpath.read_bytes()).hexdigest()==r['mask_sha256']
 mask=np.asarray(Image.open(maskpath))>0
 info=mod.summarize_mask(*cache[str(p)],mask,labels,cfg)
 records.append({**r,**{k:info[k] for k in ['decision','exclude','top_class','high_excluded_fraction']}})
d.update(records=records,retained_candidates=[r for r in records if not r['exclude']],threshold_config=cfg,stage='BACKGROUND055_FRACTION060_CACHE_RECLASSIFICATION',GT_used=False,tracking_or_repair=False)
d['summary']={'input':len(records),'retained':len(d['retained_candidates']),'excluded':sum(r['exclude'] for r in records)}
(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');(out/'status.json').write_text(json.dumps({'status':'PASS','parameters':{'pixel_confidence':.55,'mask_fraction':.60},'GT_used':False})+'\n')
print('BACKGROUND',d['summary'])
