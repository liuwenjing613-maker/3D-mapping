from pathlib import Path
import os,sys,json,fcntl,subprocess,time,traceback
out=Path(sys.argv[1]);code=Path(sys.argv[2]);locks=Path('/data/chenkejun/CVPR/results/requested_fixedH_main_v2b_20261108/online/gpu_locks');locks.mkdir(parents=True,exist_ok=True)
state=out/'driver_status.json';start=time.time()
def dump(x):
 q=state.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(state)
chosen=None
while not chosen:
 rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
 for row in rows:
  idx,uid,free,util=[x.strip() for x in row.split(',')]
  if int(idx) not in (0,2,3,5,6,7) or int(free)<14000 or int(util)>20:continue
  lock=(locks/(uid+'.lock')).open('a')
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:lock.close();continue
  chosen=(uid,lock,idx);break
 if not chosen:dump(dict(status='WAITING_GPU',elapsed_seconds=time.time()-start));time.sleep(15)
uid,lock,idx=chosen;start_infer=time.time();env={**os.environ,'CUDA_VISIBLE_DEVICES':uid,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'4','OMP_NUM_THREADS':'4','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','PYTHONPATH':'/home/chenkejun/CVPR/repos/sam2_1:/data/chenkejun/CVPR/envs/sam3_compat:/home/chenkejun/CVPR/repos/sam3-main','LD_LIBRARY_PATH':'/data/chenkejun/CVPR/envs/sam3_cuda_link:/data/chenkejun/CVPR/libs/p1a1_roi_cropformer_zoom_20261003/nvidia_580_126_09','XDG_CACHE_HOME':str(out/'cache'),'CUDA_CACHE_PATH':str(out/'cache/cuda'),'MPLCONFIGDIR':str(out/'cache/mpl')}
wrapper="import sys,runpy;sys.path.extend(['/home/chenkejun/beauty/conceptgraphs/envs/cg-main/lib/python3.10/site-packages','/home/chenkejun/beauty/conceptgraphs/envs/cg-ali/lib/python3.10/site-packages']);sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name='__main__')"
dump(dict(status='RUNNING',gpu_uuid=uid,gpu_index=int(idx),gpu_wait_seconds=start_infer-start,started_unix=start_infer))
try:
 with (out/'sam3.log').open('a') as f:rc=subprocess.call(['/data/chenkejun/CVPR/envs/dualmap_torch27/bin/python','-B','-u','-c',wrapper,str(code)],cwd=code.parent,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 dump(dict(status='PASS' if rc==0 else 'FAILED',returncode=rc,gpu_uuid=uid,gpu_index=int(idx),gpu_wait_seconds=start_infer-start,seconds=time.time()-start_infer,wall_seconds=time.time()-start,tracking_or_repair=False))
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
