from pathlib import Path
import json,hashlib,os,time,traceback,concurrent.futures
import numpy as np
from PIL import Image
B=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');R=B/'replica_sam3_tracking';start=time.time();manifest=json.loads((B/'selection_manifest.json').read_text());jobs=[(scene,r) for scene,rows in manifest['selections'].items() for r in rows];assert len(jobs)==122
def write(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2));os.replace(t,p)
def audit(job):
 scene,r=job;mid=r['mask_id'];root=R/scene/mid;status=json.loads((root/'status.json').read_text());assert status['status']=='PASS' and status['scene']==scene and status['mask_id']==mid;anchor=r['frame'];assert status['seed_sha256']==r['mask_sha256'] and status['seed_frame']==anchor;assert status['directions']['forward']['count']==1995-anchor and status['directions']['backward']['count']==anchor
 files={p.name for p in (root/'masks').glob('*.png')};assert files=={f'{i:06d}.png' for i in range(1996)};source=Path('/data/chenkejun/CVPR/results/replica8_swap34_20261020')/scene/'v1/masks'/f'{mid}.png';assert hashlib.sha256(source.read_bytes()).hexdigest()==r['mask_sha256'];seed=np.asarray(Image.open(source))>0;actual=np.asarray(Image.open(root/'masks'/f'{anchor:06d}.png'))>0;assert np.array_equal(seed,actual)
 frames=[]
 for i in range(0,1996,5):
  p=root/'masks'/f'{i:06d}.png';data=p.read_bytes();im=np.asarray(Image.open(p));assert im.shape==(680,1200) and im.dtype==np.uint8 and np.all((im==0)|(im==255));frames.append(dict(frame=i,sha256=hashlib.sha256(data).hexdigest(),pixels=int((im>0).sum())))
 return dict(scene=scene,mask_id=mid,seed_frame=anchor,seed_sha256=r['mask_sha256'],total_files=len(files),checked_mapping_frames=len(frames),frames=frames,elapsed_seconds=status['elapsed_seconds'],gpu=status['gpu'])
try:
 done=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  futures=[pool.submit(audit,j) for j in jobs]
  for f in concurrent.futures.as_completed(futures):
   done.append(f.result())
   if len(done)%5==0:write(R/'mapping_frame_audit_progress.json',{'status':'RUNNING','completed':len(done),'total':122,'seconds':time.time()-start,'pid':os.getpid()})
 done.sort(key=lambda r:(r['scene'],r['mask_id']));write(R/'mapping_frame_audit.json',{'status':'PASS','scope':'122 real SAM3 individual tracks, all 400 mapping-frame PNG contents, exact anchors, direction and 1996 file names; no repair or evaluation','GT_used':False,'cases':done,'seconds':time.time()-start,'summed_case_seconds':sum(x['elapsed_seconds'] for x in done),'note':'summed per-case GPU elapsed is not parallel wall time'});write(R/'mapping_frame_audit_progress.json',{'status':'PASS','completed':len(done),'total':122,'seconds':time.time()-start,'pid':os.getpid()})
except BaseException:
 write(R/'mapping_frame_audit_progress.json',{'status':'FAILED','traceback':traceback.format_exc(),'seconds':time.time()-start});raise
