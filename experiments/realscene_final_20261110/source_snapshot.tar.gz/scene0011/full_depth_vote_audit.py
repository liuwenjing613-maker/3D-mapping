from pathlib import Path
import json,time,sys,traceback,hashlib,numpy as np
r=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');u=Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101');scene=sys.argv[1];out=r/'replica_full_depth_fixed_selection/vote_audit'/scene;out.mkdir(parents=True,exist_ok=True);start=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(name,d):(out/name).write_text(json.dumps(d,indent=2)+'\n')
try:
 proj=json.loads((r/'replica_full_depth_fixed_selection/seed_reprojection'/scene/'result.json').read_text());assert proj['status']=='PASS';m=u/'main'/scene/'400/A/mapping';pair=m/'baseline/surface_instance_frame_votes.npz'
 with np.load(pair) as z:pp=z['surface_point_index'].astype(np.int64);pi=z['instance_id'].astype(np.int64);pv=z['frame_votes'].astype(np.int64)
 base=max(int(pi.max()),*[x['persistent_id'] for x in proj['objects']])+1;allkeys=[]
 for i,fid in enumerate(range(0,2000,5),1):
  f=m/'baseline/frame_support'/f'f{fid:06d}.npz'
  with np.load(f) as z:
   points=z['surface_point_index'].astype(np.int64);ids=z['candidate_persistent_id'].astype(np.int64);assert int(z['frame_id'][0])==fid and not z['repaired_source_pixel_journal'][0]
  assert (ids>0).all() and (ids<base).all();keys=np.unique(points*base+ids);_,inv,n=np.unique(keys//base,return_inverse=True,return_counts=True);allkeys.append(keys[n[inv]==1])
  if i%50==0:write('status.json',dict(status='RUNNING',frames=i,total=400,elapsed_seconds=time.time()-start))
 keys,counts=np.unique(np.concatenate(allkeys),return_counts=True);expected=pp*base+pi;order=np.argsort(expected);np.testing.assert_array_equal(keys,expected[order]);np.testing.assert_array_equal(counts,pv[order]);d=dict(status='PASS',stage='FULL_DEPTH_BASELINE_STRICT_VOTE_AUDIT',frames=400,instance_base=base,effective_votes=int(counts.sum()),surface_ID_pairs=len(keys),baseline_surface=proj['baseline_surface'],baseline_surface_sha256=proj['baseline_surface_sha256'],baseline_pair=str(pair),baseline_pair_sha256=sha(pair),GT_used=False,repair_executed=False,elapsed_seconds=time.time()-start);write('complete.json',d);write('status.json',d)
except BaseException:write('status.json',dict(status='FAILED',traceback=traceback.format_exc()));raise
