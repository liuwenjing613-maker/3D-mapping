"""Wait for full-depth input audits, then run the original offline repair."""
from pathlib import Path
import sys,json,hashlib,os,time,traceback,importlib.util
RUN=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');CODE=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');scene=sys.argv[1];os.environ['CVPR_SCENE']=scene;root=RUN/'replica_full_depth_fixed_selection/repair_exec'/scene;T=root/'tracking';out=root/'repair';T.mkdir(parents=True,exist_ok=True);started=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2));os.replace(q,p)
def read(p):return json.loads(Path(p).read_text())
try:
 gate=RUN/'replica_full_depth_fixed_selection/gate'/scene;baseline=RUN/'replica_full_depth_fixed_selection/vote_audit'/scene/'complete.json'
 while True:
  f=gate/'status.json';g=read(f) if f.exists() else {};a=read(baseline) if baseline.exists() else {};fail=RUN/'replica_full_depth_fixed_selection/vote_audit'/scene/'status.json';v=read(fail) if fail.exists() else {}
  if g.get('status')=='FAILED' or v.get('status')=='FAILED':raise RuntimeError('Gate or vote audit failed')
  if g.get('status')=='PASS' and a.get('status')=='PASS':break
  write(root/'runner_status.json',dict(status='WAITING_INPUT',gate=g.get('status'),baseline_audit=v.get('status'),elapsed_seconds=time.time()-started));time.sleep(20)
 dec=read(gate/'frame_decisions.json');assert dec['status']=='PASS' and not dec['GT_used'] and not dec['repair_executed'] and len(list((gate/'accepted_masks').glob('*.png')))==400
 gp=RUN/'replica_full_depth_fixed_selection/seed_reprojection'/scene/'result.json';proj=read(gp);assert proj['status']=='PASS';ba=read(baseline);assert ba['status']=='PASS'
 data=read(RUN/'replica_repair_input_manifest'/f'{scene}.json');byid={x['mask_id']:x for x in data['seeds']};group=read(Path('/data/chenkejun/CVPR/results/replica8_swap34_20261020')/scene/'v1/grouping.json');source={x['id']:x for x in group['seeds']};cases=[];seeds=[];association=[];idmap=[];seen=set()
 for x in proj['objects']:
  mid=x['mask_id'];tid=x['track_id'];pid=x['persistent_id'];u=source[mid];assert mid in byid and pid not in seen;seen.add(pid);a=read(x['tracking_adaptation']);assert a['status']=='PASS_INPUT_ADAPTER_ONLY' and a['track_id']==tid and a['H_group']==x['H_group'];case=T/'cases'/mid;(case/'tracking').mkdir(parents=True,exist_ok=True)
  labels=Path(x['tracking_adaptation']).parent/'labels';seed=labels/f"{x['seed_frame']:06d}.png"
  for dst,src in [(case/'prepared_seed.png',seed),(case/'seed_projected_support.npz',Path(x['gate_support']))]:
   if not dst.exists():dst.symlink_to(src)
   assert sha(dst)==sha(src)
  cfg={'schema_version':1,'scene':scene,'case_uid':mid,'seed_frame':x['seed_frame'],'old_family_ids':[x['old_family_for_gate']],'objects':[{'track_id':tid}],'H_group':x['H_group'],'selection_rule':'fixed old-reviewed H; full-depth ID rematch','tracking_model':'SAM3','GT_used':False};cp=case/'config.json';write(cp,cfg);rows=[]
  for v in a['mapping_frames']:
   p=labels/f"{v['frame']:06d}.png";assert sha(p)==v['label_sha256'];rows.append({'frame':v['frame'],'label_file':str(p),'label_sha256':v['label_sha256'],'areas':{str(tid):v['pixels']},'direction':'seed' if v['frame']==x['seed_frame'] else 'reverse' if v['frame']<x['seed_frame'] else 'forward'})
  assert [z['frame'] for z in rows]==list(range(0,2000,5))
  write(case/'tracking/complete.json',dict(status='PASS',case_uid=mid,GT_used=False,model='SAM3',track_ids=[tid],seed_frame=x['seed_frame'],seed_sha256=sha(seed),case_config_sha256=sha(cp),completed_frames=1996,total_frames=1996,frames=rows,frames_list_scope='400 mapping frames; all 1996 raw frames separately audited',directions_use_independent_seed_only_states=True,source_adapter_sha256=sha(x['tracking_adaptation'])))
  obj={'track_id':tid,'native_mask_id':int(u['representative']['label']),'mask_id':mid,'group_id':x['H_group'],'old_family_id':x['old_family_for_gate'],'projected_seed_points':x['projected_unique'],'seed_pixels':u['area']};choice={'ROI':x['H_group'],'frame':x['seed_frame'],'choice':'user_reviewed_mask_selection_from_sparse_map'};cases.append({'case_uid':mid,'source_choice':choice,'objects':[obj],'old_family_ids':[x['old_family_for_gate']],'config_path':str(cp)});seeds.append({'status':'READY','scene':scene,'case_uid':mid,'source_choice':choice,'objects':[obj],'seed_file':str(seed),'seed_sha256':sha(seed)});association.append({'canonical_track_id':tid,'member_track_ids':[tid],'persistent_id':pid,'association':'full_depth_best_dice_conflict','accepted_dice':x['id_candidates'][0]['dice'] if x['id_action']=='inherit' else None});idmap.append({'track_id':tid,'mask_id':mid,'group_id':x['H_group'],'persistent_id':pid})
 assert max(x['persistent_id'] for x in association)<ba['instance_base'];write(T/'seed_diagnostics.json',{'status':'PASS','cases':cases,'GT_used':False});write(T/'seed_manifest.json',{'status':'PASS','scene':scene,'seeds':seeds,'selected_masks':len(seeds),'GT_used':False});write(T/'seed_id_map.json',{'objects':idmap});write(T/'global_association.json',{'status':'PASS','GT_used':False,'objects':association,'instance_base':ba['instance_base'],'rule':'full-depth best Dice > .5, conflicts winner highest Dice; no second-best','aliases':{}});write(T/'input_freeze.json',{'status':'FROZEN_AFTER_TRACKING','selection_origin':'user-reviewed sparse geometry; not full-depth reselected','baseline_audit_sha256':sha(baseline),'gate_decisions_sha256':sha(gate/'frame_decisions.json'),'GT_used':False})
 for dst,src in [(T/'gate',gate),(root/'mapping',Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101/main')/scene/'400/A/mapping')]:
  if not dst.exists():dst.symlink_to(src,target_is_directory=True)
  assert dst.resolve()==src.resolve()
 write(T/'gate_complete.json',{'status':'PASS','objects':len(seeds),'source_gate_sha256':sha(gate/'frame_decisions.json')});write(T/'tracking_queue_complete.json',{'status':'PASS','model':'SAM3','objects':len(seeds),'source_audit_sha256':sha(RUN/'replica_sam3_tracking/mapping_frame_audit.json')});write(root/'package_complete.json',{'status':'PASS_GATE_INPUT_PACKAGE_ONLY','scene':scene,'objects':len(seeds),'GT_used':False,'repair_executed':False})
 src=Path('/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/main')/scene/'repair_continue.py';original=src.read_text();prefix="import sys\nsys.path.insert(0,'/home/chenkejun/CVPR/experiments/unified_full_depth_20261101')\nimport write_fence\n";assert original.startswith(prefix);adapted=original[len(prefix):].replace('from bootstrap_continue import *','from full_depth_bootstrap12 import *');dst=CODE/f'full_depth_repair_{scene}.py';dst.write_text(adapted)
 sys.path.insert(0,str(CODE));spec=importlib.util.spec_from_file_location('full_depth_repair_'+scene,dst);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert m.ROOT==root and m.R==out and m.TRACK==T
 def setup():
  out.mkdir(parents=True,exist_ok=True);expected=read(T/'seed_manifest.json')['selected_masks'];assert read(T/'gate_complete.json')['objects']==expected and read(T/'tracking_queue_complete.json')['status']=='PASS'
  for n in ['seed_diagnostics.json','global_association.json','seed_manifest.json','seed_id_map.json','input_freeze.json','cases']:
   p=out/n
   if not p.exists():p.symlink_to(T/n,target_is_directory=n=='cases')
   assert p.resolve()==(T/n).resolve()
  p=out/'validated/full_track';p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():p.symlink_to(T/'gate',target_is_directory=True)
  inputs=[T/'gate/frame_decisions.json',T/'global_association.json',T/'seed_manifest.json',T/'seed_diagnostics.json',gp,baseline]+list((T/'gate/accepted_masks').glob('*.png'));assert len(inputs)==406
  frozen={str(x):sha(x) for x in inputs};write(out/'repair_input_freeze.json',{'status':'FROZEN','scene':scene,'objects':expected,'source_hashes':frozen,'raw_cutoff':1995,'mapping_frame_count':400,'tracking_model':'SAM3','selection_origin':'sparse-geometry user-reviewed fixed masks; full-depth ID rematched','prior_repair_count':0,'GT_used':False,'adapted_from':str(src),'source_sha256':sha(src),'adapted_sha256':sha(dst)});return frozen
 m.setup=setup
 write(root/'runner_status.json',{'status':'RUNNING','stage':'FULL_DEPTH_ACTUAL_PARTIAL_CORE_E1_REPAIR','scene':scene,'start_unix':time.time(),'tracking':'SAM3','GT_used':False,'pid':os.getpid()});m.main();done=read(out/'repair_complete.json');assert done['status']=='PASS' and done['mapping_frames']==400
 write(root/'runner_status.json',{'status':'PASS','stage':'FULL_DEPTH_REPAIR_COMPUTED_NOT_COMMITTED','scene':scene,'elapsed_seconds':time.time()-started,'GT_used':False})
except BaseException:write(root/'runner_status.json',{'status':'FAILED','stage':'FULL_DEPTH_REPAIR','scene':scene,'traceback':traceback.format_exc(),'elapsed_seconds':time.time()-started});raise
