"""Adapt frozen original-main repair to validated fixed-H gate; isolated output."""
from pathlib import Path
import os,sys,json,time,hashlib,traceback,importlib.util
RUN=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');CODE=Path('/home/chenkejun/CVPR/experiments/scannet0011_threshold_transfer_20261109');scene=sys.argv[1];os.environ['CVPR_SCENE']=scene;root=RUN/'replica_repair_exec'/scene;T=root/'tracking';out=root/'repair';out.mkdir(parents=True,exist_ok=True);started=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2));os.replace(q,p)
try:
 package=json.loads((root/'package_complete.json').read_text());assert package['status']=='PASS_GATE_INPUT_PACKAGE_ONLY';baseline=json.loads((RUN/'replica_baseline_frame_audit'/scene/'complete.json').read_text());assert baseline['status']=='PASS';gate=json.loads((RUN/'replica_original_gate'/scene/'status.json').read_text());assert gate['status']=='PASS'
 src=Path('/home/chenkejun/CVPR/experiments/v15_main_offline400_20261105/main')/scene/'repair_continue.py';original=src.read_text();prefix="import sys\nsys.path.insert(0,'/home/chenkejun/CVPR/experiments/v15_main_offline400_20261105')\nimport write_fence\n";assert original.startswith(prefix);adapted=original[len(prefix):];assert adapted.count('from bootstrap_continue import *')==1;adapted=adapted.replace('from bootstrap_continue import *','from fixedh_bootstrap import *');dst=CODE/f'fixedh_repair_{scene}.py';dst.write_text(adapted)
 sys.path.insert(0,str(CODE));spec=importlib.util.spec_from_file_location('fixedh_repair_'+scene,dst);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert m.ROOT==root and m.R==out and m.TRACK==T
 def setup():
  expected=json.loads((T/'seed_manifest.json').read_text())['selected_masks'];assert json.loads((T/'gate_complete.json').read_text())['objects']==expected and json.loads((T/'tracking_queue_complete.json').read_text())['status']=='PASS'
  for n in ['seed_diagnostics.json','global_association.json','seed_manifest.json','seed_id_map.json','input_freeze.json','cases']:
   p=out/n
   if not p.exists():p.symlink_to(T/n,target_is_directory=n=='cases')
   assert p.resolve()==(T/n).resolve()
  p=out/'validated/full_track';p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():p.symlink_to(T/'gate',target_is_directory=True)
  inputs=[T/'gate/frame_decisions.json',T/'global_association.json',T/'seed_manifest.json',T/'seed_diagnostics.json',RUN/'replica_gate_geometry'/scene/'complete.json',RUN/'replica_baseline_frame_audit'/scene/'complete.json']+list((T/'gate/accepted_masks').glob('*.png'));assert len(inputs)==406
  frozen={str(x):sha(x) for x in inputs};write(out/'repair_input_freeze.json',{'status':'FROZEN','scene':scene,'objects':expected,'source_hashes':frozen,'raw_cutoff':1995,'mapping_frame_count':400,'tracking_model':'SAM3','fixed_H_and_ID_preview':True,'prior_repair_count':0,'GT_used':False,'adapted_from':str(src),'source_sha256':sha(src),'adapted_sha256':sha(dst)});return frozen
 m.setup=setup
 write(root/'runner_status.json',{'status':'RUNNING','stage':'ACTUAL_PARTIAL_CORE_E1_REPAIR','scene':scene,'start_unix':started,'tracking':'SAM3','baseline':'main offline auto-v3-swap','GT_used':False,'pid':os.getpid()})
 m.main();done=json.loads((out/'repair_complete.json').read_text());assert done['status']=='PASS' and done['mapping_frames']==400
 write(root/'runner_status.json',{'status':'PASS','stage':'REPAIR_COMPUTED_NOT_YET_PUBLISHED_OR_EVALUATED','scene':scene,'elapsed_seconds':time.time()-started,'GT_used':False})
except BaseException:
 write(root/'runner_status.json',{'status':'FAILED','stage':'ACTUAL_PARTIAL_CORE_E1_REPAIR','scene':scene,'traceback':traceback.format_exc(),'elapsed_seconds':time.time()-started});raise
