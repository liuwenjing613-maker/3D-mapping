from pathlib import Path
import os,sys,json,time,traceback,subprocess,hashlib
import numpy as np
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/policies/main')
from scene_completion.pipeline import write_scene_complete,finalize
R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109');O=R/'ablation_no_mask_gate_full_depth';G=R/'replica_full_depth_fixed_selection';MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');P='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';scene=sys.argv[1];root=O/'repair_exec'/scene;out=O/'pre_dbscan'/scene;out.mkdir(parents=True,exist_ok=True);start=time.time()
def read(p):return json.loads(p.read_text())
def dump(p,x):q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(x,indent=2)+'\n');q.replace(p)
try:
 while True:
  q=root/'repair/repair_complete.json';st=root/'repair_driver_status.json';x=read(st) if st.exists() else {}
  if x.get('status')=='FAILED':raise RuntimeError('repair failed '+x.get('traceback','')[-900:])
  if q.exists() and read(q).get('status')=='PASS':break
  dump(out/'status.json',{'status':'WAITING_REPAIR','scene':scene});time.sleep(15)
 src=root/'repair/partial/whole_to_partial'/scene;geom=root/'mapping/geometry/surface.ply';m=out/'scene_complete.json';write_scene_complete(m,scene=scene,workflow='main',frame_ids=list(range(0,2000,5)),inputs={'surface':src/'final/instance_surface.npz','native':src/'native/instance_surface.npz','evidence':src/'native/surface_evidence.npz','normal_geometry':geom},final_processing_complete=True,final_repair_complete=True);receipt=finalize(m,out/'final_B');new=Path(receipt['final_surface']);gate=G/'postprocess'/scene/'after/pre_dbscan/final_B/instance_surface.npz';assert gate.exists()
 with np.load(new) as a,np.load(gate) as b:np.testing.assert_array_equal(a['xyz_m'],b['xyz_m']);np.testing.assert_array_equal(a['rgb'],b['rgb'])
 prior=read(Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101/evaluation/main')/scene/'r2/adapter_manifest.json');env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'};env.pop('PYTHONPATH',None)
 for arm,surface in [('with_gate',gate),('without_gate',new)]:
  dest=out/arm;prov=out/(arm+'_provenance.json');dump(prov,{'status':'PASS','scene':scene,'arm':arm,'full_depth_geometry':True,'final_B':True,'DBSCAN':False,'commit':'gated completed; ungated may be in progress','GT_used_for_repair':False});args=[P,'-B','-m','unified_eval.cli','adapt-surface','--gt',prior['gt_file'],'--surface',str(surface),'--fixed-correspondence',prior['correspondence_cache'],'--source-provenance',str(prov),'--method-name','pre_dbscan_'+arm,'--method-commit','no_gate_preliminary_20261109','--out',str(dest)]
  with (out/(arm+'.log')).open('w') as f:subprocess.run(args,cwd=MAIN,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
  x=read(dest/'adapter_manifest.json')
  for k in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256']:assert x[k]==prior[k],k
 dump(out/'status.json',{'status':'PASS','stage':'PAIR_FINAL_B_BEFORE_DBSCAN','scene':scene,'elapsed_seconds':time.time()-start,'DBSCAN_complete':False,'not_new_full_depth_rescreen':True})
except BaseException:dump(out/'status.json',{'status':'FAILED','scene':scene,'traceback':traceback.format_exc()});raise
