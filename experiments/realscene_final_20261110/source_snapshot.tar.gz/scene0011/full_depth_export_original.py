from pathlib import Path
import os,sys,json,time,traceback,ast,hashlib
import numpy as np
from full_depth_commit_bootstrap import *
from revisable_instance_map.association import OnlineVoxelAssociator
from revisable_instance_map.observations import RawInstanceObservation,source_pixel_indices
src=Path('/home/chenkejun/CVPR/experiments/unified_full_depth_20261101/main/room0/commit_continue.py');text=src.read_text();node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='sample_pixels');exec(compile(ast.get_source_segment(text,node),str(src),'exec'))
scene=scene_id;out=RUN/'replica_full_depth_fixed_selection/postprocess_inputs/no_repair'/scene;out.mkdir(parents=True,exist_ok=True);state=out/'status.json';started=time.time()
try:
 mapping=Path('/data/chenkejun/CVPR/results/unified_full_depth_20261101/main')/scene/'400/A/mapping';ap=mapping/'association/observation_support_3cm.npz';assoc=OnlineVoxelAssociator.from_checkpoint(ap);assoc.identity_evidence.validate();source=r.ReplicaFrameSource(mapping/'config.json');obsfile=mapping/'association/observations.jsonl';obs={x['observation_id']:RawInstanceObservation(**x) for x in map(json.loads,obsfile.read_text().splitlines())};entries=sorted(assoc.observation_support.values(),key=lambda x:(x.frame_id,x.observation_id));pix=[];vox=[];layers=[];ids=[];fids=[];pids=[];fid=None;frame=None
 for k,e in enumerate(entries):
  if fid!=e.frame_id:fid=e.frame_id;frame=source.load_frame(fid)
  ob=obs[e.observation_id];assert ob.source_mask_sha256==e.source_mask_sha256
  p,v=sample_pixels(frame,ob,assoc);assert tuple(tuple(int(x) for x in row) for row in np.unique(v,axis=0))==e.voxels,e.observation_id
  pix.append(p);vox.append(v);layers.append(0);ids.append(e.observation_id);fids.append(e.frame_id);pids.append(e.instance_id)
  if k%1000==0:state.write_text(json.dumps({'status':'RUNNING','entries':k,'total':len(entries),'elapsed_seconds':time.time()-started}))
 dest=out/'source_pixel_support.npz';tmp=out/'source_pixel_support.tmp.npz';np.savez_compressed(tmp,observation_ids=np.asarray(ids,dtype=str),frame_ids=np.asarray(fids,np.int32),instance_ids=np.asarray(pids,np.int32),layer_index=np.asarray(layers,np.int16),offsets=np.r_[0,np.cumsum([len(p) for p in pix],dtype=np.int64)],flat_source_pixel_index=np.concatenate(pix).astype(np.int32),sampled_voxel_coordinates=np.concatenate(vox).astype(np.int32),voxel_size_m=np.asarray([assoc.voxel_size_m],np.float64));tmp.replace(dest)
 state.write_text(json.dumps({'status':'PASS','source_checkpoint':str(ap),'output':str(dest),'entries':len(entries),'all_sampled_voxels_exact':True,'no_repair':True,'GT_used':False,'elapsed_seconds':time.time()-started},indent=2));print('PASS',scene,len(entries),flush=True)
except Exception:state.write_text(json.dumps({'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-started},indent=2));raise
