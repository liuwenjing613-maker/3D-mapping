from pathlib import Path
import os,json,time,subprocess,traceback
R=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/replica_full_depth_fixed_selection');MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';SC=['room0','room1','room2','office0','office1','office2','office3','office4'];start=time.time();out=R/'postprocess/pooled';out.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def dump(p,d):q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(p)
try:
 while True:
  st=[read(R/'postprocess'/s/a/'status.json') for s in SC for a in ['before','after']]
  if any(x['status']=='FAILED' for x in st):raise RuntimeError('scene DBSCAN failed: '+str([(x['scene'],x['arm']) for x in st if x['status']=='FAILED']))
  if all(x['status']=='PASS' for x in st):break
  dump(out/'status.json',dict(status='WAITING_SCENES',complete=sum(x['status']=='PASS' for x in st),total=16));time.sleep(15)
 env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None)
 for arm in ['before','after']:
  rows=[]
  for s in SC:
   z=R/'postprocess'/s/arm/'r2';a=read(z/'adapter_manifest.json');rows.append(dict(gt=a['gt_file'],prediction=str(z/'canonical_prediction.npz'),diagnostic_prediction=str(z/'diagnostic_support_prediction.npz')))
  dest=out/arm;dest.mkdir(exist_ok=True);dump(dest/'batch.json',{'scenes':rows})
  with (dest/'run.log').open('w') as f:subprocess.run([PY,'-B','-m','unified_eval.cli','eval-batch','--scenes',str(dest/'batch.json'),'--out',str(dest)],cwd=MAIN,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
  x=read(dest/'summary.json');assert x['CA_PRF1_0_5']['TP']+x['CA_PRF1_0_5']['FN']==350
 summary={}
 for arm in ['before','after']:
  x=read(out/arm/'summary.json');summary[arm]={'F1':x['CA_PRF1_0_5']['F1'],'PQ':x['CA_PQ']['PQ'],'AP':x['CA_AP_uniform'],'AP50':x['CA_AP50_uniform'],'mCov':x['CA_mCov'],'TP':x['CA_PRF1_0_5']['TP'],'FP':x['CA_PRF1_0_5']['FP'],'FN':x['CA_PRF1_0_5']['FN']}
 dump(out/'comparison.json',{'status':'PASS','scenes':8,'GT':350,'scope':'full-depth incremental TSDF; paired offline SAM3; seeds originally selected on sparse geometry then reprojected; guarded DBSCAN; fixed R2','results':summary});dump(out/'status.json',{'status':'PASS','stage':'ALL_8_DBSCAN_R2_POOLED_COMPLETE','elapsed_seconds':time.time()-start});dump(Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109/direct_post_sparse/viewer/full_depth/pooled.json'),{'status':'PASS','results':summary});print(json.dumps(summary),flush=True)
except BaseException:dump(out/'status.json',{'status':'FAILED','traceback':traceback.format_exc()});raise
