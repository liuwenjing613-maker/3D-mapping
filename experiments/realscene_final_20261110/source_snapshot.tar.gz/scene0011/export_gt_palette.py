from pathlib import Path
import os,json,time,sys,traceback,colorsys,hashlib
import numpy as np
ROOT=Path('/data/chenkejun/CVPR/results/scannet0011_threshold_transfer_20261109')
R=ROOT/'full_depth_rescreen_postprocessed'
scene=sys.argv[1]
out=ROOT/'direct_post_sparse/viewer/rescreen'/scene
out.mkdir(parents=True,exist_ok=True)
started=time.time()
def read(p):return json.loads(Path(p).read_text())
def dump(p,v):
 q=Path(str(p)+'.tmp');q.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def status(v,**x):dump(out/'status.json',dict(status=v,scene=scene,elapsed_seconds=time.time()-started,**x))
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
try:
 paths=[R/'postprocess'/scene/a/'status.json' for a in ['before','after']]
 while True:
  st=[read(x) if x.exists() else {'status':'STARTING'} for x in paths]
  if any(x['status']=='FAILED' for x in st):raise RuntimeError('postprocessing failed: '+str(st))
  if all(x['status']=='PASS' for x in st):break
  status('WAITING_DBSCAN',stages=[x.get('stage',x['status']) for x in st]);time.sleep(20)
 status('EXPORTING_GT_COLOR_PLY')
 p=Path('/data/chenkejun/CVPR/visualizations/replica_gt/color_standards/replica_gt_instance_colors_v1.json')
 blob=p.read_bytes();sha=hashlib.sha256(blob).hexdigest()
 assert sha=='4e56d48db50438f7e5bfd9009b00b84c4cf2367f6ea3351d224ed7ef22950d0e','unexpected color standard'
 standard=json.loads(blob)['scenes'][scene]['colors_by_gt_instance_id']
 a,b=[load(x['source']) for x in st];xyz=a['xyz_m'];np.testing.assert_array_equal(xyz,b['xyz_m']);np.testing.assert_array_equal(a['rgb'],b['rgb'])
 ids=[a['instance_id'].astype(np.int32),b['instance_id'].astype(np.int32)];n=len(xyz)
 matched=[]
 for arm in ['before','after']:
  z=load(R/'postprocess'/scene/arm/'r2/overlap_matrix.npz');mat=z['iou'];gt=z['gt_ids'];pred=z['pred_uids'];hit=np.argwhere(mat>.5)
  m={}
  for i,j in hit:
   pid=int(pred[i]);gid=int(gt[j]);assert pid not in m and str(gid) in standard
   m[pid]=(gid,float(mat[i,j]))
  assert len({v[0] for v in m.values()})==len(m),'nonunique GT match'
  matched.append(m)
 allids=np.unique(np.concatenate(ids));allids=allids[allids>0];adj={int(k):set() for k in allids};ix=np.arange(0,n,8);vox=np.floor(xyz[ix]/.1).astype(np.int32);_,vi=np.unique(vox,axis=0,return_inverse=True)
 for lab in ids:
  pairs=np.unique(np.column_stack((vi,lab[ix])),axis=0);pairs=pairs[pairs[:,1]>0];starts=np.r_[0,np.flatnonzero(np.diff(pairs[:,0]))+1,len(pairs)]
  for l,h in zip(starts[:-1],starts[1:]):
   group=pairs[l:h,1].tolist()
   if len(group)>1:
    for x in group:adj[int(x)].update(int(y) for y in group if y!=x)
 candidates=np.unique(np.rint(np.array([colorsys.hsv_to_rgb(h/120,s,v) for h in range(120) for s in [.55,.75,.95] for v in [.7,.85,1.]])*255).astype(np.uint8),axis=0)
 fixed={int(i):[np.array(standard[str(g)],dtype=np.uint8) for m in matched for pid,(g,_) in m.items() if pid==i] for i in allids}
 fallback={};used=set();reserved={tuple(map(int,v)) for v in standard.values()}
 for iid in sorted(map(int,allids),key=lambda x:(-len(adj[x]),x)):
  if all(iid in m or iid not in lab for m,lab in zip(matched,[set(map(int,np.unique(v))) for v in ids])):continue
  near=[c for j in adj[iid] for c in fixed.get(j,[])]+[fallback[j] for j in adj[iid] if j in fallback]
  if near:score=(((candidates[:,None,:].astype(float)-np.asarray(near)[None,:,:])**2)*[.3,.59,.11]).sum(2).min(1)
  else:score=np.sum((candidates.astype(float)-110)**2,axis=1)
  for k,c in enumerate(candidates):
   if k in used or tuple(map(int,c)) in reserved:score[k]=-1
  k=int(np.argmax(score));assert score[k]>=0;fallback[iid]=candidates[k];used.add(k)
 rgb=[];views=[];audit=[]
 dt=np.dtype([('x','<f4'),('y','<f4'),('z','<f4'),('red','u1'),('green','u1'),('blue','u1'),('instance_id','<i4')])
 for i,arm in enumerate(['before','after']):
  lab=ids[i];unique,inv=np.unique(lab,return_inverse=True)
  lut=np.asarray([standard[str(matched[i][int(x)][0])] if x>0 and int(x) in matched[i] else fallback[int(x)] if x>0 else [95,104,116] for x in unique],np.uint8);col=lut[inv];rgb.append(col)
  ar=np.empty(n,dtype=dt)
  for j,k in enumerate(['x','y','z']):ar[k]=xyz[:,j]
  for j,k in enumerate(['red','green','blue']):ar[k]=col[:,j]
  ar['instance_id']=lab;filename=arm+'_gt_v1.ply';header=('ply\nformat binary_little_endian 1.0\ncomment visualization colors use GT R2 IoU > 0.5; unmatched distinct; '+arm+'\nelement vertex '+str(n)+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nproperty int instance_id\nend_header\n').encode();tmp=out/(filename+'.tmp')
  with tmp.open('wb') as f:f.write(header);ar.tofile(f)
  mm=np.memmap(tmp,dtype=dt,mode='r',offset=len(header),shape=(n,));np.testing.assert_array_equal(mm['instance_id'],lab)
  for j,k in enumerate(['x','y','z']):np.testing.assert_array_equal(mm[k],xyz[:,j])
  for j,k in enumerate(['red','green','blue']):np.testing.assert_array_equal(mm[k],col[:,j])
  del mm;tmp.replace(out/filename);del ar
  metrics=read(R/'postprocess'/scene/arm/'r2/metrics.json')['per_scene'][0]
  views.append({'instances':int((unique>0).sum()),'gray':int((lab<=0).sum()),'F1':metrics['CA_PRF1_0_5']['F1'],'AP50':metrics['CA_AP50_uniform'],'ply':filename})
  audit.append({'arm':arm,'matched_count':len(matched[i]),'unmatched_count':int((unique>0).sum())-len(matched[i]),'matches':{str(k):{'gt_id':v[0],'iou':v[1]} for k,v in matched[i].items()}})
 tmp=out/'surface_gt_v1.bin.tmp'
 with tmp.open('wb') as f:
  for ar in [np.asarray([n],dtype='<u4'),xyz.astype('<f4',copy=False),rgb[0],rgb[1]]:f.write(ar.tobytes())
 assert tmp.stat().st_size==4+n*18;tmp.replace(out/'surface_gt_v1.bin')
 conflicts=[{'pred_id':k,'before_gt':matched[0][k][0],'after_gt':matched[1][k][0]} for k in matched[0].keys()&matched[1].keys() if matched[0][k][0]!=matched[1][k][0]]
 dump(out/'scene.json',{'status':'PASS','scene':scene,'count':n,'bbox':[xyz.min(0).tolist(),xyz.max(0).tolist()],'views':views,'binary':'surface_gt_v1.bin','color_audit':{'GT_visualization_only':True,'standard_sha256':sha,'threshold':'IoU > 0.5','unmatched':'distinct fallback colors','before_after_gt_conflicts':conflicts,'arms':audit},'full_resolution':True,'geometry_and_ids_verified':True,'scope':'full-depth incremental TSDF; newly rescreened seeds; original mask gate; final B and guarded DBSCAN; offline SAM3'})
 status('PASS',matched=[len(m) for m in matched]);print('VIEW_READY',scene,flush=True)
except BaseException:status('FAILED',traceback=traceback.format_exc());raise
