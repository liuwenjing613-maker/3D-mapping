"""Rebuild fixed main baseline votes per frame before any map repair."""
from pathlib import Path
import sys,json,hashlib,os,time,traceback
import numpy as np
B=Path('/data/chenkejun/CVPR/results');R=B/'requested_fixedH_main_v2b_20261108';scene=sys.argv[1];O=R/'replica_baseline_frame_audit'/scene;O.mkdir(parents=True,exist_ok=True);start=time.time()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def put(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2));os.replace(q,p)
try:
 prep=json.loads((R/'replica_gate_geometry'/scene/'complete.json').read_text());assert prep['status']=='PASS_SEED_GEOMETRY_ONLY';surface=Path(prep['baseline_surface']);assert sha(surface)==prep['baseline_surface_sha256'];pair=surface.parent.parent/'surface_instance_frame_votes.npz';assert pair.is_file()
 with np.load(pair) as z:pp=z['surface_point_index'].astype(np.int64);pi=z['instance_id'].astype(np.int64);pv=z['frame_votes'].astype(np.int64)
 oldmax=max(prep['prior_max_id'],int(pi.max()));base=max(oldmax,*[r['persistent_id'] for r in prep['objects']])+1;assert base<65536
 assoc=Path(prep['association_file']);assert sha(assoc)==prep['association_sha256'];lookup={}
 for line in assoc.read_text().splitlines():
  x=json.loads(line);lookup[(int(x['frame_id']),int(x['mask_local_id']))]=int(x['instance_id'])
 raw=Path('/data/chenkejun/CVPR/revisable_instance_map/p1a1_raw_replica8_20261002/native')/scene/'P1-A1/surface_p0';report=json.loads((raw/'materialization_report.json').read_text());assert sha(assoc)==report['association_decisions_sha256'];records={x['frame_id']:x for x in report['frame_records']};assert sorted(records)==list(range(0,2000,5));allkeys=[]
 for idx,fid in enumerate(sorted(records),1):
  rec=records[fid];p=Path(rec['support_file']);assert sha(p)==rec['support_sha256']
  with np.load(p) as z:points=z['surface_point_index'].astype(np.int64);local=z['mask_local_id']
  lut=np.zeros(int(local.max())+1,np.int64)
  for x in np.unique(local):
   if int(x)>0:lut[int(x)]=lookup[(fid,int(x))]
  assert (lut[local]>0).all();keys=np.unique(points*base+lut[local]);_,inv,n=np.unique(keys//base,return_inverse=True,return_counts=True);allkeys.append(keys[n[inv]==1])
  if idx%50==0:put(O/'status.json',{'status':'RUNNING','stage':'BASELINE_FRAME_VOTE_AUDIT_ONLY','scene':scene,'frames':idx,'total':400,'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 keys,counts=np.unique(np.concatenate(allkeys),return_counts=True);expected=pp*base+pi;order=np.argsort(expected);np.testing.assert_array_equal(keys,expected[order]);np.testing.assert_array_equal(counts,pv[order]);put(O/'complete.json',{'status':'PASS','stage':'BASELINE_FRAME_VOTE_AUDIT_ONLY','scene':scene,'frames':400,'effective_votes':int(counts.sum()),'surface_ID_pairs':len(keys),'baseline_surface':str(surface),'baseline_surface_sha256':sha(surface),'baseline_pair':str(pair),'baseline_pair_sha256':sha(pair),'instance_base':base,'strict_frame_one_vote_abstention':True,'GT_used':False,'repair_executed':False,'elapsed_seconds':time.time()-start});put(O/'status.json',{'status':'PASS','stage':'BASELINE_FRAME_VOTE_AUDIT_ONLY','scene':scene,'frames':400,'elapsed_seconds':time.time()-start})
except BaseException:
 put(O/'status.json',{'status':'FAILED','stage':'BASELINE_FRAME_VOTE_AUDIT_ONLY','scene':scene,'traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
