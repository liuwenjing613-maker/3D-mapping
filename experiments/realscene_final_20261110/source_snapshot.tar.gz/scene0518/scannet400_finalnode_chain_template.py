from pathlib import Path
import os,json,subprocess,shutil,time,ast
E=Path('/home/chenkejun/CVPR/experiments/scannet0518_threshold_transfer_20261110');R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/scannet400');root=R/'online/scene0518_00/200/B';C=E/'scannet400_frontend/online/scene0518_00/200/B';oldroot=R/'online/scene0518_00/100/B';oldc=E/'scannet400_frontend/online/scene0518_00/100/B';s=(oldc/'fixedH_geometry.py').read_text().replace(str(oldroot),str(root));ast.parse(s);(C/'fixedH_geometry.py').write_text(s);shutil.copy2(oldc/'fixedH_wait.py',C/'fixedH_wait.py');shutil.copy2(oldc/'chain.py',C/'chain.py')
s=(E/'scannet200/online/scene0518_00/120/B/upstream_wait.py').read_text().replace("str(worker),'online','120','B'","str(worker),'online','200','B'");ast.parse(s);(C/'upstream_wait.py').write_text(s)
py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';globalc=E/'scannet400_frontend';env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'}
jobs=[('upstream',[str(C/'upstream_wait.py'),str(root),str(globalc/'upstream_worker.py')]),('visibility',[str(globalc/'visibility_worker.py'),str(root)]),('chain',[str(C/'chain.py'),str(root),str(C),str(globalc)]),('tracking',[str(globalc/'sam3_scheduler.py'),str(root)]),('gate',[str(E/'scannet_gate_wait.py'),str(root)]),('repair',[str(E/'scannet_repair_supervisor.py'),str(root),str(E/'scannet_repair_runtime/scannet400/online/scene0518_00')])]
assert not (root/'screen_chain_launch.json').exists();pids={}
for label,args in jobs:
 with (root/(label+'_orchestration.log')).open('ab',buffering=0) as f:p=subprocess.Popen([py,'-B','-u',*args],env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 pids[label]=p.pid
(root/'screen_chain_launch.json').write_text(json.dumps({'started':time.time(),'pids':pids,'scope':'causal 200 after 100 commit: candidate -> fixedH -> SAM3 -> gate -> repair'})+'\n')
nextroot=R/'online/scene0518_00/400/B';nextroot.mkdir(parents=True,exist_ok=True);assert not (nextroot/'mapping_launch.json').exists()
with (nextroot/'mapping_launcher.log').open('ab',buffering=0) as f:p=subprocess.Popen([py,'-B','-u',str(E/'scannet_next_mapping_wait.py'),str(nextroot),str(E/'scannet400_mapping/online/scene0518_00'),str(root)],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(nextroot/'mapping_launch.json').write_text(json.dumps({'pid':p.pid,'started':time.time(),'wait_for':str(root/'repair/commit_complete.json'),'scope':'causal mapping only'})+'\n');print('online200',pids,'400 wait',p.pid)
