from pathlib import Path
import os,json,time,subprocess,traceback
R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');O=R/'full_depth_rescreen_postprocessed';S=['room0','room1','room2','office0','office1','office2','office3','office4'];MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';out=O/'pooled';out.mkdir(parents=True,exist_ok=True);start=time.time()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');q.replace(p)
try:
 while True:
  rows=[read(O/'postprocess'/s/'after/status.json') if (O/'postprocess'/s/'after/status.json').exists() else {'status':'STARTING'} for s in S]
  if any(x.get('status')=='FAILED' for x in rows):raise RuntimeError('postprocess failed '+str([(s,x.get('traceback','')[-800:]) for s,x in zip(S,rows) if x.get('status')=='FAILED']))
  if all(x.get('status')=='PASS' for x in rows):break
  dump(out/'status.json',{'status':'WAITING','completed':sum(x.get('status')=='PASS' for x in rows),'total':8,'elapsed_seconds':time.time()-start});time.sleep(20)
 env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None);metrics={}
 for arm in ['sparse_after','full_before','full_rescreen_after']:
  scenes=[]
  for s in S:
   sparse=R/'direct_post_sparse/dbscan'/s/'after/r2';full=O/'postprocess'/s/'after/r2';prior=O/'postprocess'/s/'before/r2';a=read(sparse/'adapter_manifest.json');b=read(full/'adapter_manifest.json');c=read(prior/'adapter_manifest.json')
   for key in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256']:assert a[key]==b[key]==c[key],(s,key)
   assert b['geometry_xyz_sha256']==c['geometry_xyz_sha256'],s
   z,m=(sparse,a) if arm=='sparse_after' else (prior,c) if arm=='full_before' else (full,b)
   scenes.append({'gt':m['gt_file'],'prediction':str(z/'canonical_prediction.npz'),'diagnostic_prediction':str(z/'diagnostic_support_prediction.npz')})
  d=out/arm;d.mkdir(exist_ok=True);dump(d/'batch.json',{'scenes':scenes})
  with (d/'run.log').open('w') as f:subprocess.run([PY,'-B','-m','unified_eval.cli','eval-batch','--scenes',str(d/'batch.json'),'--out',str(d)],cwd=MAIN,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
  x=read(d/'summary.json');assert x['CA_PRF1_0_5']['TP']+x['CA_PRF1_0_5']['FN']==350;metrics[arm]={'F1':x['CA_PRF1_0_5']['F1'],'PQ':x['CA_PQ']['PQ'],'AP':x['CA_AP_uniform'],'AP50':x['CA_AP50_uniform'],'mCov':x['CA_mCov'],'TP':x['CA_PRF1_0_5']['TP'],'FP':x['CA_PRF1_0_5']['FP'],'FN':x['CA_PRF1_0_5']['FN']}
 result={'status':'PASS','stage':'RESCREEN_FULL_DEPTH_VS_SPARSE_DBSCAN_R2','scenes':8,'GT':350,'fixed_GT_and_evaluator':True,'full_depth_before_after_same_geometry':True,'sparse_and_full_geometry_different':True,'original_mask_gate_enabled':True,'fully_rescreened_on_full_depth':True,'historical_source_eligibility_frozen':True,'both_final_B_and_guarded_DBSCAN':True,'metrics':metrics,'elapsed_seconds':time.time()-start};dump(out/'comparison.json',result);dump(out/'status.json',{'status':'PASS','stage':result['stage'],'elapsed_seconds':time.time()-start});dump(R/'direct_post_sparse/viewer/rescreen/pooled.json',{'status':'PASS','results':{'before':metrics['full_before'],'after':metrics['full_rescreen_after']}});print(json.dumps(result),flush=True)
except BaseException:dump(out/'status.json',{'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
