from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,time
import cv2,numpy as np

MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');sys.path.insert(0,str(MAIN))
from unified_eval.current_protocol import CURRENT_CONFIG,require_current_protocol
from unified_eval.mesh_visibility import GTMeshVisibility
from unified_eval.observable_surface import ObservationFrame,observed_reference_vertices_from_frame
from unified_eval.gt_scope import coincident_label_ambiguity,apply_observed_scope
from unified_eval.io import load_gt,save_gt,sha256_array,sha256_file,repair_evaluator_code_hashes
from unified_eval.schema import CanonicalGT,Protocol
from scripts.run_object_observed_repair_development import direct_gt_oracle

require_current_protocol(CURRENT_CONFIG)
R=Path('/data/chenkejun/CVPR/results');BASE=R/'scannet0518_threshold_transfer_20261110';OLD=R/'scannet_ovimap_followup_20261107/ground_truth/scene0518_00/ground_truth';ANN=R/'scannet0050_boundary_scan_20261107/scannet_seed_assumed_all_gt_20261109/scene0518_00';OUT=BASE/'evaluation_assumed400';OUT.mkdir(exist_ok=False)
PY='/data/chenkejun/CVPR/envs/onlineanyseg/bin/python';scene='scene0518_00';config=json.loads(CURRENT_CONFIG.read_text());old=load_gt(OLD/'gt.npz');n=len(old.xyz_ref)
dtype=np.dtype([('x','<f4'),('y','<f4'),('z','<f4'),('red','u1'),('green','u1'),('blue','u1'),('source_semantic_id','<i4'),('source_instance_code','<i4'),('candidate_instance_code','<i4'),('user_seed_id','<i4'),('reference_vertex_index','<i4'),('provisional_ignore','u1'),('positive_views','<u2'),('depth_observed_views','<u2'),('geometry_source','u1'),('assumption_status','u1')])
def read(path,mesh):
 with path.open('rb') as f:
  h=b''
  while not h.endswith(b'end_header\n'):h+=f.readline()
  size=int(next(x.split()[2] for x in h.decode().splitlines() if x.startswith('element vertex ')))
  a=np.frombuffer(f.read(size*dtype.itemsize),dtype).copy();tail=f.read()
  return a,tail
ref,tail=read(ANN/(scene+'_assumed_all_mesh.ply'),True);full,extra=read(ANN/(scene+'_assumed_all_combined_points.ply'),False);assert not extra and len(ref)==n and np.array_equal(ref,full[:n]);assert np.array_equal(ref['reference_vertex_index'],np.arange(n))
xyz0=np.column_stack([ref[k] for k in ('x','y','z')]);assert np.array_equal(xyz0,old.xyz_ref);assert np.all(ref['provisional_ignore']==0) and np.all(full['provisional_ignore']==0)
faces=np.frombuffer(tail,dtype=np.dtype([('n','u1'),('idx','<i4',(3,))]));assert np.all(faces['n']==3);faces=faces['idx'].copy()
supp=full[n:];assert np.all(supp['geometry_source']==1) and np.all(supp['reference_vertex_index']==-1) and np.all(supp['user_seed_id']>0)
xyz=np.vstack([xyz0,np.column_stack([supp[k] for k in ('x','y','z')])]).astype(np.float64);seed=full['user_seed_id'];raw=np.r_[old.raw_instance_id,np.full(len(supp),-1,np.int64)].astype(np.int64);raw[seed>0]=100000+seed[seed>0];sem=np.r_[old.raw_semantic_id,np.zeros(len(supp),np.int64)].astype(np.int64);sem[seed>0]=0
amb=coincident_label_ambiguity(xyz,raw);rawmesh=raw[:n].copy();rawmesh[amb[:n]]=-1;sids=raw[n:].copy();sids[amb[n:]]=-1;renderer=GTMeshVisibility(xyz[:n],faces,rawmesh);sxyz=xyz[n:]
cfg=json.loads((BASE/'scannet400_aligned_input/inference_config.json').read_text());frames=cfg['frame_ids'];camera=cfg['camera'];K=np.array([[camera['fx'],0,camera['cx']],[0,camera['fy'],camera['cy']],[0,0,1.]]);root=Path(cfg['source']['scene_root']);assert len(frames)==400 and len(set(frames))==400
def overlay(ids,rendered,pose):
 cam=(sxyz-pose[:3,3])@pose[:3,:3];dep=cam[:,2];pos=np.flatnonzero(dep>0);u=np.floor(K[0,0]*cam[pos,0]/dep[pos]+K[0,2]+.5).astype(np.int32);v=np.floor(K[1,1]*cam[pos,1]/dep[pos]+K[1,2]+.5).astype(np.int32);h,w=ids.shape;inside=(u>=0)&(u<w)&(v>=0)&(v<h);idx=pos[inside];u=u[inside];v=v[inside];depth=dep[idx];pix=v*w+u
 if not len(pix):return ids,rendered
 order=np.lexsort((depth,pix));pix=pix[order];idx=idx[order];depth=depth[order];uniq,first=np.unique(pix,return_index=True);mindep=depth[first];chosen=sids[idx[first]];at=np.searchsorted(uniq,pix);layer=(depth-mindep[at])<.01;mn=np.full(len(uniq),np.iinfo(np.int64).max,np.int64);mx=np.full(len(uniq),np.iinfo(np.int64).min,np.int64);np.minimum.at(mn,at[layer],sids[idx[layer]]);np.maximum.at(mx,at[layer],sids[idx[layer]]);chosen[mn!=mx]=-1
 flat=rendered.ravel();fids=ids.ravel();olddepth=flat[uniq];oldids=fids[uniq];nohit=~np.isfinite(olddepth)|(olddepth<=0);front=nohit|(mindep<olddepth);near=~nohit&(np.abs(olddepth-mindep)<.01)&(oldids!=chosen);fids[uniq[front]]=chosen[front];flat[uniq[front]]=mindep[front];fids[uniq[near]]=-1;return ids,rendered
observed=np.zeros(len(xyz),np.uint16);evidence=[];t=time.time()
for i,fid in enumerate(frames):
 dp=root/'depth'/f'{fid}.png';pp=root/'pose'/f'{fid}.txt';depth=cv2.imread(str(dp),-1);assert depth is not None and depth.shape==(camera['height'],camera['width']);depth=depth.astype(np.float32)/camera['depth_png_units_per_meter'];pose=np.loadtxt(pp);pix,z=renderer.render_reference_pixels(xyz[:n],K,pose,depth.shape);pix,z=overlay(pix,z,pose);observed+=observed_reference_vertices_from_frame(xyz,raw,ObservationFrame(fid,depth,K,pose,pix,z),config['observation']['depth_tolerance_m']).astype(np.uint16);evidence.append({'frame':fid,'depth_sha256':sha256_file(dp),'pose_sha256':sha256_file(pp)})
 if (i+1)%20==0:print('VISIBLE',i+1,'/400',round(time.time()-t,1),flush=True)
source=CanonicalGT(scene,xyz,raw.copy(),sem,np.ones(len(xyz),bool),raw<=0,raw_instance_id=raw,raw_semantic_id=sem,metadata={'dataset':'ScanNet200 plus assumed user seeds and RGB-D supplement','role':'development_diagnostic_not_reviewed','source_uses_predictions':False,'annotation_mesh_sha256':sha256_file(ANN/(scene+'_assumed_all_mesh.ply')),'annotation_combined_sha256':sha256_file(ANN/(scene+'_assumed_all_combined_points.ply'))})
prior=json.loads((OLD/'candidate_scope.json').read_text());obj=[]
for r in prior['objects']:
 rid=r['raw_gt_id'];num=int(np.sum(raw==rid))
 if not num:continue
 q=copy.deepcopy(r);q.update(reference_vertex_count=num,observable=None,evaluable=False);obj.append(q)
for uid in np.unique(seed[seed>0]):
 rid=100000+int(uid);obj.append({'scene_id':scene,'raw_gt_id':rid,'semantic_class':'assumed_user_object','object_status':'TARGET','quality_verified':True,'reason':'user_requested_assumed_not_manually_verified','reference_vertex_count':int(np.sum(raw==rid)),'reference_semantic_ids':[0],'observable':None,'review_required':True,'evaluable':False,'user_seed_id':int(uid)})
scope={'schema_version':1,'evaluation_profile':'object_observed_repair','scene_id':scene,'status':'USER_REQUESTED_ASSUMED_GT_DEVELOPMENT_NOT_REVIEWED','target_classes':['official ScanNet200 objects','assumed seed objects'],'non_target_classes':['wall','floor','ceiling'],'objects':obj,'reference_xyz_sha256':sha256_array(xyz),'raw_instance_sha256':sha256_array(raw),'qualification_uses_predictions':False}
fh=hashlib.sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest();om={'method':'hybrid_original_mesh_raycast_plus_one_pixel_supplemental_reference_points','depth_tolerance_m':config['observation']['depth_tolerance_m'],'minimum_trusted_observation_count':1,'pixel_size_filter':None,'frame_ids':frames,'frame_count':400,'frame_list_sha256':fh,'input_evidence':evidence,'input_evidence_sha256':hashlib.sha256(json.dumps(evidence,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'mesh_visibility_verified':False,'status':'DEVELOPMENT_HYBRID_POINT_SPLAT_NOT_FULL_MESH_VISIBILITY','qualification_uses_predictions':False,'point_conflict_tolerance_m':.01}
gt,qualified=apply_observed_scope(source,scope,observed,observation_metadata=om,ambiguity_mask=amb);gt.metadata.update(profile_revision=2,profile_semantics_sha256=Protocol.from_dict(config).profile_semantics_sha256,evaluator_code_sha256=repair_evaluator_code_hashes());save_gt(OUT/'gt.npz',gt);(OUT/'scope.json').write_text(json.dumps(qualified,indent=2));np.savez_compressed(OUT/'visibility.npz',observation_count=observed,ambiguity_mask=amb,evaluation_region=gt.evaluation_region,raw_id=raw)
oracle=direct_gt_oracle(gt,Protocol.from_dict(config));(OUT/'oracle.json').write_text(json.dumps(oracle,indent=2));report={'scene':scene,'frame_count':400,'frame_ids_sha256':fh,'status':'USER_REQUESTED_DEVELOPMENT_DIAGNOSTIC','annotation_source':str(ANN),'gt_sha256':sha256_file(OUT/'gt.npz'),'mesh_vertices':n,'supplement_points':len(supp),'supplement_observed':int(np.sum(observed[n:]>0)),'ambiguity_points':int(amb.sum()),'target_gt_count':sum(o['evaluable'] for o in qualified['objects']),'new_seed_targets':[o['user_seed_id'] for o in qualified['objects'] if 'user_seed_id' in o and o['evaluable']],'hybrid_visibility_limitation':'supplemental points use approximate point splats; not fully mesh verified','threshold_version':'split_new3500_inherit100','method_stage':'no repair 400 frame final B and guarded DBSCAN'};(OUT/'build_report.json').write_text(json.dumps(report,indent=2));print('GT',json.dumps(report),flush=True)
surface=BASE/'scannet400/baseline_postprocess/instance_surface.npz'
print('WAITING_BASELINE_400',flush=True)
while True:
 status=BASE/'scannet400/baseline_postprocess/status.json';d=json.loads(status.read_text()) if status.exists() else {}
 if d.get('status')=='PASS':break
 if d.get('status')=='FAILED':raise RuntimeError('baseline postprocess failed: '+str(d))
 shared=BASE/'shared_input_status.json';v=json.loads(shared.read_text()) if shared.exists() else {}
 if v.get('status')=='FAILED':raise RuntimeError('shared input failed: '+str(v))
 time.sleep(20)
prov={'scene':scene,'frame_count':400,'frame_list_sha256':fh,'GT_used_for_mapping':False,'prediction_sha256':sha256_file(surface),'input_scope_verified':True,'diagnostic_scope':'assumed user annotated GT with approximate RGB-D supplementary surface; not canonical Replica350'};(OUT/'provenance.json').write_text(json.dumps(prov,indent=2));cmd=[PY,'-m','unified_eval.repair_profile','adapt','--surface',str(surface),'--gt',str(OUT/'gt.npz'),'--config',str(CURRENT_CONFIG),'--correspondence',str(OUT/'shared_correspondence.npz'),'--output-dir',str(OUT/'no_repair'),'--method-name','scene0518_400_no_repair','--method-commit','fixedH_sam3_original_gate_20261109','--source-provenance',str(OUT/'provenance.json')];env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='2',PYTHONPATH=str(MAIN));
with (OUT/'evaluate.log').open('w') as log:result=subprocess.run(cmd,cwd=MAIN,env=env,stdout=log,stderr=subprocess.STDOUT)
print('ADAPT_EXIT',result.returncode,flush=True)
if result.returncode:raise SystemExit(result.returncode)
print('COMPLETED',flush=True)
