from pathlib import Path
import json,time,os
R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');F=R/'replica_full_depth_fixed_selection';V=R/'direct_post_sparse/viewer/full_depth';S=['room0','room1','room2','office0','office1','office2','office3','office4'];V.mkdir(parents=True,exist_ok=True)
def read(p):
 try:return json.loads(p.read_text())
 except:return {}
while True:
 allready=True
 for s in S:
  v=V/s;v.mkdir(parents=True,exist_ok=True);f=v/'status.json';prev=read(f)
  if prev.get('status')=='PASS':continue
  if (v/'scene.json').exists() and all((v/name).exists() for name in ['surface.bin','before.ply','after.ply']):
   tmp=f.with_name(f.name+'.progress.tmp');tmp.write_text(json.dumps({'status':'PASS','scene':s})+'\n');os.replace(tmp,f);continue
  if prev.get('status')=='FAILED':continue
  allready=False;r=read(F/'repair_exec'/s/'runner_status.json');c=read(F/'repair_exec'/s/'commit_driver_status.json');db=[read(F/'postprocess'/s/a/'status.json') for a in ['before','after']];fail=next((x for x in [r,c,*db] if x.get('status')=='FAILED'),None)
  if fail:d={'status':'FAILED','scene':s,'message':'全深度处理失败，等待排查','detail':fail.get('traceback','')[-1200:]}
  else:
   a='修复输入打包' if not r else '实际修复'+{'RUNNING':'进行中','PASS':'完成'}.get(r.get('status'),'等待中');b='提交'+{'RUNNING':'进行中','PASS':'完成'}.get(c.get('status'),'等待中');d={'status':'WAITING','scene':s,'stages':[a,b,'最终 B 和 DBSCAN 等待中']}
  tmp=f.with_name(f.name+'.progress.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False)+'\n');os.replace(tmp,f)
 if allready:break
 time.sleep(20)
