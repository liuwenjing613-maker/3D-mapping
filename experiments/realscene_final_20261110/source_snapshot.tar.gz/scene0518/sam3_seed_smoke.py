import os,sys,json,time,hashlib,traceback
from pathlib import Path
import numpy as np
from PIL import Image
sys.path += ['/home/chenkejun/beauty/conceptgraphs/envs/cg-main/lib/python3.10/site-packages','/home/chenkejun/beauty/conceptgraphs/envs/cg-ali/lib/python3.10/site-packages']
import torch
from sam3.model_builder import build_sam3_video_predictor
B=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');R=B/'sam3_smoke';R.mkdir(exist_ok=True);start=time.monotonic()
try:
 manifest=json.loads((B/'selection_manifest.json').read_text());rows=manifest['selections']['room0'];r=next(r for r in rows if 10<=r['frame']<=1985);seed=Path('/data/chenkejun/CVPR/results/replica8_swap34_20261020/room0/v1/masks')/(r['mask_id']+'.png');assert hashlib.sha256(seed.read_bytes()).hexdigest()==r['mask_sha256'];mask=np.array(Image.open(seed))>0;assert mask.shape==(680,1200) and mask.any()
 root=Path('/home/chenkejun/beauty/conceptgraphs/data/Replica/room0/results');video=R/'rgb';video.mkdir(exist_ok=True);frames=list(range(r['frame']-5,r['frame']+6))
 for j,f in enumerate(frames):
  src=root/f'frame{f:06d}.jpg';dest=video/f'{j:06d}.jpg';assert src.exists()
  if not dest.exists():dest.symlink_to(src)
 torch.set_num_threads(4);torch.manual_seed(0);torch.cuda.set_per_process_memory_fraction(.7,0)
 p=build_sam3_video_predictor(checkpoint_path='/data/chenkejun/CVPR/models/sam3.pt',gpus_to_use=[0],async_loading_frames=True,apply_temporal_disambiguation=False,compile=False)
 session=p.handle_request({'type':'start_session','resource_path':str(video),'offload_video_to_cpu':True,'offload_state_to_cpu':True})['session_id'];z=p.handle_request({'type':'add_mask','session_id':session,'frame_index':5,'obj_id':1,'mask':mask});print('SEEDED',r['mask_id'],flush=True)
 seen={}
 for direction in ('forward','backward'):
  stream=p.handle_stream_request({'type':'propagate_in_video','session_id':session,'propagation_direction':direction,'start_frame_index':5,'force_tracker_propagation':True,'evict_cached_frame_outputs':True})
  found=[]
  for row in stream:
   i=int(row['frame_index']);m=np.asarray(row['outputs']['out_binary_masks']);ids=np.asarray(row['outputs']['out_obj_ids']);assert m.shape[1:]==mask.shape and len(ids)==len(m);found.append(i)
  seen[direction]=found;print(direction,found,flush=True)
 p.handle_request({'type':'close_session','session_id':session});p.shutdown();assert set(seen['forward'])>=set(range(6,11)) and set(seen['backward'])>=set(range(5));(R/'status.json').write_text(json.dumps({'status':'PASS','mask':r['mask_id'],'seed_frame':r['frame'],'frames':frames,'directions':seen,'elapsed_seconds':time.monotonic()-start,'model':'SAM3','scope':'small validation only, not repair'},indent=2));print('PASS',flush=True)
except BaseException:
 (R/'status.json').write_text(json.dumps({'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.monotonic()-start}));raise
