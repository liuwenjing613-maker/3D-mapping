from pathlib import Path
import os,json,time,subprocess,traceback
C=Path('/home/chenkejun/CVPR/experiments/scannet0518_threshold_transfer_20261110');O=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
state=O/'mapping_queue_status.json'
def status(s,**k):state.write_text(json.dumps(dict(status=s,scene='scene0518_00',filter_version='split_new3500_inherit100',repair_complete=False,evaluation_complete=False,**k),indent=2))
try:
 status('WAITING_SHARED_INPUTS')
 while True:
  p=O/'shared_input_status.json'
  try:d=json.loads(p.read_text())
  except (FileNotFoundError,json.JSONDecodeError):d={}
  if d.get('status')=='FAILED':raise RuntimeError('shared inputs failed: '+str(d))
  if d.get('status')=='PASS':break
  time.sleep(30)
 for method,n in [('main',400),('online',100)]:
  status('RUNNING',stage='NO_REPAIR_MAPPING' if method=='main' else 'ONLINE_INITIAL_100_MAPPING',checkpoint=n)
  env={**os.environ,'CVPR_CHECKPOINT':str(n),'CVPR_TRACK_GROUP':'B','PYTHONDONTWRITEBYTECODE':'1'}
  with (O/('mapping_'+method+'.log')).open('a') as log:
   subprocess.run([PY,'-B',str(C/'scannet400_mapping'/method/'scene0518_00/mapping_driver.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 status('PASS',stage='BASELINE400_AND_ONLINE100_MAPS_COMPLETE_REPAIR_NOT_STARTED')
except Exception:
 status('FAILED',traceback=traceback.format_exc());raise
