from pathlib import Path
import subprocess,json,traceback,time
C=Path('/home/chenkejun/CVPR/experiments/scannet0518_threshold_transfer_20261110');O=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
def state(s,**k):
 p=O/'shared_input_status.json';q=p.with_suffix('.tmp');q.write_text(json.dumps(dict(status=s,scene='scene0518_00',processed_frames_target=400,repair_complete=False,evaluation_complete=False,**k),indent=2));q.replace(p)
try:
 for n in [100,200,400]:
  state('RUNNING',stage='attributes_'+str(n))
  with (O/('attributes_'+str(n)+'.log')).open('a') as log:subprocess.run([py,'-B',str(C/'scannet400_attributes/driver.py'),str(n)],stdout=log,stderr=subprocess.STDOUT,check=True)
 state('PASS',stage='SHARED400_INPUTS_MASKS_TSDF_ATTRIBUTES_COMPLETE_NOT_REPAIR')
 subprocess.run(['/usr/bin/python3','-B',str(C/'run_mapping_queue.py')],check=True)
except Exception:
 state('FAILED',traceback=traceback.format_exc());raise
