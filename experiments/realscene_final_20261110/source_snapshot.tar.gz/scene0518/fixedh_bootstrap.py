"""Isolated original-main repair bindings for user-approved fixed-H inputs."""
from pathlib import Path
import sys,os,json,time,threading,hashlib
import numpy as np
import open3d as o3d
from scipy.spatial import cKDTree
scene_id=os.environ['CVPR_SCENE'];CHECKPOINT=400;OLD_COUNT=0;GROUP='A';CURRENT_RAW=1995;RAW_COUNT=1996;FIDS=list(range(0,2000,5))
RUN=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');ROOT=RUN/'replica_repair_exec'/scene_id;CONT=Path('/home/chenkejun/CVPR/experiments/v15_main_offline400_20261105/main')/scene_id
sys.path.insert(0,'/home/chenkejun/CVPR/experiments/auto_v2_room0_20261019/e1_repair')
from bootstrap import *
import run_repairs as r
R=ROOT/'tracking'
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+f'.{os.getpid()}.{threading.get_ident()}.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False));t.replace(p)
class OriginalScene:
 def __init__(self,_scene):
  prep=read(RUN/'replica_gate_geometry'/scene_id/'complete.json');self.final_source=Path(prep['baseline_surface']);assert digest(self.final_source)==prep['baseline_surface_sha256'];base=self.final_source.parent.parent;self.native=base/'native';self.evidence=r.load_npz(base/'surface_evidence.npz');self.pair=r.load_npz(base/'surface_instance_frame_votes.npz');nm=r.load_npz(self.native/'instance_surface.npz');fm=r.load_npz(self.final_source);self.xyz,self.rgb=nm['xyz_m'],nm['rgb'];self.original,self.final=nm['instance_id'],fm['instance_id']
  for key in ('xyz_m','rgb'):np.testing.assert_array_equal(nm[key],fm[key]);np.testing.assert_array_equal(nm[key],self.evidence[key])
  raw=Path('/data/chenkejun/CVPR/revisable_instance_map/p1a1_raw_replica8_20261002/native')/scene_id/'P1-A1/surface_p0';report=read(raw/'materialization_report.json');self.records={x['frame_id']:x for x in report['frame_records']};assert sorted(self.records)==FIDS
  assoc=Path(prep['association_file']);assert digest(assoc)==prep['association_sha256']==report['association_decisions_sha256'];self.lookup={}
  for line in assoc.read_text().splitlines():
   x=json.loads(line);self.lookup[(int(x['frame_id']),int(x['mask_local_id']))]=int(x['instance_id'])
  self.maximum_id=prep['prior_max_id'];config=Path('/data/chenkejun/CVPR/revisable_instance_map/replica8_p0_main')/scene_id/'configs/raw.json';self.source=r.ReplicaFrameSource(config);geometry=Path('/data/chenkejun/CVPR/revisable_instance_map/replica8_p0_main')/scene_id/'geometry/surface.ply';cloud=o3d.io.read_point_cloud(str(geometry));np.testing.assert_allclose(np.asarray(cloud.points),self.xyz,atol=1e-5,rtol=0);assert cloud.has_normals();self.normals=np.asarray(cloud.normals).astype(np.float32);self.tree=cKDTree(self.xyz.astype(np.float64));self.settings=r.AssignmentSettings();self.commit={'status':'PASS','processed_frames':0,'source':'independent original main baseline, no prior repair','baseline_surface_sha256':prep['baseline_surface_sha256']};self._support={};self._layers={};self.report={'min_confirmed_votes':2,'min_confirmed_ratio':.67};self.source_hashes={str(p):digest(p) for p in [self.final_source,self.native/'instance_surface.npz',base/'surface_evidence.npz',base/'surface_instance_frame_votes.npz',assoc,config,geometry]}
 def support(self,fid):
  if fid not in self._support:
   rec=self.records[fid];p=Path(rec['support_file']);assert digest(p)==rec['support_sha256'];z=r.load_npz(p);loc=z['mask_local_id'];lut=np.zeros(int(loc.max())+1,np.int32)
   for m in np.unique(loc):
    if m:lut[m]=self.lookup[(fid,int(m))]
   self._support[fid]={'surface_point_index':z['surface_point_index'],'candidate_persistent_id':lut[loc]}
  return self._support[fid]
 def expected_layer_count(self,fid):return 1
 def identity_layers(self,fid,frame=None):
  if fid not in self._layers:
   fr=frame or self.source.load_frame(fid);lut=np.zeros(int(fr.mask_local.max())+1,np.uint16)
   for m in np.unique(fr.mask_local):
    if m:lut[m]=self.lookup[(fid,int(m))]
   self._layers[fid]=[lut[fr.mask_local]]
  return self._layers[fid]
 def verify_unchanged(self):
  for path,h in self.source_hashes.items():assert digest(path)==h,path
r.Scene=OriginalScene
