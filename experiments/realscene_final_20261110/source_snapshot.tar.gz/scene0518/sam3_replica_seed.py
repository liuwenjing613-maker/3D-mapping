"""One independent SAM3 seed tracking job. This stage does not write a map."""
import os,sys,json,time,hashlib,traceback
from pathlib import Path
sys.path += ['/home/chenkejun/beauty/conceptgraphs/envs/cg-main/lib/python3.10/site-packages','/home/chenkejun/beauty/conceptgraphs/envs/cg-ali/lib/python3.10/site-packages']
import numpy as np
from PIL import Image
import torch
from sam3.model_builder import build_sam3_video_predictor
B=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');scene,mid=sys.argv[1:3];R=B/'replica_sam3_tracking'/scene/mid;R.mkdir(parents=True,exist_ok=True);started=time.monotonic()
def write(p,x):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2));os.replace(tmp,p)
try:
 rows=json.loads((B/'selection_manifest.json').read_text())['selections'][scene];r=next(x for x in rows if x['mask_id']==mid);src=Path('/data/chenkejun/CVPR/results/replica8_swap34_20261020')/scene/'v1/masks'/f'{mid}.png';seedsha=hashlib.sha256(src.read_bytes()).hexdigest();assert seedsha==r['mask_sha256'];mask=np.array(Image.open(src))>0;assert mask.shape==(680,1200) and mask.any();anchor=r['frame'];assert 0<=anchor<1996
 video=B/'replica_sam3_tracking'/scene/'rgb';assert len(list(video.glob('*.jpg')))==1996
 (R/'masks').mkdir(exist_ok=True);Image.fromarray(mask.astype(np.uint8)*255).save(R/'masks'/f'{anchor:06d}.png')
 torch.set_num_threads(4);torch.manual_seed(0);torch.cuda.set_per_process_memory_fraction(.7,0);model_start=time.monotonic();p=build_sam3_video_predictor(checkpoint_path='/data/chenkejun/CVPR/models/sam3.pt',gpus_to_use=[0],async_loading_frames=False,apply_temporal_disambiguation=False,compile=False);model_seconds=time.monotonic()-model_start;stats={}
 for direction in ('forward','backward'):
  step=time.monotonic();session=p.handle_request({'type':'start_session','resource_path':str(video),'offload_video_to_cpu':True,'offload_state_to_cpu':True})['session_id'];p.handle_request({'type':'add_mask','session_id':session,'frame_index':anchor,'obj_id':1,'mask':mask});count=0
  for result in p.handle_stream_request({'type':'propagate_in_video','session_id':session,'propagation_direction':direction,'start_frame_index':anchor,'force_tracker_propagation':True,'evict_cached_frame_outputs':True}):
   frame=int(result['frame_index'])
   if frame==anchor:continue
   assert (direction=='forward' and frame>anchor) or (direction=='backward' and frame<anchor)
   out=result['outputs'];ids=np.asarray(out['out_obj_ids']);m=np.asarray(out['out_binary_masks']);assert m.shape[1:]==mask.shape and len(ids)==len(m);where=np.flatnonzero(ids==1);assert len(where)<=1;bitmap=m[where[0]] if len(where) else np.zeros(mask.shape,bool);Image.fromarray(bitmap.astype(np.uint8)*255).save(R/'masks'/f'{frame:06d}.png');count+=1
   if count%50==0:write(R/'status.json',{'status':'RUNNING','direction':direction,'count':count,'elapsed_seconds':time.monotonic()-started,'gpu':os.getenv('CUDA_VISIBLE_DEVICES')})
  p.handle_request({'type':'close_session','session_id':session});expected=1995-anchor if direction=='forward' else anchor;assert count==expected,(direction,count,expected);stats[direction]={'count':count,'seconds':time.monotonic()-step}
 p.shutdown();assert len(list((R/'masks').glob('*.png')))==1996
 write(R/'status.json',{'status':'PASS','stage':'SAM3_TRACKING_ONLY_NOT_REPAIR','scene':scene,'mask_id':mid,'seed_frame':anchor,'seed_sha256':seedsha,'gpu':os.getenv('CUDA_VISIBLE_DEVICES'),'model_seconds':model_seconds,'directions':stats,'elapsed_seconds':time.monotonic()-started,'peak_gpu_gb':torch.cuda.max_memory_allocated()/2**30})
except BaseException:
 write(R/'status.json',{'status':'FAILED','scene':scene,'mask_id':mid,'elapsed_seconds':time.monotonic()-started,'traceback':traceback.format_exc()});raise
