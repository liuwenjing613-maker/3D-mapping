from pathlib import Path
import os,json,time,traceback,subprocess,hashlib
import numpy as np
R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/scannet400/main/scene0518_00/400/B');out=R/'evaluation_current_annotation';out.mkdir(exist_ok=True);gtroot=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/evaluation_r2/scene0518_00/ground_truth');before=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/scannet400/baseline_postprocess/instance_surface.npz');after=R/'postprocess_final/instance_surface.npz';main=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');start=time.time();py='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python'
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,d):q=Path(str(p)+'.tmp');q.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');q.replace(p)
def state(s,**k):write(out/'status.json',dict(status=s,elapsed_seconds=time.time()-start,**k))
def cli(args,log):
 env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None);env.pop('CVPR_ONLINE_GUARD',None)
 values=dict(zip(args[1::2],args[2::2]));config=main/'unified_eval/configs/replica_ca_v3.object_observed_repair.audit_r2.json'
 if args[0]=='adapt-surface':
  cmd=['adapt','--surface',values['--surface'],'--gt',values['--gt'],'--config',config,'--correspondence',values['--fixed-correspondence'],'--output-dir',values['--out'],'--method-name',values['--method-name'],'--method-commit',values['--method-commit'],'--source-provenance',values['--source-provenance']]
 elif args[0]=='eval-repair-pair':
  cmd=['paired','--gt',values['--gt'],'--before',values['--before'],'--after',values['--after'],'--config',config,'--output',Path(values['--out'])/'paired_repair_metrics.json']
 else:raise ValueError(args[0])
 with (out/log).open('ab') as f:subprocess.run([py,'-B','-m','unified_eval.repair_profile',*map(str,cmd)],cwd=main,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
try:
 while True:
  p=R/'postprocess_final/status.json';d=read(p) if p.exists() else {'status':'WAITING'}
  if d['status']=='FAILED':raise RuntimeError('postprocess failed '+str(d))
  if d['status']=='PASS':break
  state('WAITING_FULL_POSTPROCESS');time.sleep(20)
 lock=read(main/'unified_eval/configs/current_protocol.json');assert lock['profile_revision']==2 and not lock['frozen'];assert sha(main/'unified_eval/configs'/lock['config_file'])==lock['config_sha256']
 for name,h in lock['evaluator_code_sha256'].items():assert sha(main/'unified_eval'/name)==h
 gt=gtroot/'gt.npz';corr=out/'shared_correspondence.npz';report=read(gtroot/'build_report.json');assert report['frame_count']==400 and sha(gt)==report['gt_sha256']
 while True:
  bp=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/scannet400/baseline_postprocess/status.json');bs=read(bp) if bp.exists() else {'status':'WAITING'}
  if bs['status']=='FAILED':raise RuntimeError('baseline postprocess failed: '+str(bs))
  if bs['status']=='PASS':break
  state('WAITING_BASELINE_POSTPROCESS');time.sleep(20)
 with np.load(before) as a,np.load(after) as b:
  np.testing.assert_array_equal(a['xyz_m'],b['xyz_m']);np.testing.assert_array_equal(a['rgb'],b['rgb'])
 for arm,path in [('before',before),('after',after)]:
  state('RUNNING',stage='R2_ADAPT_'+arm);prov=out/(arm+'_provenance.json');write(prov,{'scene':'scene0518_00','frame_count':400,'frame_list_sha256':report['frame_list_sha256'],'annotation_source':'official0011','GT_used_for_mapping':False,'prediction_sha256':sha(path),'postprocessing':'final B and guarded DBSCAN','GT_scope':'official0011 observed mesh GT, 27 evaluable objects, not Replica350','user_approved_development_evaluation':True})
  cli(['adapt-surface','--gt',gt,'--surface',path,'--fixed-correspondence',corr,'--source-provenance',prov,'--method-name','scannet400_'+arm+'_fixedH_sam3','--method-commit','fixedH_sam3_original_gate_20261109','--out',out/arm],arm+'.log')
 a=read(out/'before/adapter_manifest.json');b=read(out/'after/adapter_manifest.json')
 for k in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256','correspondence_sha256']:assert a[k]==b[k],k
 state('RUNNING',stage='R2_PAIRED');cli(['eval-repair-pair','--gt',gt,'--before',out/'before/canonical_prediction.npz','--after',out/'after/canonical_prediction.npz','--out',out/'paired'],'paired.log')
 state('PASS',stage='FINAL_B_DBSCAN_R2_PAIRED',annotation_source='official0011',scope='official0011 400-frame observed mesh GT; not Replica350',GT_used_for_repair=False,geometry_and_correspondence_identical=True)
except BaseException:state('FAILED',traceback=traceback.format_exc());raise
