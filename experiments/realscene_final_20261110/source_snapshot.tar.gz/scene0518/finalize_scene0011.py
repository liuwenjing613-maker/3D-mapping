from pathlib import Path
import json,time,traceback,hashlib
O=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110')
def read(p):return json.loads(Path(p).read_text())

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def metric(p):
 d=read(p)['per_scene'][0];x=d['diagnostics'];pr=d['CA_PRF1_0_5']
 return dict(AP=d['CA_AP_uniform'],AP25=d['CA_AP25_uniform'],AP50=d['CA_AP50_uniform'],PQ=d['CA_PQ']['PQ'],F1=pr['F1'],TP=pr['TP'],FP=pr['FP'],FN=pr['FN'],mean_IoU=x['mean_best_gt_iou'],correct_owner_coverage=x['Correct_owner_Coverage'],prediction_instances=x['prediction_instance_count'])
def status(s,**kw):(O/'finalization_status.json').write_text(json.dumps(dict(status=s,**kw),indent=2))
try:
 paths={m:O/'scannet400'/m/'scene0518_00/400/B/evaluation_current_annotation' for m in ['main','online']}
 while True:
  states={m:read(p/'status.json') if (p/'status.json').exists() else {} for m,p in paths.items()}
  if any(d.get('status')=='FAILED' for d in states.values()):raise RuntimeError(str(states))
  if all(d.get('status')=='PASS' for d in states.values()):break
  status('WAITING_FINAL_EVALUATION');time.sleep(30)
 ref=read(paths['main']/'before/adapter_manifest.json')
 keys=['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256','correspondence_sha256']
 for p in paths.values():
  for arm in ['before','after']:
   d=read(p/arm/'adapter_manifest.json')
   for k in keys:assert d[k]==ref[k],k
 checks=[]
 for m,n in [('main',400),('online',100),('online',200),('online',400)]:
  r=O/'scannet400'/m/'scene0518_00'/str(n)/'B'
  assert read(r/'actual_repair_driver_status.json')['status']=='PASS'
  assert read(r/'repair/commit_complete.json')['processed_frames']==n
  audit=read(r/'repair/partial/mapping_complete.json')
  for k in ['baseline_multilayer_candidates_votes_evidence_exact','full_replay_equals_delta','exact_rollback','strict_same_frame_point_vote']:assert audit[k]
  if m=='online' and n>100:
   prior=r.parents[1]/str({200:100,400:200}[n])/'B/repair/commit_complete.json'
   assert read(r/'mapping/prior_commit.json')['prior_commit_sha256']==sha(prior)
  checks.append(dict(method=m,frames=n,repair_commit_audit='PASS'))
 metrics={'no_repair':metric(paths['main']/'before/metrics.json'),'main_offline':metric(paths['main']/'after/metrics.json'),'online_v2_B':metric(paths['online']/'after/metrics.json')}
 assert metrics['no_repair']==metric(paths['online']/'before/metrics.json')
 quality=['AP','AP25','AP50','PQ','F1','mean_IoU','correct_owner_coverage']
 delta={m:{k:100*(v[k]-metrics['no_repair'][k]) for k in quality} for m,v in metrics.items() if m!='no_repair'}
 result=dict(status='COMPLETE',scene='scene0518_00',processed_frames=400,baseline_version='requested_fixedH_main_v2b_20261108 fixed-H SAM3 original gate',filter_version='split_new3500_inherit100',mode={'main':'offline once400','online':'causal100/200/400'},evaluation='main object_observed_repair revision2; official0011 observed GT27; frozen=false',metrics=metrics,delta_vs_no_repair_percentage_points=delta,checks=checks,paired_invariants={k:ref[k] for k in keys})
 (O/'results_summary.json').write_text(json.dumps(result,indent=2))
 status('PASS',stage='THREE_ARMS400_FINAL_RESULTS_VERIFIED')
except Exception:status('FAILED',traceback=traceback.format_exc());raise
