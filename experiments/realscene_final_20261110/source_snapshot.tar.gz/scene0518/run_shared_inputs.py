from pathlib import Path
import os,json,struct,time,traceback,subprocess,sys,hashlib
import numpy as np
C=Path(__file__).parent;O=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');D=Path('/data/chenkejun/CVPR/datasets/MaskClustering/scannet/processed/scene0518_00');py=sys.executable;started=time.time()
def dump(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(p)
def state(s,**kw):dump(O/'shared_input_status.json',dict(status=s,scene='scene0518_00',processed_frames_target=400,mode='shared inputs for no-repair, offline main, online-v2 B',filter_version='split_new3500_inherit100',seconds=time.time()-started,**kw))
def run(name,args):
 state('RUNNING',stage=name)
 with (O/(name+'.log')).open('ab',buffering=0) as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,check=True)
try:
 sens=Path('/data/chenkejun/datasets/ScanNet/scans/scene0518_00/scene0518_00.sens');valid=[]
 with sens.open('rb') as f:
  def num(fmt):return struct.unpack('<'+fmt,f.read(struct.calcsize(fmt)))[0]
  assert num('I')==4;f.seek(num('Q'),1);f.seek(256,1)
  cc,dc=num('i'),num('i');size=[num('I') for _ in range(4)];shift=num('f');nf=num('Q');assert nf==1463 and [cc,dc]==[2,1]
  for i in range(nf):
   pose=np.frombuffer(f.read(64),dtype='<f4').reshape(4,4);f.seek(16,1);nc,nd=num('Q'),num('Q');f.seek(nc+nd,1)
   if np.isfinite(pose).all() and abs(np.linalg.det(pose[:3,:3])-1)<.01:valid.append(i)
 assert len(valid)>=400;ids=np.asarray(valid)[np.linspace(0,len(valid)-1,400,dtype=int)].tolist();assert len(set(ids))==400
 dump(O/'scannet0518_400_selection.json',{'scene':'scene0518_00','raw_frame_count':nf,'valid_raw_frames':len(valid),'original_frames':ids,'sampling':'uniform400 distinct valid raw frames across full sequence','GT_used':False})
 run('raw_extract',[py,'-B',str(C/'extract_400.py')])
 raw=O/'scannet400_input_raw';src=O/'source_rgbd/scene0518_00';src.mkdir(parents=True,exist_ok=True)
 for name in ['color','depth','pose']:(src/name).mkdir(exist_ok=True)
 (src/'intrinsic').symlink_to(D/'intrinsic',target_is_directory=True)
 for i,fid in enumerate(ids):
  for dest,source,ext in [('color','rgb','jpg'),('depth','depth','png'),('pose','pose','txt')]:
   (src/dest/(str(fid)+'.'+ext)).symlink_to(raw/source/(f'{i:06d}.'+ext))
 run('align_inputs',[py,'-B',str(C/'prepare_400_aligned.py')])
 aligned=O/'scannet400_aligned_input';cfg=json.loads((aligned/'config.json').read_text())
 dump(aligned/'inference_config.json',{'dataset':'ScanNet','scene':'scene0518_00','frame_ids':ids,'camera':cfg['camera'],'source':{'scene_root':str(src),'mask_root':str(aligned/'raw_masks')}})
 (C/'build').mkdir(exist_ok=True)
 import native_runtime400 as native
 cmds={'baseline_masks':[py,'-B','-u',str(C/'scannet400_baseline/driver.py'),str(aligned),str(C/'scannet400_baseline/infer_scannet.py')],'geometry':native.container(['/usr/bin/python3','-B','/experiment/native_geometry400.py','scene0518_00','full'])}
 procs={};logs=[]
 for name,cmd in cmds.items():
  f=(O/(name+'.log')).open('ab',buffering=0);logs.append(f);p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);procs[name]=p
 dump(O/'shared_jobs_launch.json',{k:{'pid':p.pid,'start':time.time()} for k,p in procs.items()});state('RUNNING',stage='BASELINE_MASKS_AND_SHARED_TSDF',pids={k:p.pid for k,p in procs.items()})
 for name,p in procs.items():assert p.wait()==0,name
 geo=O/'scannet400_geometry';rows=[json.loads(x) for x in (geo/'native/scene0518_00/full/frame_input_audit.jsonl').read_text().splitlines()]
 import cv2
 for row in rows:
  mask=cv2.imread(str(aligned/'masks'/f"frame{row['frame_id']:06d}.png"),-1);assert mask.shape==(480,640)
  row['mask_decoded_sha256']=hashlib.sha256(np.ascontiguousarray(mask.astype(np.int32)).tobytes()).hexdigest();dump(geo/'frame_meta/scene0518_00'/f"f{row['frame_id']:06d}.json",row)
 for n in [100,200,400]:run('attributes_'+str(n),[py,'-B',str(C/'scannet400_attributes/driver.py'),str(n)])
 state('PASS',stage='SHARED400_INPUTS_MASKS_TSDF_ATTRIBUTES_COMPLETE_NOT_REPAIR',completed_processed_frames=400,repair_complete=False,evaluation_complete=False)
except BaseException:state('FAILED',traceback=traceback.format_exc());raise
