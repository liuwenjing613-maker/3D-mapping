from pathlib import Path
import os,json,time,sys,traceback,colorsys
import numpy as np
R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/replica_full_depth_fixed_selection');scene=sys.argv[1];out=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110/direct_post_sparse/viewer/full_depth')/scene;out.mkdir(parents=True,exist_ok=True);started=time.time()
def read(p):return json.loads(Path(p).read_text())
def dump(p,v):
 q=Path(str(p)+'.tmp');q.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def status(v,**x):dump(out/'status.json',dict(status=v,scene=scene,elapsed_seconds=time.time()-started,**x))
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
try:
 paths=[R/'postprocess'/scene/a/'status.json' for a in ['before','after']]
 while True:
  st=[read(x) if x.exists() else {'status':'STARTING'} for x in paths]
  if any(x['status']=='FAILED' for x in st):raise RuntimeError('DBSCAN failed: '+str([x.get('traceback','')[-900:] for x in st if x['status']=='FAILED']))
  if all(x['status']=='PASS' for x in st):break
  status('WAITING_DBSCAN',stages=[x.get('stage',x['status']) for x in st]);time.sleep(15)
 status('EXPORTING_PLY');a,b=[load(x['source']) for x in st];xyz=a['xyz_m'];np.testing.assert_array_equal(xyz,b['xyz_m']);np.testing.assert_array_equal(a['rgb'],b['rgb']);ids=[a['instance_id'].astype(np.int32),b['instance_id'].astype(np.int32)];n=len(xyz)
 allids=np.unique(np.concatenate(ids));allids=allids[allids>0];adj={int(k):set() for k in allids};ix=np.arange(0,n,8);vox=np.floor(xyz[ix]/.1).astype(np.int32);_,vi=np.unique(vox,axis=0,return_inverse=True)
 for lab in ids:
  pairs=np.unique(np.column_stack((vi,lab[ix])),axis=0);pairs=pairs[pairs[:,1]>0];starts=np.r_[0,np.flatnonzero(np.diff(pairs[:,0]))+1,len(pairs)]
  for l,h in zip(starts[:-1],starts[1:]):
   group=pairs[l:h,1].tolist()
   if len(group)>1:
    for x in group:adj[int(x)].update(int(y) for y in group if y!=x)
 candidates=np.unique(np.rint(np.array([colorsys.hsv_to_rgb(h/120,s,v) for h in range(120) for s in [.55,.75,.95] for v in [.7,.85,1.]])*255).astype(np.uint8),axis=0);palette={};used=set()
 for iid in sorted(map(int,allids),key=lambda x:(-len(adj[x]),x)):
  near=[palette[j] for j in adj[iid] if j in palette];score=np.zeros(len(candidates))
  if near:score=(((candidates[:,None,:].astype(float)-np.asarray(near)[None,:,:])**2)*[.3,.59,.11]).sum(2).min(1)
  else:score=np.sum((candidates.astype(float)-110)**2,axis=1)
  if used:score[list(used)]=-1
  k=int(np.argmax(score));palette[iid]=candidates[k];used.add(k)
 rgb=[]
 for lab in ids:
  unique,inv=np.unique(lab,return_inverse=True);lut=np.asarray([palette[int(x)] if x>0 else [95,104,116] for x in unique],np.uint8);rgb.append(lut[inv])
 dt=np.dtype([('x','<f4'),('y','<f4'),('z','<f4'),('red','u1'),('green','u1'),('blue','u1'),('instance_id','<i4')]);views=[]
 for i,arm in enumerate(['before','after']):
  ar=np.empty(n,dtype=dt)
  for j,k in enumerate(['x','y','z']):ar[k]=xyz[:,j]
  for j,k in enumerate(['red','green','blue']):ar[k]=rgb[i][:,j]
  ar['instance_id']=ids[i];header=('ply\nformat binary_little_endian 1.0\ncomment full-depth incremental TSDF; final B and guarded covisible DBSCAN; '+arm+'\nelement vertex '+str(n)+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nproperty int instance_id\nend_header\n').encode();tmp=out/(arm+'.tmp.ply')
  with tmp.open('wb') as f:f.write(header);ar.tofile(f)
  mm=np.memmap(tmp,dtype=dt,mode='r',offset=len(header),shape=(n,));np.testing.assert_array_equal(mm['instance_id'],ids[i]);[np.testing.assert_array_equal(mm[k],xyz[:,j]) for j,k in enumerate(['x','y','z'])];del mm;tmp.replace(out/(arm+'.ply'));del ar
  metrics=read(R/'postprocess'/scene/arm/'r2/metrics.json')['per_scene'][0];views.append({'instances':int((np.unique(ids[i])>0).sum()),'gray':int((ids[i]<=0).sum()),'F1':metrics['CA_PRF1_0_5']['F1'],'AP50':metrics['CA_AP50_uniform'],'ply':arm+'.ply'})
 tmp=out/'surface.tmp.bin'
 with tmp.open('wb') as f:
  for ar in [np.asarray([n],dtype='<u4'),xyz.astype('<f4',copy=False),rgb[0],rgb[1]]:f.write(ar.tobytes())
 assert tmp.stat().st_size==4+n*18;tmp.replace(out/'surface.bin')
 dump(out/'scene.json',{'status':'PASS','scene':scene,'count':n,'bbox':[xyz.min(0).tolist(),xyz.max(0).tolist()],'views':views,'color_audit':{'same_id_same_color':True,'adjacent_colors_optimized':True},'full_resolution':True,'geometry_and_ids_verified':True,'scope':'full-depth incremental TSDF; final B plus guarded DBSCAN; offline SAM3; sparse-reviewed seeds projected to full geometry'});status('PASS');print('VIEW_READY',scene,flush=True)
except BaseException:status('FAILED',traceback=traceback.format_exc());raise
