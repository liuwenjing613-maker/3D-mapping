"""Adapt completed binary SAM3 tracks into individual uint16 track-ID images.

This only prepares gate inputs. It does not decide persistent IDs or repair a map.
"""
from pathlib import Path
import json,os,time,hashlib,traceback,concurrent.futures
import numpy as np
from PIL import Image
B=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');R=B/'replica_gate_label_inputs';R.mkdir(exist_ok=True);start=time.time()
audit=B/'replica_sam3_tracking/mapping_frame_audit.json';assert json.loads(audit.read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(v,ensure_ascii=False,indent=2));os.replace(q,p)
jobs=[]
for p in sorted((B/'replica_repair_input_manifest').glob('*.json')):
 d=json.loads(p.read_text());assert d['status']=='VALIDATED_TRACKING_INPUT_ONLY_NOT_REPAIR'
 for i,r in enumerate(sorted(d['seeds'],key=lambda x:x['mask_id']),1):jobs.append((d['scene'],i,r))
assert len(jobs)==122
def convert(job):
 scene,tid,r=job;root=R/scene/r['mask_id'];root.mkdir(parents=True,exist_ok=True);dst=root/'labels';dst.mkdir(exist_ok=True);src=Path(r['tracking_directory']);proof={int(x['frame']):x for x in r['mapping_frame_hashes']};assert len(proof)==400
 status=json.loads((src.parent/'status.json').read_text());assert status['status']=='PASS' and status['seed_sha256']==r['source_mask_sha256'];source=Path(r['source_mask']);assert sha(source)==r['source_mask_sha256'];seed=np.asarray(Image.open(source))>0;mapping=[]
 for i in range(1996):
  p=src/f'{i:06d}.png';data=p.read_bytes()
  if i in proof:assert hashlib.sha256(data).hexdigest()==proof[i]['sha256']
  mask=np.asarray(Image.open(p));assert mask.shape==(680,1200) and mask.dtype==np.uint8
  if i==r['seed_frame']:assert np.array_equal(mask>0,seed)
  labels=np.where(mask>0,tid,0).astype(np.uint16);q=dst/f'{i:06d}.png';Image.fromarray(labels).save(q,compress_level=1)
  if i in proof:mapping.append({'frame':i,'source_sha256':proof[i]['sha256'],'label_sha256':sha(q),'pixels':proof[i]['pixels']})
 assert len(list(dst.glob('*.png')))==1996 and len(mapping)==400
 report=dict(status='PASS_INPUT_ADAPTER_ONLY',scene=scene,mask_id=r['mask_id'],track_id=tid,H_group=r['H_group'],medoids_group=r['medoids_group'],medoids_cluster=r['medoids_cluster'],seed_frame=r['seed_frame'],source_mask_sha256=r['source_mask_sha256'],id_preview=r['id_preview'],tracking_model='SAM3',mapping_frames=mapping,frames=1996,GT_used=False,repair_executed=False);write(root/'adaptation.json',report);return {'scene':scene,'mask_id':r['mask_id'],'track_id':tid,'path':str(root/'adaptation.json')}
try:
 done=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  futures=[pool.submit(convert,j) for j in jobs]
  for f in concurrent.futures.as_completed(futures):
   done.append(f.result())
   if len(done)%5==0:write(R/'status.json',{'status':'RUNNING','stage':'SAM3_BINARY_TO_TRACK_LABELS_NOT_REPAIR','completed':len(done),'total':122,'elapsed_seconds':time.time()-start,'pid':os.getpid()})
 done.sort(key=lambda x:(x['scene'],x['track_id']));write(R/'complete.json',{'status':'PASS_INPUT_ADAPTER_ONLY','stage':'SAM3_BINARY_TO_TRACK_LABELS_NOT_REPAIR','cases':done,'elapsed_seconds':time.time()-start,'GT_used':False});write(R/'status.json',{'status':'PASS','stage':'SAM3_BINARY_TO_TRACK_LABELS_NOT_REPAIR','completed':len(done),'elapsed_seconds':time.time()-start,'pid':os.getpid()})
except BaseException:
 write(R/'status.json',{'status':'FAILED','stage':'SAM3_BINARY_TO_TRACK_LABELS_NOT_REPAIR','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
