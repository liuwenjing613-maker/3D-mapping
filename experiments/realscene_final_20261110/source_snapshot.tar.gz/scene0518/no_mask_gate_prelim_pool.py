from pathlib import Path
import os,json,time,subprocess,traceback
R=Path('/data/chenkejun/CVPR/results/scannet0518_threshold_transfer_20261110');O=R/'ablation_no_mask_gate_full_depth';G=R/'replica_full_depth_fixed_selection';MAIN=Path('/home/chenkejun/CVPR/worktrees/v3-r2-main-20261009');PY='/data/chenkejun/beauty/ovo_paper_original_20260915/env/bin/python';SC=['room0','room1','room2','office0','office1','office2','office3','office4'];out=O/'pre_dbscan/pooled';out.mkdir(parents=True,exist_ok=True);start=time.time()
def read(p):return json.loads(p.read_text())
def dump(p,d):q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');q.replace(p)
try:
 while True:
  st=[read(O/'pre_dbscan'/s/'status.json') if (O/'pre_dbscan'/s/'status.json').exists() else {'status':'STARTING'} for s in SC]
  failures=[(s,x.get('traceback','')[-1200:]) for s,x in zip(SC,st) if x.get('status')=='FAILED']
  if failures:raise RuntimeError('no-gate postprocess failed '+str(failures))
  if all(x.get('status')=='PASS' for x in st):break
  dump(out/'status.json',{'status':'WAITING_SCENES','complete':sum(x.get('status')=='PASS' for x in st),'total':8,'elapsed_seconds':time.time()-start});time.sleep(20)
 env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'};env.pop('PYTHONPATH',None)
 metrics={}
 for arm in ['with_gate','without_gate']:
  rows=[]
  for s in SC:
   base=O/'pre_dbscan'/s/'with_gate';new=O/'pre_dbscan'/s/'without_gate';a=read(base/'adapter_manifest.json');b=read(new/'adapter_manifest.json')
   for k in ['profile_config_sha256','evaluator_code_sha256','gt_file_sha256','gt_scope_sha256','gt_observed_support_sha256','geometry_xyz_sha256']:assert a[k]==b[k],(s,k)
   z=base if arm=='with_gate' else new;m=a if arm=='with_gate' else b;rows.append(dict(gt=m['gt_file'],prediction=str(z/'canonical_prediction.npz'),diagnostic_prediction=str(z/'diagnostic_support_prediction.npz')))
  dest=out/arm;dest.mkdir(exist_ok=True);dump(dest/'batch.json',{'scenes':rows})
  with (dest/'run.log').open('w') as f:subprocess.run([PY,'-B','-m','unified_eval.cli','eval-batch','--scenes',str(dest/'batch.json'),'--out',str(dest)],cwd=MAIN,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,check=True)
  x=read(dest/'summary.json');assert x['CA_PRF1_0_5']['TP']+x['CA_PRF1_0_5']['FN']==350;metrics[arm]={'F1':x['CA_PRF1_0_5']['F1'],'PQ':x['CA_PQ']['PQ'],'AP':x['CA_AP_uniform'],'AP50':x['CA_AP50_uniform'],'mCov':x['CA_mCov'],'TP':x['CA_PRF1_0_5']['TP'],'FP':x['CA_PRF1_0_5']['FP'],'FN':x['CA_PRF1_0_5']['FN']}
 d={'status':'PASS','stage':'NO_GATE_VS_GATE_FINAL_B_BEFORE_DBSCAN_R2','scenes':8,'GT':350,'same_geometry_GT_seeds_tracks_ID_association':True,'both_final_B_and_guarded_DBSCAN':False,'DBSCAN_complete':False,'gate_difference':'per-mask frame validity gate disabled, original overlap-pixel abstention retained','selection_provenance':'old sparse-screened user-reviewed seeds reprojected to full depth; not newly re-screened','GT_used_for_decisions':False,'metrics':metrics,'elapsed_seconds':time.time()-start}
 dump(out/'comparison.json',d);dump(out/'status.json',{'status':'PASS','stage':'NO_GATE_VS_GATE_FINAL_B_BEFORE_DBSCAN_R2','elapsed_seconds':time.time()-start});print(json.dumps(d),flush=True)
except BaseException:dump(out/'status.json',{'status':'FAILED','traceback':traceback.format_exc(),'elapsed_seconds':time.time()-start});raise
